# SehPlus – öffentliche Projektversion

SehPlus ist eine unabhängige Alltagshilfe für Menschen, die Farben schwerer unterscheiden. Die App bietet Kamera, Farbfilter, Standbild, Pipette, Zoom, Testlabor und eine lokale PWA.

## Funktionen

- Rot-Grün-, Blau-Gelb-, Kontrast- und Neutralfilter
- Livekamera, Standbild, Galerie- und Videoauswahl
- Pipette mit Farbnamen, HEX- und RGB-Werten
- Zoom, Taschenlampe, Lichtkalibrierung und Farbmemos
- Offline-Testlabor mit Beispielbildern
- kostenlose Web/PWA-Version unter `web/`

## Auf dem Mac öffnen

1. Den Projektordner entpacken.
2. Android Studio öffnen und den Ordner mit `settings.gradle` auswählen.
3. Gradle-Sync abwarten.
4. Für ein angeschlossenes Android-Gerät **Run** drücken.

Alternativ erzeugt `./gradlew assembleDebug` einen installierbaren Debug-Build unter `app/build/outputs/apk/debug/`.

## Web/PWA testen

Im Ordner `web` kann ein einfacher lokaler Server gestartet werden:

```bash
cd web
python3 -m http.server 8080
```

Für Kamerazugriff auf einem echten Smartphone muss die Seite über HTTPS geöffnet werden. Die PWA ist buildless und kann direkt über GitHub Pages veröffentlicht werden.

## Wichtige Hinweise

SehPlus ist ein persönliches, unabhängiges Projekt und keine offizielle Store-App. Die App ist eine visuelle Alltagshilfe und ersetzt keine medizinische Untersuchung. Die Messwerte hängen unter anderem von Kamera, Display und Licht ab.

Die App benötigt kein Konto und keinen API-Schlüssel. Kamera- und Bildverarbeitung findet in der jeweiligen App- bzw. Browseransicht statt; externe Dienste sind nicht Bestandteil dieser Projektversion.

## Farbprofil

`app/src/main/assets/sehplus_color_assist_v2.json` enthält die wiederverwendbaren Farbprofile und lokalen Erkennungsmodi.

## Version

Diese öffentliche Projektversion ist SehPlus 1.6.2.
