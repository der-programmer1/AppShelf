# SehPlus Web/PWA

Die Web-Version ist eine buildless PWA für moderne Browser. Sie enthält Kamera, Bildauswahl, Farbfilter, Standbild, Pipette, Zoom und lokale Farbmemos.

## Lokal testen

```bash
cd web
python3 -m http.server 8080
```

Für Kamerafunktionen auf einem echten Smartphone muss die Seite über HTTPS erreichbar sein. Auf `localhost` erlauben moderne Browser den Kameratest meist auch ohne HTTPS.

## GitHub Pages

Den Inhalt dieses Ordners kann ein statischer GitHub-Pages-Workflow veröffentlichen. Die PWA benötigt keinen Build-Schritt und keinen Server für die Bildverarbeitung.

## Hinweise

SehPlus ist ein unabhängiges persönliches Projekt und keine offizielle Store-App. Die App ist eine visuelle Alltagshilfe und ersetzt keine medizinische Untersuchung. Die Taschenlampensteuerung hängt vom Browser und Gerät ab.
