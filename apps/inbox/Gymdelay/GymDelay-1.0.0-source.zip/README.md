# GymDelay

GymDelay starts the currently selected and paused music after a short delay. It is designed for the moment when a set begins but straps, gloves, or another preparation step still takes a few seconds.

## Verhalten

- 5, 10, 15, 30 oder 60 Sekunden auswählen
- Start drücken: laufende Musik wird pausiert; pausierte Musik bleibt bereit
- Countdown läuft mit sichtbarer Benachrichtigung im Hintergrund weiter
- Nach Ablauf wird nur die ausgewählte Android-Medien-Session wieder gestartet
- Abbrechen ist in der App und in der Benachrichtigung möglich

GymDelay streamt und speichert keine Musik. Für Spotify und kompatible Musik-Apps braucht Android einmal den Notification-Listener-Zugriff, damit GymDelay die aktive MediaSession verwenden darf. Die App verarbeitet daraus nur die Mediensteuerung und speichert keine Benachrichtigungstexte.

## Öffnen und bauen

Das Projekt kann direkt in Android Studio als Ordner `GymDelay` geöffnet werden.

Auf dem Entwicklungsrechner wurde es mit JDK 17, Android SDK 36 und Gradle 8.13 gebaut:

```bash
ANDROID_HOME=/root/android-sdk \
ANDROID_SDK_ROOT=/root/android-sdk \
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64 \
./gradlew testDebugUnitTest assembleDebug --no-daemon --console=plain \
  -Pandroid.aapt2FromMavenOverride=/tmp/aapt2
```

Das Debug-APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

## Einrichtung auf dem Telefon

1. GymDelay installieren.
2. In GymDelay „Medienzugriff einrichten“ öffnen und GymDelay aktivieren.
3. Benachrichtigungen erlauben.
4. Spotify öffnen, einen Titel auswählen und pausieren.
5. In GymDelay die Dauer wählen und „Start drücken“.
