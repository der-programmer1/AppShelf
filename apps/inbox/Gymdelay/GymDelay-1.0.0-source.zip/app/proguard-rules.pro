# GymDelay uses Android framework media-session and notification APIs.
