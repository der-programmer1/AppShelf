package com.gymdelay.app

import kotlin.math.max

internal object DelayLogic {
    fun remainingSeconds(endElapsedRealtime: Long, nowElapsedRealtime: Long): Int {
        val remainingMillis = endElapsedRealtime - nowElapsedRealtime
        if (remainingMillis <= 0L) return 0
        return ((remainingMillis + 999L) / 1_000L).toInt()
    }

    fun progress(durationSeconds: Int, endElapsedRealtime: Long, nowElapsedRealtime: Long): Float {
        if (durationSeconds <= 0) return 1f
        val remaining = remainingSeconds(endElapsedRealtime, nowElapsedRealtime)
        return (1f - remaining.toFloat() / durationSeconds.toFloat()).coerceIn(0f, 1f)
    }

    fun safeDuration(seconds: Int): Int = max(5, seconds.coerceAtMost(60))
}
