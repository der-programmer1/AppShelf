package com.gymdelay.app

import android.content.Context
import androidx.core.content.edit

internal data class ActiveDelay(
    val endElapsedRealtime: Long,
    val durationSeconds: Int,
    val sourceName: String,
    val trackName: String,
)

internal class DelayPreferences(context: Context) {
    private val preferences = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun lastDelaySeconds(): Int = preferences.getInt(KEY_LAST_DELAY, DEFAULT_DELAY_SECONDS)

    fun saveLastDelaySeconds(seconds: Int) {
        preferences.edit { putInt(KEY_LAST_DELAY, seconds) }
    }

    fun saveActive(delay: ActiveDelay) {
        preferences.edit {
            putBoolean(KEY_ACTIVE, true)
            putLong(KEY_END, delay.endElapsedRealtime)
            putInt(KEY_DURATION, delay.durationSeconds)
            putString(KEY_SOURCE, delay.sourceName)
            putString(KEY_TRACK, delay.trackName)
        }
    }

    fun activeDelay(): ActiveDelay? {
        if (!preferences.getBoolean(KEY_ACTIVE, false)) return null
        return ActiveDelay(
            endElapsedRealtime = preferences.getLong(KEY_END, 0L),
            durationSeconds = preferences.getInt(KEY_DURATION, DEFAULT_DELAY_SECONDS),
            sourceName = preferences.getString(KEY_SOURCE, "Musik") ?: "Musik",
            trackName = preferences.getString(KEY_TRACK, "Aktueller Titel") ?: "Aktueller Titel",
        )
    }

    fun clearActive() {
        preferences.edit {
            remove(KEY_ACTIVE)
            remove(KEY_END)
            remove(KEY_DURATION)
            remove(KEY_SOURCE)
            remove(KEY_TRACK)
        }
    }

    private companion object {
        const val FILE_NAME = "gym_delay_preferences"
        const val KEY_LAST_DELAY = "last_delay_seconds"
        const val KEY_ACTIVE = "active_delay"
        const val KEY_END = "active_end_elapsed"
        const val KEY_DURATION = "active_duration_seconds"
        const val KEY_SOURCE = "active_source"
        const val KEY_TRACK = "active_track"
        const val DEFAULT_DELAY_SECONDS = 30
    }
}
