package com.gymdelay.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal enum class DelayPhase { IDLE, COUNTDOWN }

internal data class GymDelayUiState(
    val hasMediaAccess: Boolean = false,
    val hasNotifications: Boolean = false,
    val mediaSession: MediaSessionInfo? = null,
    val selectedDelaySeconds: Int = 30,
    val phase: DelayPhase = DelayPhase.IDLE,
    val endElapsedRealtime: Long = 0L,
    val durationSeconds: Int = 0,
    val remainingSeconds: Int = 0,
    val activeSourceName: String = "",
    val activeTrackName: String = "",
    val message: String? = null,
)

internal class GymDelayViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application
    private val preferences = DelayPreferences(application)
    private val mediaController = MediaSessionController(application)
    private val mutableState = MutableStateFlow(
        GymDelayUiState(selectedDelaySeconds = preferences.lastDelaySeconds()),
    )
    private var tickerJob: Job? = null

    val state: StateFlow<GymDelayUiState> = mutableState.asStateFlow()

    init {
        restoreActiveCountdown()
        refresh()
    }

    fun refresh() {
        val active = preferences.activeDelay()
        val end = active?.endElapsedRealtime ?: 0L
        val activeStillValid = end > SystemClock.elapsedRealtime()
        if (active != null && activeStillValid) {
            mutableState.update {
                it.copy(
                    phase = DelayPhase.COUNTDOWN,
                    endElapsedRealtime = end,
                    durationSeconds = active.durationSeconds,
                    remainingSeconds = DelayLogic.remainingSeconds(end, SystemClock.elapsedRealtime()),
                    activeSourceName = active.sourceName,
                    activeTrackName = active.trackName,
                )
            }
            startTicker(end)
        } else if (active != null) {
            preferences.clearActive()
        }

        val access = mediaController.hasNotificationListenerAccess()
        mutableState.update {
            it.copy(
                hasMediaAccess = access,
                hasNotifications = NotificationManagerCompat.from(app).areNotificationsEnabled(),
                mediaSession = if (access) mediaController.findActiveSession() else null,
            )
        }
    }

    fun selectDelay(seconds: Int) {
        if (state.value.phase == DelayPhase.COUNTDOWN) return
        val safeSeconds = DelayLogic.safeDuration(seconds)
        preferences.saveLastDelaySeconds(safeSeconds)
        mutableState.update { it.copy(selectedDelaySeconds = safeSeconds, message = null) }
    }

    fun start(context: Context) {
        val currentState = state.value
        if (!currentState.hasMediaAccess) {
            showMessage("Richte zuerst den Medienzugriff ein.")
            return
        }
        if (!currentState.hasNotifications) {
            showMessage("Erlaube Benachrichtigungen, damit der Countdown zuverlässig sichtbar bleibt.")
            return
        }

        val session = mediaController.findActiveSession()
        if (session == null) {
            showMessage("Keine Musik gefunden. Öffne Spotify, wähle einen Titel und pausiere ihn.")
            return
        }

        val duration = DelayLogic.safeDuration(currentState.selectedDelaySeconds)
        val end = SystemClock.elapsedRealtime() + duration * 1_000L
        if (session.isPlaying && !mediaController.pause(session)) {
            showMessage("Die aktuelle Musik konnte nicht pausiert werden.")
            return
        }

        val activeDelay = ActiveDelay(
            endElapsedRealtime = end,
            durationSeconds = duration,
            sourceName = session.appName,
            trackName = session.title,
        )
        preferences.saveActive(activeDelay)
        mutableState.update {
            it.copy(
                phase = DelayPhase.COUNTDOWN,
                endElapsedRealtime = end,
                durationSeconds = duration,
                remainingSeconds = duration,
                activeSourceName = session.appName,
                activeTrackName = session.title,
                message = "Vorbereitung läuft. Musik startet danach automatisch.",
            )
        }
        startTicker(end)

        val serviceIntent = Intent(context, MusicDelayService::class.java).apply {
            action = MusicDelayService.ACTION_START
            putExtra(MusicDelayService.EXTRA_TOKEN, session.token)
            putExtra(MusicDelayService.EXTRA_END_ELAPSED, end)
            putExtra(MusicDelayService.EXTRA_DURATION_SECONDS, duration)
            putExtra(MusicDelayService.EXTRA_SOURCE_NAME, session.appName)
            putExtra(MusicDelayService.EXTRA_TRACK_NAME, session.title)
        }
        runCatching {
            ContextCompat.startForegroundService(context, serviceIntent)
        }.onFailure {
            preferences.clearActive()
            tickerJob?.cancel()
            mutableState.update {
                it.copy(phase = DelayPhase.IDLE, remainingSeconds = 0, message = "Der Hintergrund-Countdown konnte nicht gestartet werden.")
            }
        }
    }

    fun cancel(context: Context) {
        context.startService(
            Intent(context, MusicDelayService::class.java).setAction(MusicDelayService.ACTION_CANCEL),
        )
    }

    fun onServiceState(intent: Intent) {
        when (intent.getStringExtra(MusicDelayService.EXTRA_STATE)) {
            MusicDelayService.STATE_COUNTDOWN -> {
                val end = intent.getLongExtra(MusicDelayService.EXTRA_END_ELAPSED, state.value.endElapsedRealtime)
                mutableState.update {
                    it.copy(
                        phase = DelayPhase.COUNTDOWN,
                        endElapsedRealtime = end,
                        durationSeconds = intent.getIntExtra(MusicDelayService.EXTRA_DURATION_SECONDS, it.durationSeconds),
                        activeSourceName = intent.getStringExtra(MusicDelayService.EXTRA_SOURCE_NAME) ?: it.activeSourceName,
                        activeTrackName = intent.getStringExtra(MusicDelayService.EXTRA_TRACK_NAME) ?: it.activeTrackName,
                        remainingSeconds = intent.getIntExtra(MusicDelayService.EXTRA_REMAINING_SECONDS, it.remainingSeconds),
                    )
                }
                startTicker(end)
            }

            MusicDelayService.STATE_COMPLETED,
            MusicDelayService.STATE_CANCELLED,
            MusicDelayService.STATE_FAILED,
            -> {
                tickerJob?.cancel()
                preferences.clearActive()
                mutableState.update {
                    it.copy(
                        phase = DelayPhase.IDLE,
                        endElapsedRealtime = 0L,
                        durationSeconds = 0,
                        remainingSeconds = 0,
                        message = intent.getStringExtra(MusicDelayService.EXTRA_MESSAGE),
                    )
                }
                refresh()
            }
        }
    }

    fun clearMessage() {
        mutableState.update { it.copy(message = null) }
    }

    private fun restoreActiveCountdown() {
        val active = preferences.activeDelay() ?: return
        if (active.endElapsedRealtime <= SystemClock.elapsedRealtime()) {
            preferences.clearActive()
            return
        }
        mutableState.update {
            it.copy(
                phase = DelayPhase.COUNTDOWN,
                endElapsedRealtime = active.endElapsedRealtime,
                durationSeconds = active.durationSeconds,
                remainingSeconds = DelayLogic.remainingSeconds(active.endElapsedRealtime, SystemClock.elapsedRealtime()),
                activeSourceName = active.sourceName,
                activeTrackName = active.trackName,
            )
        }
        startTicker(active.endElapsedRealtime)
    }

    private fun startTicker(endElapsedRealtime: Long) {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive && state.value.phase == DelayPhase.COUNTDOWN) {
                val remaining = DelayLogic.remainingSeconds(endElapsedRealtime, SystemClock.elapsedRealtime())
                mutableState.update { it.copy(remainingSeconds = remaining) }
                if (remaining <= 0) break
                delay(200L)
            }
        }
    }

    private fun showMessage(message: String) {
        mutableState.update { it.copy(message = message) }
    }

    override fun onCleared() {
        tickerJob?.cancel()
        super.onCleared()
    }
}
