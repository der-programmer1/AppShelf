package com.gymdelay.app

import android.service.notification.NotificationListenerService

/**
 * The service exists so Android can grant access to active media sessions.
 * GymDelay does not inspect, persist, or forward notification text.
 */
internal class GymMediaNotificationListenerService : NotificationListenerService()
