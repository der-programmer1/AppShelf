package com.gymdelay.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<GymDelayViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GymDelayTheme {
                GymDelayApp(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refresh()
    }
}

@Composable
private fun GymDelayApp(viewModel: GymDelayViewModel) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val requestNotifications = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (!granted) openAppNotificationSettings(context)
        viewModel.refresh()
    }

    val receiver = remember(viewModel) {
        object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                viewModel.onServiceState(intent)
            }
        }
    }
    DisposableEffect(context, receiver) {
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(MusicDelayService.ACTION_STATE),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        onDispose { context.unregisterReceiver(receiver) }
    }

    Scaffold(containerColor = GymBackground) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(GymBackground)
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { Header() }
            item {
                MediaCard(
                    state = state,
                    onMediaSettings = { openMediaAccessSettings(context) },
                    onNotificationSettings = {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            openAppNotificationSettings(context)
                        }
                    },
                )
            }
            item {
                DelayChooser(
                    selectedSeconds = state.selectedDelaySeconds,
                    enabled = state.phase == DelayPhase.IDLE,
                    onSelected = viewModel::selectDelay,
                )
            }
            item {
                if (state.phase == DelayPhase.COUNTDOWN) {
                    CountdownCard(state = state, onCancel = { viewModel.cancel(context) })
                } else {
                    StartCard(
                        enabled = state.hasMediaAccess && state.hasNotifications && state.mediaSession != null,
                        selectedSeconds = state.selectedDelaySeconds,
                        onStart = { viewModel.start(context) },
                    )
                }
            }
            state.message?.let { message ->
                item { MessageCard(message, onDismiss = viewModel::clearMessage) }
            }
            item { HowItWorksCard() }
            item { PrivacyCard() }
        }
    }
}

@Composable
private fun Header() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(GymAccent),
                contentAlignment = Alignment.Center,
            ) {
                Text("▶", color = GymBackground, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.size(12.dp))
            Column {
                Text("GYMDELAY", color = GymMuted, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Text("Bereit machen. Musik an.", color = GymText, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.8).sp)
            }
        }
        Text(
            "Dein Titel startet erst, wenn du wirklich bereit bist.",
            color = GymMuted,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 12.dp),
        )
    }
}

@Composable
private fun MediaCard(
    state: GymDelayUiState,
    onMediaSettings: () -> Unit,
    onNotificationSettings: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GymSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, GymLine),
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(42.dp).clip(CircleShape).background(GymSurfaceStrong),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("♫", color = GymAccent, fontSize = 24.sp)
                }
                Spacer(Modifier.size(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("AKTUELLE MUSIK", color = GymMuted, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = state.mediaSession?.title ?: "Noch keine Musik erkannt",
                        color = GymText,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Text(
                        text = state.mediaSession?.let { session ->
                            listOf(session.appName, session.artist).filter { it.isNotBlank() }.joinToString(" · ")
                        } ?: "Spotify oder eine andere Musik-App",
                        color = GymMuted,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                StatusDot(ready = state.hasMediaAccess && state.mediaSession != null)
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = GymLine)
            Spacer(Modifier.height(14.dp))

            when {
                !state.hasMediaAccess -> {
                    Text(
                        "Damit GymDelay Spotify und andere Musik-Apps steuern darf, musst du einmal den Medienzugriff aktivieren.",
                        color = GymMuted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                    )
                    OutlinedButton(onClick = onMediaSettings, modifier = Modifier.padding(top = 12.dp)) {
                        Text("Medienzugriff einrichten")
                    }
                }

                state.mediaSession == null -> {
                    Text(
                        "Öffne Spotify, wähle deinen Titel und pausiere ihn. Danach erscheint er hier.",
                        color = GymMuted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                    )
                }

                !state.hasNotifications -> {
                    Text(
                        "Für den Countdown im Hintergrund braucht GymDelay sichtbare Benachrichtigungen.",
                        color = GymMuted,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                    )
                    OutlinedButton(onClick = onNotificationSettings, modifier = Modifier.padding(top = 12.dp)) {
                        Text("Benachrichtigungen erlauben")
                    }
                }

                else -> {
                    Text("Bereit für deinen nächsten Satz.", color = GymAccent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun StatusDot(ready: Boolean) {
    Box(
        modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(if (ready) GymAccent else GymMuted.copy(alpha = 0.35f)),
    )
}

@Composable
private fun DelayChooser(selectedSeconds: Int, enabled: Boolean, onSelected: (Int) -> Unit) {
    Column {
        Text("DELAY WÄHLEN", color = GymMuted, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
        Text("Wie lange brauchst du noch?", color = GymText, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 13.dp)) {
            listOf(5, 10, 15, 30, 60).forEach { seconds ->
                DelayChip(seconds, selectedSeconds == seconds, enabled, onSelected)
            }
        }
    }
}

@Composable
private fun DelayChip(seconds: Int, selected: Boolean, enabled: Boolean, onSelected: (Int) -> Unit) {
    Surface(
        modifier = Modifier
            .width(62.dp)
            .clip(RoundedCornerShape(13.dp))
            .clickable(enabled = enabled) { onSelected(seconds) },
        color = if (selected) GymAccent else GymSurface,
        shape = RoundedCornerShape(13.dp),
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, GymLine),
    ) {
        Text(
            "$seconds s",
            color = if (selected) GymBackground else if (enabled) GymText else GymMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 12.dp),
        )
    }
}

@Composable
private fun StartCard(enabled: Boolean, selectedSeconds: Int, onStart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GymAccent),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("MUSIKSTART", color = GymBackground.copy(alpha = 0.7f), fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 4.dp)) {
                Text("$selectedSeconds", color = GymBackground, fontSize = 46.sp, fontWeight = FontWeight.Black)
                Text(" Sekunden", color = GymBackground, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 9.dp, start = 5.dp))
            }
            Button(
                onClick = onStart,
                enabled = enabled,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GymBackground,
                    contentColor = GymAccent,
                    disabledContainerColor = GymBackground.copy(alpha = 0.3f),
                    disabledContentColor = GymBackground.copy(alpha = 0.55f),
                ),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("Start drücken", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun CountdownCard(state: GymDelayUiState, onCancel: () -> Unit) {
    val progress = DelayLogic.progress(state.durationSeconds, state.endElapsedRealtime, android.os.SystemClock.elapsedRealtime())
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GymSurfaceStrong),
        border = androidx.compose.foundation.BorderStroke(1.dp, GymAccent.copy(alpha = 0.5f)),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth().padding(22.dp)) {
            Text("MUSIK STARTET IN", color = GymAccent, fontSize = 11.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "%02d".format(state.remainingSeconds.coerceAtLeast(0)),
                color = GymText,
                fontSize = 76.sp,
                lineHeight = 80.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 3.dp),
            )
            Text("${state.activeTrackName} · ${state.activeSourceName}", color = GymMuted, fontSize = 12.sp, maxLines = 1)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(CircleShape)
                    .background(GymBackground)
                    .padding(0.dp),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(7.dp)
                        .clip(CircleShape)
                        .background(GymAccent),
                )
            }
            OutlinedButton(onClick = onCancel, modifier = Modifier.padding(top = 18.dp)) {
                Text("Countdown abbrechen")
            }
        }
    }
}

@Composable
private fun MessageCard(message: String, onDismiss: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF283126)),
        shape = RoundedCornerShape(15.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 15.dp, end = 5.dp, top = 8.dp, bottom = 8.dp)) {
            Text(message, color = GymText, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("OK", color = GymAccent, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun HowItWorksCard() {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 5.dp)) {
        Text("SO FUNKTIONIERT ES", color = GymMuted, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        StepRow("01", "Musik vorbereiten", "Spotify öffnen, Titel wählen und pausieren.")
        StepRow("02", "Delay starten", "Zeit auswählen und auf Start drücken.")
        StepRow("03", "Loslegen", "Nach dem Countdown läuft dein Titel automatisch.")
    }
}

@Composable
private fun StepRow(number: String, title: String, description: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
        Text(number, color = GymAccent, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(30.dp))
        Column {
            Text(title, color = GymText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(description, color = GymMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun PrivacyCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.Transparent,
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GymLine),
    ) {
        Text(
            "Lokal und privat: GymDelay streamt keine Musik, braucht kein Konto und speichert keine Benachrichtigungstexte. Es steuert nur die freigegebene Musik-Session.",
            color = GymMuted,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            modifier = Modifier.padding(14.dp),
        )
    }
}

private fun openMediaAccessSettings(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun openAppNotificationSettings(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

private val GymBackground = Color(0xFF101310)
private val GymSurface = Color(0xFF1A211B)
private val GymSurfaceStrong = Color(0xFF222C22)
private val GymLine = Color(0xFF344034)
private val GymAccent = Color(0xFFB7F36B)
private val GymText = Color(0xFFF2F5EE)
private val GymMuted = Color(0xFFA5B0A2)

@Composable
private fun GymDelayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GymAccent,
            onPrimary = GymBackground,
            background = GymBackground,
            onBackground = GymText,
            surface = GymSurface,
            onSurface = GymText,
            outline = GymLine,
        ),
        content = content,
    )
}
