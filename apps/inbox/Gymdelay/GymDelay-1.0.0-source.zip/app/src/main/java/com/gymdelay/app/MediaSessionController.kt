package com.gymdelay.app

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat

internal data class MediaSessionInfo(
    val packageName: String,
    val appName: String,
    val title: String,
    val artist: String,
    val isPlaying: Boolean,
    val token: MediaSession.Token,
    val controller: MediaController,
)

internal class MediaSessionController(private val context: Context) {
    private val sessionManager = context.getSystemService(MediaSessionManager::class.java)
    private val listenerComponent = ComponentName(context, GymMediaNotificationListenerService::class.java)

    fun hasNotificationListenerAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun findActiveSession(): MediaSessionInfo? {
        if (!hasNotificationListenerAccess()) return null
        val controllers = runCatching {
            sessionManager?.getActiveSessions(listenerComponent).orEmpty()
        }.getOrDefault(emptyList())

        return controllers
            .firstOrNull { controller ->
                controller.playbackState?.state in setOf(
                    PlaybackState.STATE_PLAYING,
                    PlaybackState.STATE_PAUSED,
                    PlaybackState.STATE_BUFFERING,
                    PlaybackState.STATE_CONNECTING,
                )
            }
            ?.let(::toInfo)
    }

    fun pause(info: MediaSessionInfo): Boolean =
        runCatching {
            info.controller.transportControls.pause()
            true
        }.getOrDefault(false)

    private fun toInfo(controller: MediaController): MediaSessionInfo {
        val metadata = controller.metadata
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: ""
        val appName = runCatching {
            val appInfo = context.packageManager.getApplicationInfo(controller.packageName, 0)
            context.packageManager.getApplicationLabel(appInfo).toString()
        }.getOrDefault(controller.packageName)
        val playbackState = controller.playbackState?.state

        return MediaSessionInfo(
            packageName = controller.packageName,
            appName = appName,
            title = title.ifBlank { "Aktueller Titel" },
            artist = artist,
            isPlaying = playbackState == PlaybackState.STATE_PLAYING ||
                playbackState == PlaybackState.STATE_BUFFERING ||
                playbackState == PlaybackState.STATE_CONNECTING,
            token = controller.sessionToken,
            controller = controller,
        )
    }
}
