package com.gymdelay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.session.MediaController
import android.media.session.MediaSession
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal class MusicDelayService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var preferences: DelayPreferences
    private var countdownJob: Job? = null
    private var activeController: MediaController? = null
    private var activeEndElapsedRealtime: Long = 0L
    private var activeDurationSeconds: Int = 0
    private var activeSourceName: String = "Musik"
    private var activeTrackName: String = "Aktueller Titel"
    private var hasSettled = true

    override fun onCreate() {
        super.onCreate()
        preferences = DelayPreferences(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> cancelCountdown()
            ACTION_START -> startCountdown(intent)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startCountdown(intent: Intent) {
        countdownJob?.cancel()
        activeController = null
        preferences.clearActive()

        val token = readToken(intent)
        val end = intent.getLongExtra(EXTRA_END_ELAPSED, 0L)
        val duration = DelayLogic.safeDuration(intent.getIntExtra(EXTRA_DURATION_SECONDS, 30))
        if (token == null || end <= android.os.SystemClock.elapsedRealtime()) {
            sendState(STATE_FAILED, "Keine gültige Musik-Session für den Countdown gefunden.")
            stopSelf()
            return
        }

        val controller = runCatching { MediaController(this, token) }.getOrNull()
        if (controller == null) {
            sendState(STATE_FAILED, "Die Musik-Session ist nicht mehr verfügbar.")
            stopSelf()
            return
        }

        activeController = controller
        activeEndElapsedRealtime = end
        activeDurationSeconds = duration
        activeSourceName = intent.getStringExtra(EXTRA_SOURCE_NAME).orEmpty().ifBlank { "Musik" }
        activeTrackName = intent.getStringExtra(EXTRA_TRACK_NAME).orEmpty().ifBlank { "Aktueller Titel" }
        hasSettled = false
        preferences.saveActive(
            ActiveDelay(
                endElapsedRealtime = end,
                durationSeconds = duration,
                sourceName = activeSourceName,
                trackName = activeTrackName,
            ),
        )

        try {
            startForegroundCompat(buildNotification(DelayLogic.remainingSeconds(end, nowElapsedRealtime())))
        } catch (error: Exception) {
            finishWithFailure(error.message ?: "Der Countdown konnte nicht im Hintergrund gestartet werden.")
            return
        }

        sendState(STATE_COUNTDOWN, null, DelayLogic.remainingSeconds(end, nowElapsedRealtime()))
        countdownJob = serviceScope.launch {
            try {
                while (isActive) {
                    val remaining = DelayLogic.remainingSeconds(end, nowElapsedRealtime())
                    if (remaining <= 0) break
                    updateNotification(remaining)
                    sendState(STATE_COUNTDOWN, null, remaining)
                    delay(minOf(remaining * 1_000L, 1_000L))
                }

                val playSucceeded = runCatching {
                    val currentSession = MediaSessionController(this@MusicDelayService).findActiveSession()
                    val selectedController = activeController
                    val sessionStillMatches = currentSession == null || selectedController == null || (
                        currentSession.packageName == selectedController.packageName &&
                            currentSession.token == selectedController.sessionToken
                        )
                    if (sessionStillMatches) selectedController?.transportControls?.play()
                    sessionStillMatches && selectedController != null
                }.getOrDefault(false)
                if (playSucceeded) {
                    finish(STATE_COMPLETED, "Musik läuft jetzt.")
                } else {
                    finishWithFailure("Die Musik-Session war beim Ablauf nicht mehr verfügbar.")
                }
            } catch (_: CancellationException) {
                // A new start or explicit cancellation owns the next service state.
            } catch (error: Exception) {
                finishWithFailure(error.message ?: "Die Musik konnte nicht gestartet werden.")
            }
        }
    }

    private fun cancelCountdown() {
        if (hasSettled) {
            stopSelf()
            return
        }
        countdownJob?.cancel()
        finish(STATE_CANCELLED, "Countdown abgebrochen.")
    }

    private fun finish(state: String, message: String) {
        hasSettled = true
        countdownJob?.cancel()
        preferences.clearActive()
        sendState(state, message, 0)
        activeController = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun finishWithFailure(message: String) {
        finish(STATE_FAILED, message)
    }

    private fun updateNotification(remainingSeconds: Int) {
        getSystemService(NotificationManager::class.java)
            ?.notify(NOTIFICATION_ID, buildNotification(remainingSeconds))
    }

    private fun buildNotification(remainingSeconds: Int): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val cancelIntent = PendingIntent.getService(
            this,
            REQUEST_CANCEL,
            Intent(this, MusicDelayService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val safeRemaining = remainingSeconds.coerceAtLeast(0)
        val progress = (activeDurationSeconds - safeRemaining).coerceIn(0, activeDurationSeconds)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.delay_notification_title))
            .setContentText("$activeTrackName · startet in ${safeRemaining}s")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(activeDurationSeconds, progress, false)
            .addAction(R.drawable.ic_launcher, getString(R.string.notification_cancel), cancelIntent)
            .build()
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun sendState(state: String, message: String?, remainingSeconds: Int = 0) {
        sendBroadcast(
            Intent(ACTION_STATE).setPackage(packageName).apply {
                putExtra(EXTRA_STATE, state)
                putExtra(EXTRA_MESSAGE, message)
                putExtra(EXTRA_REMAINING_SECONDS, remainingSeconds)
                putExtra(EXTRA_END_ELAPSED, activeEndElapsedRealtime)
                putExtra(EXTRA_DURATION_SECONDS, activeDurationSeconds)
                putExtra(EXTRA_SOURCE_NAME, activeSourceName)
                putExtra(EXTRA_TRACK_NAME, activeTrackName)
            },
        )
    }

    private fun nowElapsedRealtime(): Long = android.os.SystemClock.elapsedRealtime()

    @Suppress("DEPRECATION")
    private fun readToken(intent: Intent): MediaSession.Token? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_TOKEN, MediaSession.Token::class.java)
        } else {
            intent.getParcelableExtra(EXTRA_TOKEN)
        }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.delay_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Zeigt den laufenden Musik-Countdown an."
                setShowBadge(false)
            },
        )
    }

    override fun onDestroy() {
        countdownJob?.cancel()
        serviceScope.cancel()
        if (!hasSettled) {
            preferences.clearActive()
            sendState(STATE_FAILED, "Der Countdown wurde vom System beendet.")
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.gymdelay.app.action.START"
        const val ACTION_CANCEL = "com.gymdelay.app.action.CANCEL"
        const val ACTION_STATE = "com.gymdelay.app.action.STATE"

        const val STATE_COUNTDOWN = "countdown"
        const val STATE_COMPLETED = "completed"
        const val STATE_CANCELLED = "cancelled"
        const val STATE_FAILED = "failed"

        const val EXTRA_TOKEN = "extra_token"
        const val EXTRA_END_ELAPSED = "extra_end_elapsed"
        const val EXTRA_DURATION_SECONDS = "extra_duration_seconds"
        const val EXTRA_SOURCE_NAME = "extra_source_name"
        const val EXTRA_TRACK_NAME = "extra_track_name"
        const val EXTRA_STATE = "extra_state"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_REMAINING_SECONDS = "extra_remaining_seconds"

        private const val CHANNEL_ID = "gym_delay_countdown"
        private const val NOTIFICATION_ID = 4101
        private const val REQUEST_OPEN = 4102
        private const val REQUEST_CANCEL = 4103
    }
}
