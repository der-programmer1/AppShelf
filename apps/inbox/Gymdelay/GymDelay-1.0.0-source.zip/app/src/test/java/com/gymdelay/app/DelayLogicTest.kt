package com.gymdelay.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DelayLogicTest {
    @Test
    fun remainingSecondsRoundsUpUntilTheCountdownEnds() {
        assertEquals(30, DelayLogic.remainingSeconds(30_000L, 0L))
        assertEquals(30, DelayLogic.remainingSeconds(30_000L, 1L))
        assertEquals(1, DelayLogic.remainingSeconds(30_000L, 29_001L))
        assertEquals(0, DelayLogic.remainingSeconds(30_000L, 30_000L))
    }

    @Test
    fun progressIsClampedToTheCountdownRange() {
        assertEquals(0f, DelayLogic.progress(30, 30_000L, 0L))
        assertTrue(DelayLogic.progress(30, 30_000L, 15_000L) in 0.4f..0.6f)
        assertEquals(1f, DelayLogic.progress(30, 30_000L, 30_000L))
        assertEquals(1f, DelayLogic.progress(30, 30_000L, 40_000L))
    }

    @Test
    fun durationIsLimitedToTheSupportedPresetWindow() {
        assertEquals(5, DelayLogic.safeDuration(1))
        assertEquals(30, DelayLogic.safeDuration(30))
        assertEquals(60, DelayLogic.safeDuration(120))
    }
}
