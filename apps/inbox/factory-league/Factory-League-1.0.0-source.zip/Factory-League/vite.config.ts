import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  root: "client", publicDir: "../public", plugins: [react()],
  build: { outDir: "../dist/client", emptyOutDir: true },
  server: { host: "0.0.0.0", port: 5173, strictPort: true, proxy: { "/api": "http://127.0.0.1:3001", "/health": "http://127.0.0.1:3001" } }
});
