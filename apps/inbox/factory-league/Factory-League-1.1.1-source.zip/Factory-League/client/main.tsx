import {StrictMode} from "react";
import {createRoot} from "react-dom/client";
import {BrowserRouter} from "react-router-dom";
import {SessionProvider} from "./session";
import App from "./App";
import "./style.css";
createRoot(document.getElementById("root")!).render(<StrictMode><BrowserRouter><SessionProvider><App/></SessionProvider></BrowserRouter></StrictMode>);
