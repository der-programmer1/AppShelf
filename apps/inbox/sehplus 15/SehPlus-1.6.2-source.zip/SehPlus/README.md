# SehPlus – Android Studio Projekt

SehPlus ist eine offline-first Alltagshilfe für Menschen mit Rot-Grün-Schwäche oder erschwerter Farbdifferenzierung. Die App hilft dabei, Farben im Alltag besser zu unterscheiden; sie ersetzt keine medizinische Untersuchung.

## Enthaltene Funktionen

- drei übersichtliche Bereiche: Kamera, Einstellungen und ÜBER
- große responsive Livebild-Vorschau mit kompaktem Filter-Dropdown direkt in der Kameraansicht; Livebilder füllen den Bereich proportional, Standbilder bleiben vollständig sichtbar
- Filterauswahl ohne überladene Werkzeugseite; Stärke sowie Helligkeit/Kontrast liegen unter „Filter anpassen“
- lokale Live-Kamera mit Filterprofilen und hochauflösendem Standbild
- Standbild-Zoom per Pinch, Plus/Minus, Doppeltippen und Zurücksetzen
- globale Normalansicht ohne Filter für Kamera, Standbild und Bilder
- Erkennungsmodus für Standbilder mit Testbild- und Whiteboard-Preset
- einheitlicher Standardbetrieb mit Kamera, Filter, Standbild, Pipette, Taschenlampe, Medienauswahl und Speichern
- Taschenlampe mit Ein/Aus und – wenn das Gerät es unterstützt – einstellbarer Helligkeit
- automatische Korrektur der Kameraausrichtung auf dem Gerät
- Standbildmodus mit Live/Standbild-Umschaltung
- ziehbare Offline-Pipette mit vergrößerter Messlupe, Farbnamen, HEX- und RGB-Werten
- Rot-Grün, Rot-Grün+, Blau-Gelb, Kontrast und Neutral
- Filterstärke und Helligkeit/Kontrast im aufklappbaren Filtermenü einstellbar
- Erkennungsstärke für verschobene Farben bei Testbildern und Whiteboards
- automatische Helligkeits-/Kontrastanpassung mit manueller Abschaltmöglichkeit
- robuste Pipettenmessung über eine wählbare kleine, mittlere oder große Fläche mit Farbfläche, HEX- und RGB-Werten
- verständliche Messqualitäts-Hinweise für dunkle, spiegelnde, gemischte oder uneinheitliche Flächen
- dominante Grundfarbe für Stoffe, Papier und strukturierte Oberflächen; Struktur wird nicht mehr automatisch als unbrauchbare Mischfarbe verworfen
- Sicherheitsstufe mit kurzer Begründung und dezentem Unterton, zum Beispiel `Grau · leicht bläulich`
- punktpriorisierte Pipette mit vorsichtiger automatischer Weißpunktkorrektur bei neutralen Bildbereichen
- alltagstaugliche Farbnamen wie Beige, Khaki und Ocker statt einer vorschnellen Orange-Zuordnung
- adaptive lokale Kontrastverstärkung im Testbild-Modus für Ishihara- und Punktbilder
- optionale Lichtkalibrierung der Pipette für die aktuelle Nutzungssitzung
- schnelleres Pipettenverhalten durch einmalige, lokale Lichtkorrektur pro Bild
- Offline-Testlabor mit Stoff-, Licht-, Kanten-, Punktbild- und Whiteboard-Beispielen ohne Kamera
- Zwei-Farben-Vergleich mit Helligkeit, Farbton und Farbabstand
- lokale Farbmemos ohne Foto sowie eine teilbare Farbkarte als reiner Text
- kurze 3-Schritt-Einweisung beim ersten Start mit Bedien-, Licht- und Pipettenhinweisen
- dauerhafter Licht-Hinweis direkt unter der Kameravorschau
- verständlicher Hinweis auf freiwillige Spenden im Onboarding und unter „Über"
- Feedback-Formular für Verbesserungsvorschläge im Onboarding und unter „Über"
- modernisierte „Über“-Seite mit Hero-Bereich, Status-Badges, Schnellaktionen, Feature-Kacheln und aufklappbaren Bereichen
- vorbereiteter Workflow zur täglichen Feedback-Auswertung mit ChatGPT und Google Sheets
- Standbild-Timeout mit Rückfall auf die letzte Live-Vorschau, falls die Hochauflösungsaufnahme nicht rechtzeitig zurückkommt
- erneuter Versuch für hochauflösende Standbilder nach einem Timeout
- klarer Kamerafehler-Zustand mit nutzbarem letztem Bild und Kamera-Neustart
- verständliche Content-Descriptions für die wichtigsten Kamera-, Pipetten- und Ansichtsaktionen
- haptisches Feedback für Pipette und Zoom, abschaltbar
- Akku- und Performance-Anzeige ohne Hintergrunddienst
- Bildauswahl aus der Galerie
- Videoauswahl mit lokalem Einzelbild-/Positionsregler zur Prüfung verschiedener Videostellen
- Original/angepasste Vorschau innerhalb der App
- Speichern der aktuell angezeigten Ansicht unter `Pictures/SehPlus`
- keine Internet-Berechtigung, kein Konto und kein API-Schlüssel
- sichtbarer Hinweis, dass der Filter keine medizinische Diagnose ersetzt
- in der App erreichbarer Bereich „Datenschutz & Rechtliches“ mit lokaler Kurzinfo sowie Links zu Datenschutzerklärung und Impressum
- lokaler technischer Testbericht über das Android-Teilen-Menü, ohne Bilder oder persönliche Inhalte
- portables Profil `SehPlus ColorAssist v2` als `app/src/main/assets/sehplus_color_assist_v2.json`
- kostenlose lokale PWA für moderne Browser unter `web/`, mit denselben Kernprofilen und ohne Bild-Upload

## Auf dem Mac öffnen

1. ZIP entpacken.
2. Android Studio öffnen.
3. **Open** wählen und den Ordner `SehPlus` auswählen – dort liegt `settings.gradle`.
4. Den Gradle-Sync abwarten und danach **Run** auf einem Android-Gerät oder Emulator drücken.
5. Für die Live-Kamera in der App **KAMERA STARTEN** wählen und die Kamera-Berechtigung erlauben.

Android Studio lädt beim ersten Sync nur die normalen Build-Werkzeuge und Gradle-Abhängigkeiten. SehPlus selbst nutzt keine Cloud-API und sendet keine Bilder ins Internet.

Das Projekt verwendet Android Gradle Plugin 9.4.0 und ist damit für Gradle 9.6.0 vorbereitet.

## Hinweise zur Verwendung

Die Filter und die Pipette sind visuelle Hilfen. Die genaue Wirkung hängt von Display, Licht, Kamera und individueller Farbwahrnehmung ab. Die HEX- und RGB-Werte der Pipette sind verlässlicher als der ungefähre Grundfarbname. Eine Lichtkalibrierung kann warmes oder ungleichmäßiges Licht ausgleichen, ist aber keine laborgenaue Farbmessung.

SehPlus verarbeitet die Kamera lokal und startet keine Aufzeichnung. Die Helligkeitsregelung der Taschenlampe hängt vom Kameramodul und der Android-Version ab; ältere oder einfachere Geräte bieten nur Ein/Aus.

Die Video-Funktion arbeitet in dieser ersten Version bewusst mit Einzelbildern: Der Regler sucht lokale Videoframes und filtert den gewählten Frame. Dadurch bleibt die App klein und benötigt keine externe Videobibliothek.

## Geschlossene Testphase

Über **ÜBER → ENTWICKLER & VERSION → TESTBERICHT TEILEN** erstellt SehPlus einen technischen Bericht mit Version, Gerät, Android-Version, Farbprofil und Kamerastatus. Es werden keine Fotos oder persönlichen Inhalte angehängt. Android öffnet anschließend das normale Teilen-Menü; der Bericht kann direkt an die eigene E-Mail, WhatsApp, Notizen oder einen anderen Kanal gesendet werden. Wenn kein Teilen-Programm verfügbar ist, wird der Text in die Zwischenablage kopiert.

Für einen ersten Test sollten das Nothing Phone und zwei bis drei weitere Android-Geräte verwendet werden. Besonders wichtig sind Kamerastart, Unterbrechung, Kamerafehler, Standbild, Pipette unter verschiedenem Licht, Kalibrierung, Testbilder und Whiteboard-Modus.

Die vollständige Checkliste liegt in `TESTCHECKLIST.md`. Für die Pipette sollten ausdrücklich Handtücher, Kleidung, Papier, Holz und ungleichmäßig beleuchtete Flächen geprüft werden; die Messfläche kann dafür zwischen Klein, Mittel und Groß gewechselt werden.

## Launch-Reihenfolge

1. Android-Version 1.6.1 auf dem Nothing Phone und mindestens zwei weiteren Geräten als geschlossenen Test prüfen.
2. Spenden-Link, Feedback-Link, Datenschutzkontakt und Impressum einsetzen und testen.
3. In `app/build.gradle` prüfen, dass `targetSdk 36` gesetzt ist.
4. Eine signierte APK als GitHub Release veröffentlichen.
5. Ein signiertes AAB im Google Play Console-internen Test prüfen.
6. Die PWA über GitHub Pages veröffentlichen und erst danach den Instagram-Link teilen.

## Wiederverwendbares Farbfilterprofil

`SehPlus ColorAssist v2` (`sehplus_color_assist_v2`) beschreibt die fünf Profile Rot-Grün, Rot-Grün+, Blau-Gelb, Kontrast und Neutral sowie die lokalen Erkennungsmodi `test_image` und `whiteboard`. Rot-Grün und Rot-Grün+ verwenden eine stufenlose Daltonisierung; die Erkennungsmodi verschieben Farben stärker zugunsten von Blau-Gelb- und Helligkeitsunterschieden. Die JSON-Datei kann in anderen Projekten als lokale Profilquelle übernommen werden.

## Build-Status

Die Java-Quellen von Version 1.6.1 wurden mit JDK 17 gegen Android API 36 syntaktisch kompiliert. Der vollständige Gradle-/APK-Build muss nach dem Import in Android Studio oder auf einer Build-Umgebung mit kompatiblem Android-Build-Tool ausgeführt werden. Nach dem Import bitte synchronisieren, mit **Run** auf einem Gerät testen und anschließend die Debug- oder Release-APK bauen.

## Freiwillige Spende

Die App öffnet für freiwillige Unterstützung den externen Link `https://buymeacoffee.com/sehplus`. Vor der Veröffentlichung muss geprüft werden, dass diese öffentliche Seite tatsächlich eingerichtet ist; falls dein Profil eine andere Adresse hat, muss sie in `MainActivity.java` und `web/app.js` ersetzt werden. Die App verarbeitet keine Zahlungsdaten und benötigt dafür keine Internet-Berechtigung.

## Rechtlicher Launch-Check

Vor dem ersten öffentlichen Launch müssen alle folgenden Punkte erledigt sein:

- `web/impressum.html` mit deinem vollständigen Namen, deiner ladungsfähigen Anschrift und einer erreichbaren Kontakt-E-Mail ausfüllen.
- `web/privacy.html` mit denselben Verantwortlichen-/Datenschutzkontaktdaten vervollständigen.
- In der Android-App im Bereich `ÜBER → DATENSCHUTZ & RECHTLICHES` die echten Kontaktdaten sowie die öffentlichen Datenschutz- und Impressum-URLs in `MainActivity.java` einsetzen.
- In `MainActivity.java` und `web/app.js` den Platzhalter `DEIN_FORMULAR_ID` durch den echten Google-Forms-Antwort-Link ersetzen.
- Den Spenden-Link auf einem echten Gerät und in der PWA testen.
- Nur eigene oder nachweisbar lizenzierte Bilder, Testbilder, Icons, Fonts und Store-Screenshots verwenden.
- In der Play Console Datenschutzerklärung, Data-Safety-Angaben, Zielgruppe, Altersfreigabe und Werbeangabe vollständig ausfüllen.

Die aktuellen Platzhalter sind absichtlich sichtbar markiert, damit die App nicht versehentlich mit falschen oder erfundenen Kontaktdaten veröffentlicht wird.

## Web-App für Apple-Nutzer

Unter `web/` liegt eine eigenständige, buildless PWA. Sie kann kostenlos über GitHub Pages veröffentlicht und anschließend über Instagram oder einen anderen Link geteilt werden. Die PWA verarbeitet Kamera- und Bilddaten lokal im Browser und benötigt kein Konto. Für die Kamera muss die Seite über HTTPS geöffnet werden. Die Taschenlampe wird nur angeboten, wenn der Browser sie unterstützt; Safari bietet diese Steuerung nicht auf jedem Gerät an.

Für GitHub Pages kann der Workflow in `.github/workflows/deploy-pages.yml` verwendet werden. Nach der Veröffentlichung kann die Seite in Safari über „Zum Home-Bildschirm“ installiert werden.

## Feedback-Formular einrichten

Die App öffnet für Verbesserungsvorschläge ein externes Google-Forms-Formular. Im Quelltext steht zunächst nur dieser Platzhalter:

`https://docs.google.com/forms/d/e/DEIN_FORMULAR_ID/viewform`

Vor der Veröffentlichung musst du in `app/src/main/java/com/sehplus/app/MainActivity.java` die Konstante `FEEDBACK_FORM_URL` durch den echten Antwort-Link ersetzen.

1. Unter [Google Forms](https://forms.google.com) ein leeres Formular erstellen.
2. Titel setzen: `SehPlus – Verbesserungsvorschlag`.
3. Diese Fragen hinzufügen: `Was möchtest du verbessern?` (Absatz, erforderlich), `Was ist passiert oder was hast du erwartet?` (Absatz, optional) und `Gerät und Android-Version` (kurze Antwort, optional).
4. Keine Datei-Uploads und keine verpflichtende Google-Anmeldung aktivieren; E-Mail-Adressen nicht automatisch sammeln.
5. Unter „Antworten“ mit Google Sheets verbinden und E-Mail-Benachrichtigungen für neue Antworten aktivieren.
6. Den „Antworten-Link“ kopieren und in `FEEDBACK_FORM_URL` einsetzen.
7. Den Link in einem privaten Browserfenster ohne Google-Anmeldung testen.

Die offiziellen Google-Hinweise erklären das [Teilen und Veröffentlichen](https://support.google.com/docs/answer/2839588?hl=de), das [Speichern in Google Sheets](https://support.google.com/docs/answer/2917686) und [Benachrichtigungen zu Antworten](https://support.google.com/docs/answer/139706?hl=de). Die Kamera- und Bildverarbeitung der App bleibt lokal; nur ein bewusst ausgefülltes Formular wird an Google Forms gesendet.

## Feedback mit ChatGPT auswerten

Der vorbereitete Ablauf steht in [`FEEDBACK_WORKFLOW.md`](FEEDBACK_WORKFLOW.md). Kurz gesagt: Google Forms speichert die Antworten in Google Sheets, und ChatGPT kann die freigegebene Tabelle über Google Drive morgens nach neuen Antworten prüfen. Die Auswertung erstellt Kategorien, Prioritäten und konkrete Update-Vorschläge; Code wird erst nach deiner Bestätigung geändert.

Dafür muss die Google-Drive-Verbindung in ChatGPT/Codex einmal mit deinem Google-Konto autorisiert werden. Die Verbindung ist nicht automatisch eingerichtet und erhält nur die Berechtigungen, die du bestätigst. Wenn geplante Aufgaben in deinem Konto nicht verfügbar sind, kannst du den im Workflow dokumentierten Analyse-Prompt jederzeit manuell verwenden.
