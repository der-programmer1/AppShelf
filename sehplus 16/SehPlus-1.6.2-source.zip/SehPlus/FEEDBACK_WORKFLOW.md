# SehPlus-Feedback mit ChatGPT auswerten

## Status

Der Workflow ist vorbereitet. Die Google-Drive-Verbindung muss einmal in ChatGPT/Codex mit dem Google-Konto autorisiert werden. Danach kann die verbundene Google-Sheets-Tabelle als Feedback-Quelle verwendet werden.

## Datenfluss

1. Nutzer senden Feedback über das Google-Formular.
2. Google Forms speichert die Antworten in einer verknüpften Google-Sheets-Tabelle.
3. ChatGPT liest nur diese freigegebene Tabelle über Google Drive.
4. Neue Antworten werden morgens gebündelt ausgewertet.
5. Die Ergebnisse werden als priorisierte Update-Ideen ausgegeben.
6. Code wird erst nach deiner Bestätigung geändert.

## Einrichtung

1. Im Google-Formular unter **Antworten** auf **Mit Google Sheets verknüpfen** klicken.
2. In ChatGPT/Codex die Google-Drive-Verbindung öffnen und dein Google-Konto autorisieren.
3. Nur Zugriff auf die Feedback-Tabelle freigeben, sofern die Oberfläche eine Dateiauswahl anbietet.
4. Ein Projekt namens `SehPlus Feedback` anlegen.
5. Die folgende Projektanweisung einfügen.
6. Eine tägliche Aufgabe für den Morgen einrichten, zum Beispiel 08:00 Uhr Europe/Berlin.

## Projektanweisung

```text
Analysiere jeden Morgen die neuen Antworten in der verbundenen SehPlus-Feedback-Tabelle.

Ignoriere bereits ausgewertete Antworten. Gruppiere ähnliche Rückmeldungen und ordne sie den Kategorien Fehler, Farberkennung, Bedienung, Feature-Wunsch oder Lob zu.

Priorisiere:
P0 = Absturz oder App unbenutzbar
P1 = wichtige falsche Farb- oder Pipettenmessung
P2 = deutliche Bedienungs- oder Verständlichkeitsprobleme
P3 = optionale Verbesserung

Erstelle:
1. eine kurze Zusammenfassung,
2. die drei wichtigsten Probleme,
3. die Anzahl ähnlicher Rückmeldungen,
4. konkrete Lösungsvorschläge,
5. einen empfohlenen Plan für das nächste Update,
6. offene Fragen oder notwendige Tests.

Trenne echte Fehler von persönlichen Wünschen. Erfinde keine Ursachen und kennzeichne Vermutungen ausdrücklich. Ändere keinen Code automatisch. Warte auf meine Bestätigung, bevor eine Umsetzung beginnt. Verwende keine persönlichen Daten aus dem Feedback.

Wenn keine neuen Antworten vorhanden sind, gib nur aus: „Keine neuen SehPlus-Feedbacks seit der letzten Auswertung.“
```

## Sicherheits- und Datenschutzregeln

- Keine Fotos, medizinischen Diagnosen oder privaten Kontaktdaten im Formular anfordern.
- E-Mail-Adressen der Teilnehmer nicht automatisch sammeln.
- Nur die Feedback-Tabelle mit ChatGPT teilen, nicht den gesamten Google-Drive-Inhalt.
- Vorschläge vor der Umsetzung prüfen; die Auswertung darf keine automatische Codeänderung auslösen.

## Fallback ohne automatische Aufgabe

Wenn geplante Aufgaben in deinem Konto nicht verfügbar sind, verbinde Google Drive trotzdem und schreibe morgens:

```text
Analysiere die neuen SehPlus-Feedbacks in der verbundenen Google-Tabelle und erstelle den Plan für das nächste Update.
```

Alternativ kann die Tabelle als CSV exportiert und zur Auswertung hochgeladen werden.
