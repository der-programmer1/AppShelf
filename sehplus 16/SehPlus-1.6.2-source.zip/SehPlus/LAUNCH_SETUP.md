# SehPlus – letzte Angaben vor dem Launch

Die folgenden Angaben dürfen nicht erfunden werden und müssen vor der öffentlichen Veröffentlichung einmal eingesetzt und getestet werden.

## 1. Spendenlink

Der aktuelle Standardlink ist:

`https://buymeacoffee.com/sehplus`

Rufe ihn auf dem Telefon und im Browser auf. Falls dein eingerichtetes Profil eine andere Adresse hat, ändere sie in:

- `app/src/main/java/com/sehplus/app/MainActivity.java` → `DONATION_URL`
- `web/app.js` → `CONFIG.donationUrl`

Die App verarbeitet keine Zahlungsdaten. Die Zahlung findet ausschließlich beim externen Anbieter statt.

## 2. Feedback-Link

Ersetze in beiden Dateien den kompletten Platzhalter durch den öffentlichen Google-Forms-Antwort-Link:

- `app/src/main/java/com/sehplus/app/MainActivity.java` → `FEEDBACK_FORM_URL`
- `web/app.js` → `CONFIG.feedbackUrl`

Danach den Link in einem privaten Browserfenster und auf dem Android-Gerät testen.

## 3. Impressum und Datenschutzkontakt

In `web/impressum.html` und `web/privacy.html` eintragen:

- vollständiger Name
- ladungsfähige Anschrift
- erreichbare E-Mail-Adresse

Keine Platzhalter, Fantasieadressen oder fremde Kontaktdaten verwenden.

Zusätzlich in `app/src/main/java/com/sehplus/app/MainActivity.java` eintragen:

- `PRIVACY_URL` mit der öffentlich erreichbaren Datenschutzerklärung
- `IMPRINT_URL` mit dem öffentlich erreichbaren Impressum
- `LEGAL_RESPONSIBLE_NAME`, `LEGAL_RESPONSIBLE_ADDRESS` und `LEGAL_CONTACT_EMAIL`

Die Android-App zeigt den Bereich unter **ÜBER → DATENSCHUTZ & RECHTLICHES**. Solange Platzhalter vorhanden sind, öffnen die Buttons keine erfundene Adresse und der Launch-Check bleibt absichtlich rot.

## 4. Google Play

- `targetSdk 36` beibehalten.
- Datenschutzerklärung als öffentlich erreichbare URL eintragen.
- Data-Safety-Formular wahrheitsgemäß ausfüllen.
- Kamera als notwendige Kernfunktion erklären.
- Keine Werbung angeben, wenn keine Werbung enthalten ist.
- Release-Keystore sicher außerhalb des Projekts sichern.

## 5. Letzter Test

Erst veröffentlichen, wenn eine saubere Release-Installation funktioniert und alle Links, Kamera, Standbild, Pipette, Filter und Datenschutzseiten geprüft wurden.
