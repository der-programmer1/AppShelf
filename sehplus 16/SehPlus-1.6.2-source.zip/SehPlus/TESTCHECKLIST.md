# SehPlus 1.6.0 – geschlossene Testphase

## Installation

1. Projektordner `SehPlus` in Android Studio öffnen.
2. Gradle-Sync abwarten.
3. Auf dem Gerät installieren und die Kamera-Berechtigung zunächst erlauben.
4. Optional anschließend den Test noch einmal mit verweigerter Berechtigung wiederholen.

## Erste Einweisung und Unterstützung

- Beim ersten Start erscheinen drei kurze Einweisungsschritte.
- Prüfen, dass der Einfluss von Umgebungslicht auf Aufnahme und Farberkennung erklärt wird.
- Prüfen, dass die freiwillige Spende verständlich erklärt wird und keine Voraussetzung ist.
- Prüfen, dass `SPÄTER` und `ÜBERSPRINGEN` die App ohne Spenden- oder Feedbackaktion erreichbar machen.
- `FREIWILLIG SPENDEN` testen; der eigene externe Spenden-Link muss den Browser öffnen.
- `FEEDBACK SENDEN` testen; der echte Google-Forms-Link muss den Browser öffnen.
- Unter `ÜBER` die Einweisung erneut öffnen sowie Spenden- und Feedback-Link erneut testen.
- Das Formular in einem privaten Browserfenster ohne Google-Anmeldung öffnen und eine Testantwort absenden.
- In Google Forms prüfen, dass die Testantwort unter „Antworten“ erscheint und die konfigurierte Benachrichtigung ankommt.

### Über-Seite und Abstände

- Prüfen, dass der Hero-Bereich SehPlus-Icon, Tagline und die Badges `OFFLINE`, `LOKAL` und `KEIN KONTO` ruhig und vollständig darstellt.
- Prüfen, dass die Schnellaktionen als zwei klar getrennte Karten erscheinen und ihre Kurzbeschreibungen verständlich sind.
- Prüfen, dass die drei Feature-Kacheln `FILTER`, `PIPETTE` und `STANDBILD` ohne Abschneiden sichtbar sind.
- Prüfen, dass die zwei Schnellaktionen `FREIWILLIG SPENDEN` und `FEEDBACK SENDEN` direkt sichtbar sind.
- Prüfen, dass `SCHNELLZUGRIFF` als eigene Gruppe erkennbar ist und die beiden Buttons durch Abstand getrennt sind.
- Prüfen, dass zunächst nur `ÜBER SEHPLUS` geöffnet ist und die anderen Bereiche geschlossen sind.
- Jeden Akkordeon-Bereich öffnen und prüfen, dass sich der vorherige Bereich automatisch schließt.
- Prüfen, dass zwischen den Akkordeon-Bereichen dezente Trennlinien und ausreichend Abstand sichtbar sind.
- Prüfen, dass der farbige Seitenmarker geöffnete und geschlossene Bereiche ruhig unterscheidbar macht.
- Prüfen, dass im Entwicklerbereich Versions-Badge und persönlicher Entwicklerhinweis getrennt lesbar sind.
- Die gesamte Über-Seite bis `TESTBERICHT TEILEN` scrollen und prüfen, dass kein Inhalt von der unteren Navigation verdeckt wird.
- Auf einem kleineren Gerät kontrollieren, dass Karten nicht aneinanderkleben und alle Buttons erreichbar bleiben.

### Feedback-Auswertung

- Google-Formular mit einer Google-Sheets-Tabelle verbinden.
- Google-Drive-Verbindung in ChatGPT/Codex autorisieren und nur die Feedback-Tabelle freigeben.
- Eine Testantwort senden und prüfen, ob sie in der Tabelle erscheint.
- Den Analyse-Prompt aus `FEEDBACK_WORKFLOW.md` ausführen.
- Prüfen, dass Feedback kategorisiert und priorisiert wird und keine automatische Codeänderung erfolgt.

### Live-Kameravorschau

- Kamera starten und prüfen, dass das Livebild den großen Vorschau-Bereich vollständig ausfüllt.
- Prüfen, dass das Livebild proportional bleibt und nicht verzerrt wird.
- Prüfen, dass keine großen schwarzen Leerflächen neben oder unter dem Livebild entstehen.
- Prüfen, dass das Standbild weiterhin vollständig sichtbar bleibt und nicht zugeschnitten wird.
- Zwischen `STANDBILD` und `WEITER LIVE` wechseln und kontrollieren, dass die Darstellung jeweils korrekt angepasst wird.
- Im Standbild Zoom und Pipette prüfen; der Pipettenpunkt muss trotz Live-Zuschneiden korrekt zur Bildstelle passen.

## Kernablauf

- Kamera starten und prüfen, ob das Bild aufrecht angezeigt wird.
- `FILTER` öffnen und zwischen `Rot-Grün+`, `Rot-Grün`, `Kontrast` und `Neutral` wechseln.
- Standbild aufnehmen und Zoom per Plus, Minus, Pinch und Doppeltippen prüfen.
- `PIPETTE` aktivieren und über eine matte rote, grüne, blaue, gelbe, orange, weiße, graue und schwarze Fläche ziehen.
- Prüfen, ob Grundfarbe, Unterton, Sicherheit, HEX/RGB und Messhinweis verständlich sind.
- Prüfen, ob die Messqualität bei dunklen, spiegelnden, gemischten und uneinheitlichen Flächen verständlich erklärt wird.
- Bei einem Handtuch, Kleidungsstück oder strukturierten Stoff den Punkt auf eine gleichmäßige Stelle setzen und `MESSFLÄCHE` mit Klein, Mittel und Groß vergleichen.
- Prüfen, dass eine strukturierte Fläche als dominante Grundfarbe ausgegeben wird und nicht nur als unbrauchbare Mischfarbe.
- Beige Stoffe, sandfarbene Flächen und warme graue Materialien prüfen; die Namen sollen alltagstauglich und nicht pauschal „Orange“ sein.
- Bei farbigem Raumlicht prüfen, ob die App nur bei ausreichender Sicherheit vorsichtig korrigiert und sonst die Originalmessung beibehält.
- Den dauerhaften Licht-Hinweis unter der Kameravorschau lesen und prüfen, dass er auch ohne Bild verständlich ist.

## Pipette und Lichtkalibrierung

1. Eine matte weiße oder neutrale graue Fläche unter dem aktuellen Licht anzeigen.
2. Den Pipettenpunkt auf die Fläche ziehen.
3. `LICHT KALIBRIEREN` öffnen und die Kalibrierung übernehmen.
4. Eine farbige Fläche erneut messen und prüfen, ob die Ausgabe stabil bleibt.
5. `KALIBRIERUNG ZURÜCKSETZEN` auswählen und die Änderung prüfen.
6. Eine glänzende oder gemischte Fläche testen; sie sollte weiterhin eine niedrigere Sicherheit und einen verständlichen Hinweis erhalten.

## Kamera- und Standbildfehler

- Kamera während der Nutzung durch eine andere App unterbrechen.
- Prüfen, dass kein `WEITER LIVE` zusammen mit einem Kamerafehler stehen bleibt.
- Prüfen, dass das letzte Bild als statisches Bild erhalten bleibt.
- Pipette, Zoom und Erkennung auf dem letzten Bild testen.
- `KAMERA NEU STARTEN` wählen und prüfen, ob ein neuer Live-Start möglich ist.
- Bei einem Standbild-Timeout den Button `HOCHAUFLÖSEND ERNEUT VERSUCHEN` testen.

## Erkennung im Standardbetrieb

- Auf einem Testbild `ERKENNUNG · Testbild` wählen und Zahlen/Punkte vergleichen.
- Mehrere Ishihara-/Punktbilder mit hellem Hintergrund prüfen: Hintergrund soll hell bleiben, Punkte und Zahlen sollen kontrastreicher werden und nicht zu einer schwarzen Gesamtfläche verschmelzen.
- Auf einem Whiteboard oder Blatt `ERKENNUNG · Whiteboard` wählen.
- Prüfen, dass Kamera, Filter, Standbild, Pipette, Taschenlampe, Medienauswahl und Speichern im Standardbetrieb verfügbar bleiben.

## Testbericht senden

1. `ÜBER` öffnen.
2. `TESTBERICHT TEILEN` wählen.
3. Den Bericht an die eigene E-Mail, WhatsApp oder Notizen senden.
4. Prüfen, dass keine Fotos oder persönlichen Inhalte enthalten sind.

## Web/PWA

- `web/index.html` über HTTPS öffnen und die kurze Einweisung beim ersten Start prüfen.
- Kamera, Bildauswahl, Standbild, Filter, Farben verschieben, Zoom und Pipette im Browser testen.
- Auf iPhone-Safari „Zum Home-Bildschirm“ verwenden und den Start im Standalone-Modus prüfen.
- Nach dem ersten Laden den Flugmodus aktivieren und prüfen, dass die PWA ohne Kamera weiterhin öffnet und lokale Bilder verarbeitet.
- Prüfen, dass die Taschenlampe bei nicht unterstützten Browsern verständlich als nicht verfügbar angezeigt wird.
- Prüfen, dass Datenschutzseite und Impressum erreichbar sind und vor dem Launch keine Platzhalter mehr enthalten.
- Den GitHub-Pages-Workflow ausführen und die veröffentlichte HTTPS-Adresse auf iPhone und Android öffnen.

## Offline-Testlabor und Farbwerkzeuge

- `ÜBER → OFFLINE-TESTLABOR` öffnen und jedes Beispiel ohne Kamerazugriff laden.
- Bei Stoff- und Kantenbildern die Messfläche `Klein`, `Mittel` und `Groß` vergleichen.
- `ZWEI FARBEN VERGLEICHEN` wählen, Punkt A und Punkt B antippen und Helligkeit, Farbton sowie Farbabstand prüfen.
- Eine Messung mit `MESSUNG MERKEN` speichern und unter `ÜBER → LOKALE FARBNOTIZEN` wiederfinden.
- `FARBKARTE TEILEN` testen; es darf nur Text mit Farbname, HEX/RGB und Sicherheit geteilt werden, kein Foto.
- Die Werkzeuge bei normalem Licht und warmem Innenlicht testen und die automatische Lichtkorrektur mit einer neutralen Fläche vergleichen.

## Fehler melden

Für jeden Fehler notieren:

- Was wurde erwartet?
- Was ist tatsächlich passiert?
- Welcher Bildschirm und welches Farbprofil waren aktiv?
- War die Pipettenfläche matt, glänzend oder gemischt?
- Testbericht aus der App mitsenden.
