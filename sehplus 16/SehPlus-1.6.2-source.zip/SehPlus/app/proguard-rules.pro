# SehPlus v1 intentionally ships without code shrinking.
