package com.sehplus.app;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Offline analyzer for the dominant colour of a local image area.
 * It deliberately separates material texture and brightness changes from
 * genuinely different hue groups, which is useful for fabric and paper.
 */
final class ColorAnalyzer {
    private static final int HUE_BINS = 36;

    enum AreaSize {
        SMALL("Klein", 48),
        MEDIUM("Mittel", 78),
        LARGE("Groß", 124);

        final String label;
        final int diameterDp;

        AreaSize(String label, int diameterDp) {
            this.label = label;
            this.diameterDp = diameterDp;
        }
    }

    enum Confidence {
        HIGH("hoch"),
        MEDIUM("mittel"),
        LOW("niedrig");

        final String label;

        Confidence(String label) {
            this.label = label;
        }
    }

    static final class Result {
        final int color;
        final String baseName;
        final String undertone;
        final Confidence confidence;
        final String reason;
        final int sampleCount;
        final boolean mixed;
        final float saturation;
        final float value;
        final float dominantRatio;

        Result(int color, String baseName, String undertone, Confidence confidence,
               String reason, int sampleCount, boolean mixed, float saturation,
               float value, float dominantRatio) {
            this.color = color;
            this.baseName = baseName;
            this.undertone = undertone;
            this.confidence = confidence;
            this.reason = reason;
            this.sampleCount = sampleCount;
            this.mixed = mixed;
            this.saturation = saturation;
            this.value = value;
            this.dominantRatio = dominantRatio;
        }

        String displayName() {
            return undertone.isEmpty() ? baseName : baseName + " · " + undertone;
        }
    }

    private static final class Sample {
        final int color;
        final float hue;
        final float saturation;
        final float value;
        final float weight;
        final float distanceFromCenter;

        Sample(int color, float hue, float saturation, float value,
               float weight, float distanceFromCenter) {
            this.color = color;
            this.hue = hue;
            this.saturation = saturation;
            this.value = value;
            this.weight = weight;
            this.distanceFromCenter = distanceFromCenter;
        }
    }

    private ColorAnalyzer() { }

    static Result analyze(Bitmap source, int centerX, int centerY, int radius,
                          float redGain, float greenGain, float blueGain) {
        if (source == null || source.isRecycled() || source.getWidth() <= 0 || source.getHeight() <= 0) {
            return new Result(Color.BLACK, "Schwarz", "", Confidence.LOW,
                    "keine Bildfläche", 0, true, 0f, 0f, 0f);
        }
        int safeRadius = Math.max(2, Math.min(radius,
                Math.max(2, Math.min(source.getWidth(), source.getHeight()) / 3)));
        List<Sample> samples = new ArrayList<>();
        for (int y = Math.max(0, centerY - safeRadius); y <= Math.min(source.getHeight() - 1, centerY + safeRadius); y++) {
            for (int x = Math.max(0, centerX - safeRadius); x <= Math.min(source.getWidth() - 1, centerX + safeRadius); x++) {
                float dx = x - centerX;
                float dy = y - centerY;
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                if (distance > safeRadius) continue;
                int raw = source.getPixel(x, y);
                int corrected = Color.rgb(
                        clamp(Math.round(Color.red(raw) * clampGain(redGain))),
                        clamp(Math.round(Color.green(raw) * clampGain(greenGain))),
                        clamp(Math.round(Color.blue(raw) * clampGain(blueGain))));
                float[] hsv = new float[3];
                Color.colorToHSV(corrected, hsv);
                float centerWeight = 1f - Math.min(1f, distance / Math.max(1f, safeRadius));
                samples.add(new Sample(corrected, hsv[0], hsv[1], hsv[2],
                        .55f + centerWeight * .45f, distance));
            }
        }
        if (samples.isEmpty()) {
            return new Result(Color.BLACK, "Schwarz", "", Confidence.LOW,
                    "keine Bildfläche", 0, true, 0f, 0f, 0f);
        }

        float[] luminances = new float[samples.size()];
        int neutralCount = 0;
        for (int index = 0; index < samples.size(); index++) {
            Sample sample = samples.get(index);
            luminances[index] = luminance(sample.color);
            if (sample.saturation < .20f) {
                neutralCount++;
            }
        }
        float neutralRatio = neutralCount / (float) samples.size();
        int centerWindow = Math.max(2, Math.round(safeRadius * .18f));
        List<Sample> centerSamples = new ArrayList<>();
        for (Sample sample : samples) {
            if (sample.distanceFromCenter <= centerWindow) centerSamples.add(sample);
        }
        if (centerSamples.isEmpty()) centerSamples.add(samples.get(0));
        float centerNeutralRatio = 0f;
        float centerHueSin = 0f;
        float centerHueCos = 0f;
        float centerSaturation = 0f;
        for (Sample sample : centerSamples) {
            if (sample.saturation < .20f) centerNeutralRatio++;
            double radians = Math.toRadians(sample.hue);
            centerHueSin += (float) Math.sin(radians) * Math.max(.2f, sample.saturation);
            centerHueCos += (float) Math.cos(radians) * Math.max(.2f, sample.saturation);
            centerSaturation += sample.saturation;
        }
        centerNeutralRatio /= centerSamples.size();
        float centerHue = (float) Math.toDegrees(Math.atan2(centerHueSin, centerHueCos));
        if (centerHue < 0f) centerHue += 360f;
        centerSaturation /= centerSamples.size();
        float medianLuminance = median(luminances);
        List<Sample> usable = new ArrayList<>();
        for (Sample sample : samples) {
            if (!isGlare(sample.color, luminance(sample.color), medianLuminance)) usable.add(sample);
        }
        if (usable.size() < Math.max(5, samples.size() / 2)) usable = samples;

        if (centerNeutralRatio >= .68f && neutralRatio >= .30f) {
            return analyzeNeutral(centerSamples, samples.size(), centerNeutralRatio);
        }
        return analyzeChromatic(usable, samples.size(), centerHue, centerSaturation);
    }

    private static Result analyzeNeutral(List<Sample> samples, int totalCount, float neutralRatio) {
        int[] reds = new int[samples.size()];
        int[] greens = new int[samples.size()];
        int[] blues = new int[samples.size()];
        float[] hues = new float[samples.size()];
        float[] saturations = new float[samples.size()];
        float[] values = new float[samples.size()];
        for (int index = 0; index < samples.size(); index++) {
            Sample sample = samples.get(index);
            reds[index] = Color.red(sample.color);
            greens[index] = Color.green(sample.color);
            blues[index] = Color.blue(sample.color);
            hues[index] = sample.hue;
            saturations[index] = sample.saturation;
            values[index] = sample.value;
        }
        int color = Color.rgb(median(reds), median(greens), median(blues));
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float saturation = Math.max(hsv[1], median(saturations));
        String base = hsv[2] < .18f ? "Schwarz" : hsv[2] > .92f && saturation < .12f ? "Weiß" : "Grau";
        String undertone = neutralUndertone(hues, saturations, base);
        float luminanceSpread = percentile(values, .90f) - percentile(values, .10f);
        Confidence confidence = neutralRatio >= .78f ? Confidence.HIGH : Confidence.MEDIUM;
        String reason = luminanceSpread > .20f ? "Struktur erkannt" : "Fläche überwiegend einheitlich";
        return new Result(color, base, undertone, confidence, reason, totalCount,
                false, saturation, hsv[2], neutralRatio);
    }

    private static Result analyzeChromatic(List<Sample> samples, int totalCount,
                                           float centerHue, float centerSaturation) {
        float[] histogram = new float[HUE_BINS];
        float chromaticWeight = 0f;
        for (Sample sample : samples) {
            float weight = sample.weight * Math.max(.18f, sample.saturation);
            chromaticWeight += weight;
            int bin = hueBin(sample.hue);
            histogram[bin] += weight;
            histogram[(bin + HUE_BINS - 1) % HUE_BINS] += weight * .45f;
            histogram[(bin + 1) % HUE_BINS] += weight * .45f;
        }
        int bestBin = 0;
        for (int index = 1; index < histogram.length; index++) {
            if (histogram[index] > histogram[bestBin]) {
                bestBin = index;
            }
        }
        int globalBestBin = bestBin;
        int centerBin = hueBin(centerHue);
        if (centerSaturation >= .20f
                && histogram[centerBin] >= histogram[globalBestBin] * .22f) {
            bestBin = centerBin;
        }
        int secondBin = bestBin == 0 ? 1 : 0;
        for (int index = 0; index < histogram.length; index++) {
            if (index != bestBin && histogram[index] > histogram[secondBin]) secondBin = index;
        }
        float dominantHue = bestBin * 360f / HUE_BINS + 5f;
        float secondHue = secondBin * 360f / HUE_BINS + 5f;
        float dominantWeight = histogram[bestBin];
        float secondWeight = histogram[secondBin];
        float dominantRatio = dominantWeight / Math.max(.01f, chromaticWeight * 1.9f);
        float hueSpread = 0f;
        List<Sample> dominant = new ArrayList<>();
        for (Sample sample : samples) {
            float difference = hueDistance(sample.hue, dominantHue);
            if (difference <= 38f) {
                dominant.add(sample);
                hueSpread = Math.max(hueSpread, difference);
            }
        }
        if (dominant.size() < Math.max(5, samples.size() / 4)) dominant = samples;
        int[] reds = new int[dominant.size()];
        int[] greens = new int[dominant.size()];
        int[] blues = new int[dominant.size()];
        float[] saturations = new float[dominant.size()];
        float[] values = new float[dominant.size()];
        for (int index = 0; index < dominant.size(); index++) {
            Sample sample = dominant.get(index);
            reds[index] = Color.red(sample.color);
            greens[index] = Color.green(sample.color);
            blues[index] = Color.blue(sample.color);
            saturations[index] = sample.saturation;
            values[index] = sample.value;
        }
        int color = Color.rgb(median(reds), median(greens), median(blues));
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        String base = baseName(hsv[0], hsv[1], hsv[2]);
        String undertone = chromaticUndertone(hsv[0], dominantHue, hueSpread, base);
        boolean mixed = secondWeight > dominantWeight * .48f
                && hueDistance(dominantHue, secondHue) > 42f;
        Confidence confidence;
        if (mixed || dominantRatio < .46f) confidence = Confidence.LOW;
        else if (dominantRatio < .64f || hueSpread > 32f) confidence = Confidence.MEDIUM;
        else confidence = Confidence.HIGH;
        String reason = mixed ? "Mehrere Farben oder Kante erkannt" :
                (hueSpread > 28f || percentile(values, .90f) - percentile(values, .10f) > .22f
                        ? "Struktur erkannt" : "dominante Farbgruppe erkannt");
        return new Result(color, base, undertone, confidence, reason, totalCount,
                mixed, median(saturations), hsv[2], Math.max(0f, Math.min(1f, dominantRatio)));
    }

    private static String neutralUndertone(float[] hues, float[] saturations, String base) {
        if (!"Grau".equals(base) || median(saturations) < .10f) return "";
        float[] chromaticHues = new float[hues.length];
        int count = 0;
        for (int index = 0; index < hues.length; index++) {
            if (saturations[index] >= .06f) chromaticHues[count++] = hues[index];
        }
        if (count == 0) return "";
        float[] relevantHues = Arrays.copyOf(chromaticHues, count);
        float hue = circularMedian(relevantHues);
        if (hue >= 175f && hue <= 275f) return "leicht bläulich";
        if (hue >= 18f && hue <= 78f) return "leicht warm";
        return "";
    }

    private static String chromaticUndertone(float hue, float dominantHue, float spread, String base) {
        if (spread > 25f) return "";
        if ("Beige".equals(base)) return hue < 30f ? "leicht rötlich" : "leicht gelblich";
        if ("Khaki".equals(base)) return "leicht grünlich";
        if ("Grün".equals(base) && hue < 95f) return "leicht gelblich";
        if ("Blau".equals(base) && hue > 220f) return "leicht violett";
        if ("Orange".equals(base) && hue < 30f) return "leicht rötlich";
        if ("Violett".equals(base) && hue > 275f) return "leicht pink";
        return "";
    }

    private static String baseName(float hue, float saturation, float value) {
        if (value < .16f) return "Schwarz";
        if (saturation < .14f) return value > .92f ? "Weiß" : "Grau";
        if (hue < 15f || hue >= 345f) return "Rot";
        if (hue < 42f) {
            if (value < .48f) return "Braun";
            if (saturation < .28f && value > .78f) return "Creme";
            if (saturation < .45f && value > .70f) return "Sand";
            if (saturation < .58f) return "Beige";
            if (saturation < .72f && value < .82f) return "Ocker";
            return "Orange";
        }
        if (hue < 58f && value > .48f && saturation < .52f) return "Khaki";
        if (hue < 72f) return "Gelb";
        if (hue < 165f) return "Grün";
        if (hue < 195f) return "Türkis";
        if (hue < 255f) return "Blau";
        if (hue < 300f) return "Violett";
        return "Pink";
    }

    private static int hueBin(float hue) {
        return Math.max(0, Math.min(HUE_BINS - 1, (int) (hue / 360f * HUE_BINS)));
    }

    private static float hueDistance(float first, float second) {
        float difference = Math.abs(first - second) % 360f;
        return difference > 180f ? 360f - difference : difference;
    }

    private static boolean isGlare(int pixel, float pixelLuminance, float medianLuminance) {
        int maximum = Math.max(Color.red(pixel), Math.max(Color.green(pixel), Color.blue(pixel)));
        int minimum = Math.min(Color.red(pixel), Math.min(Color.green(pixel), Color.blue(pixel)));
        return maximum >= 242 && maximum - minimum < 52 && pixelLuminance > medianLuminance + 26;
    }

    private static float luminance(int pixel) {
        return .2126f * Color.red(pixel) + .7152f * Color.green(pixel) + .0722f * Color.blue(pixel);
    }

    private static float clampGain(float gain) {
        return Math.max(.70f, Math.min(1.40f, gain));
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    private static int median(int[] values) {
        if (values.length == 0) return 0;
        int[] copy = Arrays.copyOf(values, values.length);
        Arrays.sort(copy);
        return copy[copy.length / 2];
    }

    private static float median(float[] values) {
        if (values.length == 0) return 0f;
        float[] copy = Arrays.copyOf(values, values.length);
        Arrays.sort(copy);
        return copy[copy.length / 2];
    }

    private static float percentile(float[] values, float fraction) {
        if (values.length == 0) return 0f;
        float[] copy = Arrays.copyOf(values, values.length);
        Arrays.sort(copy);
        int index = Math.max(0, Math.min(copy.length - 1,
                Math.round((copy.length - 1) * fraction)));
        return copy[index];
    }

    private static float circularMedian(float[] hues) {
        if (hues.length == 0) return 0f;
        float best = hues[0];
        float bestDistance = Float.MAX_VALUE;
        for (float candidate : hues) {
            float distance = 0f;
            for (float other : hues) distance += hueDistance(candidate, other);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }
}
