package com.sehplus.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Offline-only legal reader. HTTPS-shaped asset URLs never go to a network. */
public final class LegalActivity extends Activity {
    public static final String EXTRA_DOCUMENT = "legal_document";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String PREFIX = "/legal/";
    private static final int BACKGROUND = Color.rgb(14, 18, 20);
    private static final int TEXT = Color.rgb(239, 244, 237);
    private LinearLayout root;
    private WebView browser;
    private Button publicButton;
    private LegalConfig config;
    private String document;
    private boolean showingFallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        config = LegalConfig.read(this);
        document = LegalLinks.documentName(state == null
                ? getIntent().getStringExtra(EXTRA_DOCUMENT) : state.getString(EXTRA_DOCUMENT));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(4), dp(10), dp(4));
        Button back = new Button(this);
        back.setText("Zurück");
        back.setAllCaps(false);
        back.setTextColor(TEXT);
        back.setMinHeight(dp(48));
        back.setContentDescription("Rechtstexte schließen und zu SehPlus zurückkehren");
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(-2, -2));
        TextView heading = new TextView(this);
        heading.setText("Rechtliches · offline");
        heading.setTextColor(TEXT);
        heading.setTextSize(16);
        heading.setPadding(dp(12), 0, 0, 0);
        if (Build.VERSION.SDK_INT >= 28) heading.setAccessibilityHeading(true);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);
        publicButton = new Button(this);
        publicButton.setText("Öffentliche Fassung im Browser öffnen");
        publicButton.setAllCaps(false);
        publicButton.setTextColor(TEXT);
        publicButton.setMinHeight(dp(48));
        publicButton.setOnClickListener(v -> openExternal(config.publicUrlFor(document)));
        updatePublicButton();
        root.addView(publicButton, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        root.requestApplyInsets();
        try {
            browser = new WebView(this);
            browser.setBackgroundColor(BACKGROUND);
            browser.setContentDescription("Vollständige SehPlus-Rechtstexte, offline gespeichert");
            WebSettings settings = browser.getSettings();
            settings.setJavaScriptEnabled(false);
            settings.setDomStorageEnabled(false);
            settings.setDatabaseEnabled(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            settings.setAllowFileAccessFromFileURLs(false);
            settings.setAllowUniversalAccessFromFileURLs(false);
            settings.setBlockNetworkLoads(true);
            settings.setBlockNetworkImage(true);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);
            settings.setTextZoom(Math.max(100, Math.round(getResources().getConfiguration().fontScale * 100)));
            browser.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    String asset = bundledAsset(request.getUrl());
                    if (!"GET".equals(request.getMethod()) || asset == null) return blockedResponse();
                    try {
                        return new WebResourceResponse(asset.endsWith(".css") ? "text/css" : "text/html",
                                "UTF-8", getAssets().open("legal/" + asset));
                    } catch (Exception ignored) {
                        return blockedResponse();
                    }
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    if (!request.isForMainFrame()) return true;
                    String asset = bundledAsset(request.getUrl());
                    if ("privacy.html".equals(asset) || "impressum.html".equals(asset)) {
                        document = asset;
                        updatePublicButton();
                        return false;
                    }
                    if (request.hasGesture()) openExternal(request.getUrl().toString());
                    return true;
                }

                @Override
                public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                    if (request.isForMainFrame()) showTextFallback();
                }
            });
            root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
            browser.loadUrl(ORIGIN + PREFIX + document);
        } catch (Exception | LinkageError unavailableWebView) {
            showTextFallback();
        }
    }

    private String bundledAsset(Uri uri) {
        if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost()) ||
                uri.getUserInfo() != null || uri.getPort() != -1 || uri.getQuery() != null) return null;
        for (String name : new String[]{"privacy.html", "impressum.html", "legal.css"}) {
            if ((PREFIX + name).equals(uri.getEncodedPath())) return name;
        }
        return null;
    }

    private WebResourceResponse blockedResponse() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void updatePublicButton() {
        publicButton.setVisibility(config.publicUrlFor(document).isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void openExternal(String url) {
        if (!LegalLinks.isPublicHttps(url) && !LegalLinks.isContactEmail(url)) return;
        try {
            Intent intent = new Intent(url.startsWith("mailto:") ? Intent.ACTION_SENDTO : Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception ignored) {
            Toast.makeText(this, "Keine passende App zum Öffnen dieses Links vorhanden.", Toast.LENGTH_LONG).show();
        }
    }

    private void showTextFallback() {
        if (showingFallback || isFinishing()) return;
        showingFallback = true;
        if (browser != null) {
            root.removeView(browser);
            browser.destroy();
            browser = null;
        }
        ScrollView scroll = new ScrollView(this);
        TextView text = new TextView(this);
        text.setTextSize(18);
        text.setTextColor(TEXT);
        text.setPadding(dp(22), dp(16), dp(22), dp(32));
        text.setTextIsSelectable(true);
        try (InputStream stream = getAssets().open("legal/" + document)) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int count;
            while ((count = stream.read(buffer)) != -1) bytes.write(buffer, 0, count);
            String html = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            html = html.replaceAll("(?is)<head>.*?</head>", "");
            text.setText(Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY));
        } catch (Exception ignored) {
            text.setText("Der lokale Rechtstext konnte nicht geladen werden. Bitte prüfe die Installation von SehPlus.");
        }
        scroll.addView(text);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        state.putString(EXTRA_DOCUMENT, document);
        super.onSaveInstanceState(state);
    }

    @Override
    protected void onDestroy() {
        if (browser != null) {
            root.removeView(browser);
            browser.destroy();
            browser = null;
        }
        super.onDestroy();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
