package com.sehplus.app;

import android.content.Context;
import java.io.InputStream;
import java.util.Properties;

final class LegalConfig {
    final boolean publicationReady;
    final String privacyUrl;
    final String imprintUrl;
    final String feedbackUrl;

    private LegalConfig(Properties values) {
        publicationReady = "true".equals(values.getProperty("publicationReady", "false"));
        privacyUrl = values.getProperty("privacyUrl", "").trim();
        imprintUrl = values.getProperty("imprintUrl", "").trim();
        feedbackUrl = values.getProperty("feedbackUrl", "").trim();
    }

    static LegalConfig read(Context context) {
        Properties values = new Properties();
        try (InputStream stream = context.getAssets().open("legal/release.properties")) {
            values.load(stream);
        } catch (Exception ignored) {
            // Missing configuration never activates an external link.
            values.clear();
        }
        return new LegalConfig(values);
    }

    boolean hasFeedback() { return LegalLinks.isPublicHttps(feedbackUrl); }

    String publicUrlFor(String document) {
        String url = "impressum.html".equals(document) ? imprintUrl : privacyUrl;
        return publicationReady && LegalLinks.isPublicHttps(url) ? url : "";
    }
}
