package com.sehplus.app;

import java.net.URI;
import java.util.Locale;

/** Link policy shared by the legal reader and its plain-Java regression tests. */
final class LegalLinks {
    private LegalLinks() { }

    static boolean isPublicHttps(String value) {
        if (value == null || value.isEmpty() || !value.equals(value.trim())) return false;
        try {
            URI uri = new URI(value);
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null || uri.getUserInfo() != null) return false;
            host = host.toLowerCase(Locale.ROOT);
            if (!host.contains(".") || host.endsWith(".") || host.contains(":") || host.matches("[0-9.]+")) return false;
            if (host.equals("example.com") || host.endsWith(".example.com") ||
                    host.equals("example.org") || host.endsWith(".example.org") ||
                    host.equals("example.net") || host.endsWith(".example.net")) return false;
            for (String suffix : new String[]{".example", ".invalid", ".test", ".local", ".localhost", ".internal"}) {
                if (host.endsWith(suffix)) return false;
            }
            String normalized = value.toUpperCase(Locale.ROOT);
            return !normalized.contains("DEIN_FORMULAR_ID") && !normalized.contains("DEINE-DOMAIN") &&
                    !normalized.contains("%0A") && !normalized.contains("%0D");
        } catch (Exception ignored) {
            return false;
        }
    }

    static boolean isContactEmail(String value) {
        if (value == null || !value.startsWith("mailto:") || value.contains("%") || value.contains("?")) return false;
        return value.substring(7).matches("[A-Za-z0-9.!#$&'*+/=^_`{|}~-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)+") &&
                !value.toLowerCase(Locale.ROOT).endsWith("@example.com");
    }

    static String documentName(String requested) {
        return "impressum.html".equals(requested) ? "impressum.html" : "privacy.html";
    }
}
