package com.sehplus.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import android.graphics.ImageFormat;
import android.util.Size;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * SehPlus: an offline color-assistance tool for camera frames, photos and video frames.
 * No network permission or account is required.
 */
public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION = 42;
    private static final int PICK_MEDIA = 43;
    // Verify this public creator URL before publishing the app.
    private static final String DONATION_URL = "https://buymeacoffee.com/sehplus";
    private LegalConfig legalConfig;
    private static final float[] SRGB_TO_LINEAR = new float[256];
    private static final int[] LINEAR_TO_SRGB = new int[4097];

    static {
        for (int index = 0; index < SRGB_TO_LINEAR.length; index++) {
            float value = index / 255f;
            SRGB_TO_LINEAR[index] = value <= 0.04045f
                    ? value / 12.92f
                    : (float) Math.pow((value + 0.055f) / 1.055f, 2.4f);
        }
        for (int index = 0; index < LINEAR_TO_SRGB.length; index++) {
            float value = index / (float) (LINEAR_TO_SRGB.length - 1);
            float srgb = value <= 0.0031308f
                    ? value * 12.92f
                    : 1.055f * (float) Math.pow(value, 1f / 2.4f) - 0.055f;
            LINEAR_TO_SRGB[index] = Math.round(Math.max(0f, Math.min(1f, srgb)) * 255f);
        }
    }

    private final int background = Color.rgb(14, 18, 20);
    private final int surface = Color.rgb(24, 32, 36);
    private final int surfaceTwo = Color.rgb(32, 43, 48);
    private final int text = Color.rgb(244, 247, 246);
    private final int muted = Color.rgb(169, 182, 184);
    private final int accent = Color.rgb(184, 244, 75);
    private final int divider = Color.rgb(51, 65, 71);

    private FrameLayout previewFrame;
    private ImageView preview;
    private ZoomImageView zoomPreview;
    private TextView emptyPreview;
    private TextView statusText;
    private TextView lightHintText;
    private TextView batteryStatus;
    private TextView performanceStatus;
    private TextView profileDescription;
    private TextView strengthValue;
    private TextView brightnessValue;
    private TextView videoPositionLabel;
    private SeekBar strengthSeek;
    private SeekBar brightnessSeek;
    private SeekBar videoSeek;
    private Button cameraButton;
    private Button mediaButton;
    private Button filterMenuButton;
    private Button freezeButton;
    private Button pipetteButton;
    private Button recognitionButton;
    private Button torchButton;
    private Button saveButton;
    private Button compareButton;
    private Button stillRetryButton;
    private Button pipetteCalibrationButton;
    private Button pipetteAreaButton;
    private Button colorCompareButton;
    private Button saveColorButton;
    private Button shareColorButton;
    private TextView torchValue;
    private SeekBar torchSeek;
    private TextView pipetteResult;
    private TextView pipetteCalibrationStatus;
    private View pipetteSwatch;
    private TextView zoomValue;
    private Button zoomOutButton;
    private Button zoomResetButton;
    private Button zoomInButton;
    private Button cameraTab;
    private Button aboutTab;
    private Button settingsTab;
    private FrameLayout pageContainer;
    private View cameraPage;
    private View aboutPage;
    private View settingsPage;
    private android.widget.ScrollView cameraScroll;
    private Switch autoEnhanceSwitch;
    private Switch hapticsSwitch;
    private PipetteOverlay pipetteOverlay;
    private PopupWindow filterPopupWindow;
    private PopupWindow recognitionPopupWindow;
    private PopupWindow pipetteAreaPopupWindow;
    private View filterAdjustPanel;
    private Button filterAdjustButton;
    private boolean filterAdjustExpanded;
    private final List<Button> profileButtons = new ArrayList<>();

    private Profile selectedProfile = Profile.RED_GREEN_PLUS;
    private Bitmap currentSource;
    private Bitmap currentDisplay;
    private Uri currentUri;
    private boolean cameraMode;
    private boolean cameraFrozen;
    private boolean livePreviewFitPending;
    private volatile CameraUiState cameraUiState = CameraUiState.IDLE;
    private volatile long cameraGeneration;
    private boolean videoMode;
    private boolean pipetteMode;
    private boolean showingOriginal;
    private boolean autoEnhance = true;
    private boolean hapticsEnabled = true;
    private boolean torchOn;
    private volatile RecognitionMode recognitionMode = RecognitionMode.OFF;
    private int recognitionStrength = 82;
    private SeekBar recognitionSeek;
    private TextView recognitionStrengthValue;
    private boolean torchAvailable;
    private int torchMaxLevel = 1;
    private int torchDefaultLevel = 1;
    private String torchCameraId;
    private long videoDurationMs;
    private MediaMetadataRetriever videoRetriever;
    private int cameraRotationDegrees;
    private boolean cameraFrontFacing;

    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraSession;
    private CaptureRequest.Builder cameraRequestBuilder;
    private ImageReader imageReader;
    private ImageReader stillReader;
    private boolean stillCapturePending;
    private boolean cameraOpening;
    private PipetteCalibration pipetteCalibration;
    private ColorAnalyzer.AreaSize pipetteAreaSize = ColorAnalyzer.AreaSize.MEDIUM;
    private ColorAnalyzer.Result lastPipetteResult;
    private int lastPipetteColor;
    private ColorAnalyzer.Result compareFirstResult;
    private boolean colorCompareMode;
    private Bitmap pipetteGainSource;
    private float[] cachedPipetteGains = new float[]{1f, 1f, 1f};
    private int lastPipetteSourceX = -1;
    private int lastPipetteSourceY = -1;
    private float lastPipetteViewX;
    private float lastPipetteViewY;
    private String lastCameraError = "";
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable stillTimeout = () -> {
        if (!stillCapturePending || !cameraMode || !cameraFrozen) return;
        stillCapturePending = false;
        showStillFallback("Standbild aktiv · Vorschauauflösung verwendet");
        freezeButton.setEnabled(currentSource != null);
        pipetteButton.setEnabled(currentSource != null);
        updateRecognitionUi();
        resetZoomControls();
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        legalConfig = LegalConfig.read(this);
        Window window = getWindow();
        window.setStatusBarColor(background);
        window.setNavigationBarColor(background);
        SharedPreferences preferences = getSharedPreferences("sehplus_preferences", MODE_PRIVATE);
        autoEnhance = preferences.getBoolean("auto_enhance", true);
        hapticsEnabled = preferences.getBoolean("haptics", true);
        buildUi();
        String profileName = preferences.getString("profile", Profile.RED_GREEN_PLUS.name());
        selectedProfile = Profile.fromStoredName(profileName);
        if (!selectedProfile.name().equals(profileName)) {
            preferences.edit().putString("profile", selectedProfile.name()).apply();
        }
        if (autoEnhanceSwitch != null) autoEnhanceSwitch.setChecked(autoEnhance);
        if (hapticsSwitch != null) hapticsSwitch.setChecked(hapticsEnabled);
        selectProfile(selectedProfile);
        showEmptyState("Kamera starten oder ein Bild öffnen");
        prepareTorch();
        updateDeviceStatus();
        uiHandler.post(this::showWelcomeIfNeeded);
    }

    private void showWelcomeIfNeeded() {
        SharedPreferences preferences = getSharedPreferences("sehplus_preferences", MODE_PRIVATE);
        if (preferences.getBoolean("welcome_shown", false) || isFinishing()) return;
        showOnboardingStep(0, preferences);
    }

    private void showOnboarding() {
        showOnboardingStep(0, getSharedPreferences("sehplus_preferences", MODE_PRIVATE));
    }

    private void showOnboardingStep(int step, SharedPreferences preferences) {
        if (isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setOnCancelListener(dialog -> finishOnboarding(preferences));
        if (step == 0) {
            builder.setTitle("Willkommen bei SehPlus · 1/3")
                    .setMessage("SehPlus hilft dir, Farben im Alltag besser zu unterscheiden. "
                            + "Kamera- und Bilddaten werden lokal auf dem Gerät verarbeitet. "
                            + "SehPlus ist keine medizinische Diagnose.")
                    .setNegativeButton("ÜBERSPRINGEN", (dialog, which) -> finishOnboarding(preferences))
                    .setPositiveButton("WEITER", (dialog, which) -> showOnboardingStep(1, preferences));
        } else if (step == 1) {
            builder.setTitle("Das Licht zählt · 2/3")
                    .setMessage("Umgebungslicht beeinflusst jede Kameraaufnahme und damit auch die Farberkennung. "
                            + "Nutze möglichst gleichmäßiges Licht, vermeide Spiegelungen und vergleiche wichtige Farben unter dem Licht, "
                            + "unter dem du sie später brauchst. Mit der Pipette kannst du eine matte weiße oder graue Fläche zur Lichtkalibrierung verwenden.")
                    .setNegativeButton("ZURÜCK", (dialog, which) -> showOnboardingStep(0, preferences))
                    .setPositiveButton("WEITER", (dialog, which) -> showOnboardingStep(2, preferences));
        } else {
            builder.setTitle("So funktioniert es · 3/3")
                    .setMessage("Starte die Kamera, wähle ein Farbprofil und nutze im Standbild Zoom, Pipette oder Farben verschieben. "
                            + "Für strukturierte Flächen hilft eine größere Messfläche.\n\n"
                            + "Ich bin ein junger unabhängiger Entwickler. Wenn dir SehPlus hilft, kannst du die Weiterentwicklung freiwillig mit einer Spende unterstützen – nur wenn du möchtest.\n\n"
                            + "Du hast einen Verbesserungsvorschlag oder etwas funktioniert nicht wie erwartet? "
                            + "Über das Feedback-Formular kannst du uns direkt schreiben.")
                    .setNegativeButton("SPÄTER", (dialog, which) -> finishOnboarding(preferences))
                    .setNeutralButton("FEEDBACK SENDEN", (dialog, which) -> {
                        finishOnboarding(preferences);
                        openFeedbackForm();
                    })
                    .setPositiveButton("ZUR KAMERA", (dialog, which) -> finishOnboarding(preferences));
        }
        builder.show();
    }

    private void finishOnboarding(SharedPreferences preferences) {
        preferences.edit().putBoolean("welcome_shown", true).apply();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(background);
        int baseHorizontalPadding = dp(16);
        int baseTopPadding = dp(10);
        root.setPadding(baseHorizontalPadding, baseTopPadding, baseHorizontalPadding, 0);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int topInset = insets.getSystemWindowInsetTop();
            int bottomInset = insets.getSystemWindowInsetBottom();
            root.setPadding(baseHorizontalPadding, baseTopPadding + topInset,
                    baseHorizontalPadding, bottomInset);
            return insets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("SEHPLUS", 25, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
        batteryStatus = pill("Akku --", accent, Color.rgb(39, 63, 23));
        header.addView(batteryStatus, new LinearLayout.LayoutParams(-2, dp(30)));
        root.addView(header);
        TextView subtitle = label("Farben sichtbar machen · lokal verarbeitet", 13, muted);
        subtitle.setPadding(0, 0, 0, dp(8));
        root.addView(subtitle);

        pageContainer = new FrameLayout(this);
        root.addView(pageContainer, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setPadding(0, dp(8), 0, dp(8));
        cameraTab = navButton("KAMERA", true);
        aboutTab = navButton("ÜBER", false);
        settingsTab = navButton("EINSTELLUNGEN", false);
        cameraTab.setOnClickListener(v -> switchPage(0));
        aboutTab.setOnClickListener(v -> switchPage(1));
        settingsTab.setOnClickListener(v -> switchPage(2));
        navigation.addView(cameraTab, navLayoutParams(true));
        navigation.addView(aboutTab, navLayoutParams(false));
        navigation.addView(settingsTab, navLayoutParams(false));
        root.addView(navigation);

        cameraScroll = scrollPage(buildCameraPage());
        cameraPage = cameraScroll;
        aboutPage = scrollPage(buildAboutPage());
        settingsPage = scrollPage(buildSettingsPage());
        pageContainer.addView(cameraPage, new FrameLayout.LayoutParams(-1, -1));
        pageContainer.addView(aboutPage, new FrameLayout.LayoutParams(-1, -1));
        pageContainer.addView(settingsPage, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.requestApplyInsets();
        switchPage(0);
    }

    private LinearLayout.LayoutParams navLayoutParams(boolean first) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(46), 1);
        if (!first) params.setMargins(dp(4), 0, 0, 0);
        return params;
    }

    private android.widget.ScrollView scrollPage(LinearLayout content) {
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(8));
        scroll.addView(content);
        return scroll;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(2), dp(4), dp(2), dp(12));
        return layout;
    }

    private Button navButton(String title, boolean selected) {
        Button button = actionButton(title, selected);
        button.setTextSize(10);
        return button;
    }

    private LinearLayout buildCameraPage() {
        LinearLayout page = column();
        TextView heading = label("Kamera", 20, text);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(heading);
        TextView hint = label("Live ansehen, Standbild aufnehmen oder ein Bild öffnen.", 12, muted);
        hint.setPadding(0, dp(2), 0, dp(8));
        page.addView(hint);

        LinearLayout modes = new LinearLayout(this);
        cameraButton = actionButton("KAMERA STARTEN", true);
        mediaButton = actionButton("BILD / VIDEO ÖFFNEN", false);
        cameraButton.setContentDescription("Kamera starten oder stoppen");
        mediaButton.setContentDescription("Bild oder Video öffnen");
        cameraButton.setOnClickListener(v -> startCameraFromUserAction());
        mediaButton.setOnClickListener(v -> openMediaPicker());
        modes.addView(cameraButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        modes.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
        modes.addView(mediaButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        page.addView(modes);
        page.addView(verticalGap(10));

        LinearLayout filterBar = new LinearLayout(this);
        filterBar.setGravity(Gravity.CENTER_VERTICAL);
        filterMenuButton = actionButton("FILTER · " + selectedProfile.shortName + "  ▾", false);
        filterMenuButton.setContentDescription("Filter auswählen");
        filterMenuButton.setOnClickListener(v -> showFilterPopup());
        filterBar.addView(filterMenuButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        page.addView(filterBar);
        page.addView(verticalGap(10));

        previewFrame = new FrameLayout(this);
        previewFrame.setBackground(roundDrawable(surface, dp(16)));
        int previewHeight = previewHeight();
        zoomPreview = new ZoomImageView(this);
        preview = zoomPreview;
        preview.setScaleType(ImageView.ScaleType.MATRIX);
        preview.setBackgroundColor(Color.rgb(9, 12, 13));
        preview.setContentDescription("Vorschau des Farbfilters");
        previewFrame.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        emptyPreview = label("", 15, muted);
        emptyPreview.setGravity(Gravity.CENTER);
        emptyPreview.setPadding(dp(24), dp(24), dp(24), dp(24));
        previewFrame.addView(emptyPreview, new FrameLayout.LayoutParams(-1, -1));
        TextView offlineBadge = pill("LOKAL", accent, Color.rgb(28, 43, 22));
        FrameLayout.LayoutParams badgeParams = new FrameLayout.LayoutParams(-2, dp(30), Gravity.TOP | Gravity.START);
        badgeParams.setMargins(dp(12), dp(12), 0, 0);
        previewFrame.addView(offlineBadge, badgeParams);
        pipetteOverlay = new PipetteOverlay(this);
        pipetteOverlay.setVisibility(View.GONE);
        previewFrame.addView(pipetteOverlay, new FrameLayout.LayoutParams(-1, -1));
        page.addView(previewFrame, new LinearLayout.LayoutParams(-1, previewHeight));

        statusText = label("Bereit", 12, muted);
        statusText.setPadding(dp(4), dp(8), dp(4), dp(6));
        page.addView(statusText);
        lightHintText = label("Licht-Hinweis: Umgebungslicht, Schatten und Spiegelungen können Aufnahme und Farberkennung verändern. Für wichtige Farben gleichmäßig beleuchten.", 11, muted);
        lightHintText.setPadding(dp(4), 0, dp(4), dp(7));
        lightHintText.setLineSpacing(0, 1.1f);
        page.addView(lightHintText);
        stillRetryButton = actionButton("HOCHAUFLÖSEND ERNEUT VERSUCHEN", false);
        stillRetryButton.setContentDescription("Hochauflösendes Standbild erneut versuchen");
        stillRetryButton.setVisibility(View.GONE);
        stillRetryButton.setOnClickListener(v -> requestHighResolutionStill());
        page.addView(stillRetryButton, new LinearLayout.LayoutParams(-1, dp(44)));

        LinearLayout quick = new LinearLayout(this);
        freezeButton = actionButton("STANDBILD", false);
        pipetteButton = actionButton("PIPETTE", false);
        compareButton = actionButton("NORMALANSICHT", false);
        freezeButton.setContentDescription("Standbild aufnehmen");
        pipetteButton.setContentDescription("Farbe mit der Pipette messen");
        compareButton.setContentDescription("Zwischen Filter und Normalansicht wechseln");
        freezeButton.setEnabled(false);
        pipetteButton.setEnabled(false);
        compareButton.setEnabled(false);
        freezeButton.setOnClickListener(v -> toggleFreeze());
        pipetteButton.setOnClickListener(v -> togglePipette());
        compareButton.setOnClickListener(v -> toggleComparison());
        quick.addView(freezeButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        quick.addView(space(dp(6)), new LinearLayout.LayoutParams(dp(6), 1));
        quick.addView(pipetteButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        quick.addView(space(dp(6)), new LinearLayout.LayoutParams(dp(6), 1));
        quick.addView(compareButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        page.addView(quick);
        page.addView(verticalGap(8));

        recognitionButton = actionButton("FARBEN VERSCHIEBEN  ▾", false);
        recognitionButton.setContentDescription("Erkennungsmodus für Standbild öffnen");
        recognitionButton.setOnClickListener(v -> showRecognitionPopup());
        recognitionButton.setVisibility(View.GONE);
        page.addView(recognitionButton, new LinearLayout.LayoutParams(-1, dp(48)));
        page.addView(verticalGap(8));

        LinearLayout zoomRow = new LinearLayout(this);
        zoomOutButton = actionButton("−", false);
        zoomResetButton = actionButton("1×", false);
        zoomInButton = actionButton("+", false);
        zoomValue = label("Zoom nur im Standbild", 11, muted);
        zoomValue.setGravity(Gravity.CENTER);
        zoomOutButton.setEnabled(false);
        zoomResetButton.setEnabled(false);
        zoomInButton.setEnabled(false);
        zoomOutButton.setOnClickListener(v -> zoomPreview.changeZoom(0.75f));
        zoomResetButton.setOnClickListener(v -> zoomPreview.resetZoom());
        zoomInButton.setOnClickListener(v -> zoomPreview.changeZoom(1.35f));
        zoomRow.addView(zoomOutButton, new LinearLayout.LayoutParams(dp(52), dp(38)));
        zoomRow.addView(zoomValue, new LinearLayout.LayoutParams(0, dp(38), 1));
        zoomRow.addView(zoomResetButton, new LinearLayout.LayoutParams(dp(58), dp(38)));
        zoomRow.addView(zoomInButton, new LinearLayout.LayoutParams(dp(52), dp(38)));
        page.addView(zoomRow);
        page.addView(verticalGap(6));

        pipetteResult = label("Pipette auswählen, dann über das Bild ziehen.", 12, muted);
        pipetteResult.setPadding(dp(4), 0, dp(4), dp(7));
        pipetteResult.setLineSpacing(0, 1.1f);
        pipetteSwatch = new View(this);
        pipetteSwatch.setBackground(roundDrawable(surfaceTwo, dp(18)));
        LinearLayout pipetteResultRow = new LinearLayout(this);
        pipetteResultRow.setGravity(Gravity.CENTER_VERTICAL);
        pipetteResultRow.addView(pipetteResult, new LinearLayout.LayoutParams(0, -2, 1));
        pipetteResultRow.addView(pipetteSwatch, new LinearLayout.LayoutParams(dp(38), dp(38)));
        page.addView(pipetteResultRow);
        pipetteAreaButton = actionButton("MESSFLÄCHE · MITTEL  ▾", false);
        pipetteAreaButton.setContentDescription("Messfläche der Pipette auswählen");
        pipetteAreaButton.setOnClickListener(v -> showPipetteAreaPopup());
        page.addView(pipetteAreaButton, new LinearLayout.LayoutParams(-1, dp(42)));
        page.addView(verticalGap(4));
        LinearLayout colorTools = new LinearLayout(this);
        colorCompareButton = actionButton("ZWEI FARBEN VERGLEICHEN", false);
        saveColorButton = actionButton("MESSUNG MERKEN", false);
        shareColorButton = actionButton("FARBKARTE TEILEN", false);
        colorCompareButton.setContentDescription("Zwei gemessene Farben vergleichen");
        saveColorButton.setContentDescription("Aktuelle Farbmessung lokal merken");
        shareColorButton.setContentDescription("Farbkarte ohne Foto teilen");
        colorCompareButton.setEnabled(false);
        saveColorButton.setEnabled(false);
        shareColorButton.setEnabled(false);
        colorCompareButton.setOnClickListener(v -> toggleColorCompare());
        saveColorButton.setOnClickListener(v -> saveColorNote());
        shareColorButton.setOnClickListener(v -> shareColorCard());
        colorTools.addView(colorCompareButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        colorTools.addView(space(dp(5)), new LinearLayout.LayoutParams(dp(5), 1));
        colorTools.addView(saveColorButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        colorTools.addView(space(dp(5)), new LinearLayout.LayoutParams(dp(5), 1));
        colorTools.addView(shareColorButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        page.addView(colorTools);
        page.addView(verticalGap(4));
        pipetteCalibrationStatus = label("Keine Lichtkalibrierung aktiv", 11, muted);
        pipetteCalibrationStatus.setPadding(dp(4), 0, dp(4), dp(4));
        page.addView(pipetteCalibrationStatus);
        pipetteCalibrationButton = actionButton("LICHT KALIBRIEREN", false);
        pipetteCalibrationButton.setContentDescription("Pipette unter dem aktuellen Licht kalibrieren");
        pipetteCalibrationButton.setEnabled(false);
        pipetteCalibrationButton.setOnClickListener(v -> togglePipetteCalibration());
        page.addView(pipetteCalibrationButton, new LinearLayout.LayoutParams(-1, dp(42)));
        page.addView(verticalGap(4));

        LinearLayout torchRow = new LinearLayout(this);
        torchButton = actionButton("TASCHENLAMPE AUS", false);
        torchButton.setEnabled(false);
        torchButton.setOnClickListener(v -> toggleTorch());
        torchValue = label("nicht verfügbar", 11, muted);
        torchValue.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        torchRow.addView(torchButton, new LinearLayout.LayoutParams(0, dp(40), 1));
        torchRow.addView(torchValue, new LinearLayout.LayoutParams(dp(118), dp(40)));
        page.addView(torchRow);
        torchSeek = seekBar(50);
        torchSeek.setEnabled(false);
        torchSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (torchValue != null && torchAvailable) torchValue.setText("Helligkeit " + Math.max(1, value) + " %");
                if (fromUser && torchOn) applyTorchLevel();
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        page.addView(torchSeek, new LinearLayout.LayoutParams(-1, dp(34)));
        page.addView(verticalGap(6));

        videoPositionLabel = label("", 12, muted);
        page.addView(videoPositionLabel);
        videoSeek = seekBar(0);
        videoSeek.setVisibility(View.GONE);
        videoSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser && videoMode) updateVideoFrame(videoDurationMs * value / 1000L);
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        page.addView(videoSeek, new LinearLayout.LayoutParams(-1, dp(34)));
        page.addView(verticalGap(6));

        LinearLayout bottomActions = new LinearLayout(this);
        saveButton = actionButton("BILD SPEICHERN", true);
        saveButton.setEnabled(false);
        saveButton.setOnClickListener(v -> saveCurrentImage());
        bottomActions.addView(saveButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        page.addView(bottomActions);
        buildFilterPopup();
        buildRecognitionPopup();
        buildPipetteAreaPopup();
        return page;
    }

    private void buildFilterPopup() {
        profileButtons.clear();
        LinearLayout content = column();
        content.setPadding(dp(12), dp(12), dp(12), dp(10));

        TextView title = label("Filter auswählen", 16, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView subtitle = label("Die Auswahl wird sofort auf Livebild und Standbild angewendet.", 11, muted);
        subtitle.setPadding(0, 0, 0, dp(8));
        content.addView(subtitle);

        for (Profile profile : Profile.values()) {
            Button button = actionButton(profile.shortName, false);
            button.setTag(profile);
            button.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            button.setOnClickListener(v -> {
                selectProfile((Profile) v.getTag());
                if (filterPopupWindow != null) filterPopupWindow.dismiss();
            });
            profileButtons.add(button);
            content.addView(button, new LinearLayout.LayoutParams(-1, dp(40)));
            View gap = space(dp(5));
            content.addView(gap, new LinearLayout.LayoutParams(1, dp(5)));
        }

        profileDescription = label("", 11, muted);
        profileDescription.setPadding(dp(4), dp(6), dp(4), dp(8));
        profileDescription.setLineSpacing(0, 1.1f);
        content.addView(profileDescription);

        filterAdjustButton = actionButton("FILTER ANPASSEN  ▼", false);
        filterAdjustButton.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        filterAdjustButton.setOnClickListener(v -> {
            filterAdjustExpanded = !filterAdjustExpanded;
            filterAdjustPanel.setVisibility(filterAdjustExpanded ? View.VISIBLE : View.GONE);
            filterAdjustButton.setText(filterAdjustExpanded ? "FILTER ANPASSEN  ▲" : "FILTER ANPASSEN  ▼");
        });
        content.addView(filterAdjustButton, new LinearLayout.LayoutParams(-1, dp(40)));

        filterAdjustPanel = column();
        filterAdjustPanel.setPadding(dp(4), dp(4), dp(4), 0);
        LinearLayout strengthHeader = new LinearLayout(this);
        strengthHeader.setGravity(Gravity.CENTER_VERTICAL);
        strengthHeader.addView(sectionTitle("FILTERSTÄRKE"), new LinearLayout.LayoutParams(0, dp(28), 1));
        strengthValue = label("70 %", 12, accent);
        strengthHeader.addView(strengthValue);
        ((LinearLayout) filterAdjustPanel).addView(strengthHeader);
        strengthSeek = seekBar(70);
        strengthSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                strengthValue.setText(Math.max(5, value) + " %");
                refreshCurrentMedia();
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        ((LinearLayout) filterAdjustPanel).addView(strengthSeek, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout brightnessHeader = new LinearLayout(this);
        brightnessHeader.setGravity(Gravity.CENTER_VERTICAL);
        brightnessHeader.addView(sectionTitle("HELLIGKEIT / KONTRAST"), new LinearLayout.LayoutParams(0, dp(28), 1));
        brightnessValue = label("0", 12, accent);
        brightnessHeader.addView(brightnessValue);
        ((LinearLayout) filterAdjustPanel).addView(brightnessHeader);
        brightnessSeek = seekBar(50);
        brightnessSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                int offset = value - 50;
                brightnessValue.setText((offset > 0 ? "+" : "") + offset);
                refreshCurrentMedia();
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        ((LinearLayout) filterAdjustPanel).addView(brightnessSeek, new LinearLayout.LayoutParams(-1, dp(34)));
        Button resetButton = actionButton("FILTER ZURÜCKSETZEN", false);
        resetButton.setOnClickListener(v -> resetControls());
        ((LinearLayout) filterAdjustPanel).addView(resetButton, new LinearLayout.LayoutParams(-1, dp(40)));
        filterAdjustPanel.setVisibility(View.GONE);
        content.addView(filterAdjustPanel, new LinearLayout.LayoutParams(-1, -2));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int popupHeight = Math.min(dp(520), Math.max(dp(360), screenHeight - dp(110)));
        int popupWidth = Math.min(dp(370), getResources().getDisplayMetrics().widthPixels - dp(24));
        filterPopupWindow = new PopupWindow(scroll, popupWidth, popupHeight, true);
        filterPopupWindow.setBackgroundDrawable(roundDrawable(surface, dp(14)));
        filterPopupWindow.setOutsideTouchable(true);
        filterPopupWindow.setElevation(dp(8));
    }

    private void buildRecognitionPopup() {
        LinearLayout content = column();
        content.setPadding(dp(12), dp(12), dp(12), dp(10));

        TextView title = label("Farben für Erkennung verschieben", 16, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView subtitle = label("Optimiert Lesbarkeit statt natürlicher Farbwiedergabe. Nur für Standbilder.", 11, muted);
        subtitle.setPadding(0, 0, 0, dp(9));
        subtitle.setLineSpacing(0, 1.05f);
        content.addView(subtitle);

        Button off = actionButton("AUS · normalen Filter verwenden", false);
        off.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        off.setOnClickListener(v -> selectRecognitionMode(RecognitionMode.OFF));
        content.addView(off, new LinearLayout.LayoutParams(-1, dp(42)));
        content.addView(space(dp(5)), new LinearLayout.LayoutParams(1, dp(5)));

        Button testImage = actionButton("TESTBILD · Zahlen und Punkte", false);
        testImage.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        testImage.setOnClickListener(v -> selectRecognitionMode(RecognitionMode.TEST_IMAGE));
        content.addView(testImage, new LinearLayout.LayoutParams(-1, dp(42)));
        content.addView(space(dp(5)), new LinearLayout.LayoutParams(1, dp(5)));

        Button whiteboard = actionButton("WHITEBOARD · Schrift und Linien", false);
        whiteboard.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        whiteboard.setOnClickListener(v -> selectRecognitionMode(RecognitionMode.WHITEBOARD));
        content.addView(whiteboard, new LinearLayout.LayoutParams(-1, dp(42)));
        content.addView(verticalGap(8));

        LinearLayout strengthHeader = new LinearLayout(this);
        strengthHeader.setGravity(Gravity.CENTER_VERTICAL);
        strengthHeader.addView(sectionTitle("ERKENNUNGSSTÄRKE"), new LinearLayout.LayoutParams(0, dp(28), 1));
        recognitionStrengthValue = label(recognitionStrength + " %", 12, accent);
        strengthHeader.addView(recognitionStrengthValue);
        content.addView(strengthHeader);
        recognitionSeek = seekBar(recognitionStrength);
        recognitionSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                recognitionStrength = Math.max(5, value);
                if (recognitionStrengthValue != null) recognitionStrengthValue.setText(recognitionStrength + " %");
                if (fromUser && recognitionMode != RecognitionMode.OFF) refreshCurrentMedia();
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        content.addView(recognitionSeek, new LinearLayout.LayoutParams(-1, dp(34)));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int popupHeight = Math.min(dp(390), Math.max(dp(300), screenHeight - dp(120)));
        int popupWidth = Math.min(dp(370), getResources().getDisplayMetrics().widthPixels - dp(24));
        recognitionPopupWindow = new PopupWindow(scroll, popupWidth, popupHeight, true);
        recognitionPopupWindow.setBackgroundDrawable(roundDrawable(surface, dp(14)));
        recognitionPopupWindow.setOutsideTouchable(true);
        recognitionPopupWindow.setElevation(dp(8));
    }

    private void buildPipetteAreaPopup() {
        LinearLayout content = column();
        content.setPadding(dp(12), dp(12), dp(12), dp(10));

        TextView title = label("Messfläche wählen", 16, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView subtitle = label("Die Mitte bleibt der Messpunkt. Eine größere Fläche hilft bei Stoff, Papier und ungleichmäßigem Licht.", 11, muted);
        subtitle.setLineSpacing(0, 1.08f);
        subtitle.setPadding(0, 0, 0, dp(8));
        content.addView(subtitle);

        for (ColorAnalyzer.AreaSize size : ColorAnalyzer.AreaSize.values()) {
            Button option = actionButton(size.label.toUpperCase(Locale.GERMANY), false);
            option.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            option.setOnClickListener(v -> selectPipetteArea(size));
            content.addView(option, new LinearLayout.LayoutParams(-1, dp(42)));
            content.addView(space(dp(5)), new LinearLayout.LayoutParams(1, dp(5)));
        }

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        int popupWidth = Math.min(dp(370), getResources().getDisplayMetrics().widthPixels - dp(24));
        pipetteAreaPopupWindow = new PopupWindow(scroll, popupWidth, dp(250), true);
        pipetteAreaPopupWindow.setBackgroundDrawable(roundDrawable(surface, dp(14)));
        pipetteAreaPopupWindow.setOutsideTouchable(true);
        pipetteAreaPopupWindow.setElevation(dp(8));
    }

    private void showPipetteAreaPopup() {
        if (pipetteAreaButton == null) return;
        if (pipetteAreaPopupWindow == null) buildPipetteAreaPopup();
        if (pipetteAreaPopupWindow.isShowing()) {
            pipetteAreaPopupWindow.dismiss();
            return;
        }
        pipetteAreaPopupWindow.showAsDropDown(pipetteAreaButton, 0, dp(6));
    }

    private void selectPipetteArea(ColorAnalyzer.AreaSize size) {
        pipetteAreaSize = size;
        if (pipetteAreaPopupWindow != null) pipetteAreaPopupWindow.dismiss();
        updatePipetteAreaUi();
        if (pipetteOverlay != null) pipetteOverlay.setAreaSize(size);
        if (lastPipetteSourceX >= 0 && lastPipetteSourceY >= 0
                && (lastPipetteViewX > 0 || lastPipetteViewY > 0)) {
            sampleAtPreviewPoint(lastPipetteViewX, lastPipetteViewY);
        }
        haptic(pipetteAreaButton);
    }

    private void updatePipetteAreaUi() {
        if (pipetteAreaButton != null) {
            pipetteAreaButton.setText("MESSFLÄCHE · " + pipetteAreaSize.label.toUpperCase(Locale.GERMANY) + "  ▾");
            pipetteAreaButton.setEnabled(currentSource != null);
        }
        if (pipetteOverlay != null) pipetteOverlay.setAreaSize(pipetteAreaSize);
    }

    private void showRecognitionPopup() {
        if (recognitionButton == null || recognitionButton.getVisibility() != View.VISIBLE) return;
        if (recognitionPopupWindow == null) buildRecognitionPopup();
        if (recognitionPopupWindow.isShowing()) {
            recognitionPopupWindow.dismiss();
            return;
        }
        recognitionPopupWindow.showAsDropDown(recognitionButton, 0, dp(6));
    }

    private void selectRecognitionMode(RecognitionMode mode) {
        recognitionMode = mode;
        if (recognitionPopupWindow != null) recognitionPopupWindow.dismiss();
        updateRecognitionUi();
        if (currentSource != null && (!cameraMode || cameraFrozen)) {
            refreshCurrentMedia();
            statusText.setText(mode == RecognitionMode.OFF
                    ? "Standbild · normaler Filter aktiv"
                    : mode.label + " · Erkennung aktiv");
            if (cameraScroll != null && mode != RecognitionMode.OFF) {
                cameraScroll.post(() -> cameraScroll.smoothScrollTo(0, Math.max(0, recognitionButton.getTop() - dp(12))));
            }
        }
        haptic(recognitionButton);
    }

    private void updateRecognitionUi() {
        if (recognitionButton == null) return;
        boolean available = currentSource != null && (!cameraMode || cameraFrozen);
        recognitionButton.setVisibility(available ? View.VISIBLE : View.GONE);
        if (!available) return;
        recognitionButton.setText(recognitionMode == RecognitionMode.OFF
                ? "FARBEN VERSCHIEBEN  ▾"
                : "ERKENNUNG · " + recognitionMode.label + "  ▾");
        recognitionButton.setTextColor(recognitionMode == RecognitionMode.OFF
                ? text : Color.rgb(20, 30, 14));
        recognitionButton.setBackground(roundDrawable(
                recognitionMode == RecognitionMode.OFF ? surfaceTwo : accent, dp(11)));
    }

    private void showFilterPopup() {
        if (filterPopupWindow == null) buildFilterPopup();
        if (filterPopupWindow.isShowing()) {
            filterPopupWindow.dismiss();
            return;
        }
        filterPopupWindow.showAsDropDown(filterMenuButton, 0, dp(6));
    }

    private LinearLayout buildAboutPage() {
        LinearLayout page = column();
        LinearLayout hero = column();
        hero.setPadding(dp(16), dp(16), dp(16), dp(14));
        hero.setBackground(roundDrawable(surfaceTwo, dp(18)));

        LinearLayout heroHeader = new LinearLayout(this);
        heroHeader.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        int logoId = getResources().getIdentifier("ic_sehplus", "drawable", getPackageName());
        if (logoId != 0) logo.setImageResource(logoId);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        heroHeader.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout heroCopy = new LinearLayout(this);
        heroCopy.setOrientation(LinearLayout.VERTICAL);
        heroCopy.setPadding(dp(12), 0, 0, 0);
        TextView heroTitle = label("SehPlus", 21, text);
        heroTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView heroTagline = label("Farben sicherer unterscheiden", 12, muted);
        heroTagline.setPadding(0, dp(3), 0, 0);
        heroCopy.addView(heroTitle);
        heroCopy.addView(heroTagline);
        heroHeader.addView(heroCopy, new LinearLayout.LayoutParams(0, -2, 1));
        hero.addView(heroHeader);

        TextView heroDescription = label("Lokal verarbeitet · für deinen Alltag", 11, muted);
        heroDescription.setPadding(dp(4), dp(12), 0, dp(8));
        hero.addView(heroDescription);
        LinearLayout badges = new LinearLayout(this);
        badges.setGravity(Gravity.CENTER_VERTICAL);
        badges.addView(pill("OFFLINE", accent, Color.rgb(43, 69, 26)), new LinearLayout.LayoutParams(-2, dp(28)));
        badges.addView(space(dp(7)), new LinearLayout.LayoutParams(dp(7), 1));
        badges.addView(pill("LOKAL", accent, Color.rgb(43, 69, 26)), new LinearLayout.LayoutParams(-2, dp(28)));
        badges.addView(space(dp(7)), new LinearLayout.LayoutParams(dp(7), 1));
        badges.addView(pill("KEIN KONTO", accent, Color.rgb(43, 69, 26)), new LinearLayout.LayoutParams(-2, dp(28)));
        hero.addView(badges);
        page.addView(hero);
        page.addView(verticalGap(18));

        page.addView(aboutGroupLabel("SCHNELLZUGRIFF"));
        page.addView(verticalGap(8));
        LinearLayout quickActions = new LinearLayout(this);
        quickActions.setGravity(Gravity.CENTER_VERTICAL);
        View donationCard = aboutActionCard("Freiwillig unterstützen", "Entwicklung helfen", true,
                "SehPlus-Entwicklung freiwillig unterstützen", v -> openDonationPage());
        View feedbackCard = aboutActionCard("Verbesserung senden",
                legalConfig.hasFeedback() ? "Feedback direkt teilen" : "Noch nicht eingerichtet", false,
                legalConfig.hasFeedback() ? "Verbesserungsvorschlag an SehPlus senden" : "Feedback noch nicht eingerichtet",
                v -> openFeedbackForm());
        feedbackCard.setEnabled(legalConfig.hasFeedback());
        feedbackCard.setClickable(legalConfig.hasFeedback());
        feedbackCard.setAlpha(legalConfig.hasFeedback() ? 1f : 0.55f);
        quickActions.addView(donationCard, new LinearLayout.LayoutParams(0, dp(68), 1));
        quickActions.addView(space(dp(12)), new LinearLayout.LayoutParams(dp(12), 1));
        quickActions.addView(feedbackCard, new LinearLayout.LayoutParams(0, dp(68), 1));
        page.addView(quickActions);
        page.addView(aboutDivider());

        List<View> panels = new ArrayList<>();
        List<TextView> arrows = new ArrayList<>();

        LinearLayout appContent = column();
        appContent.addView(infoCard("SehPlus ColorAssist", "Farbfilter, Standbild, Zoom und Pipette werden direkt auf dem Gerät verarbeitet."));
        TextView appNote = label("SehPlus ist eine visuelle Alltagshilfe und ersetzt keine medizinische Untersuchung.", 11, muted);
        appNote.setPadding(dp(4), dp(10), dp(4), dp(2));
        appNote.setLineSpacing(0, 1.15f);
        appContent.addView(appNote);
        LinearLayout featureRow = new LinearLayout(this);
        featureRow.addView(aboutFeatureTile("FILTER", "Farben hervorheben"), new LinearLayout.LayoutParams(0, dp(68), 1));
        featureRow.addView(space(dp(6)), new LinearLayout.LayoutParams(dp(6), 1));
        featureRow.addView(aboutFeatureTile("PIPETTE", "Farbe messen"), new LinearLayout.LayoutParams(0, dp(68), 1));
        featureRow.addView(space(dp(6)), new LinearLayout.LayoutParams(dp(6), 1));
        featureRow.addView(aboutFeatureTile("STANDBILD", "Genau lesen"), new LinearLayout.LayoutParams(0, dp(68), 1));
        appContent.addView(verticalGap(12));
        appContent.addView(featureRow);
        page.addView(aboutAccordionSection("ÜBER SEHPLUS", "Lokale Farbhilfe für deinen Alltag", appContent, true, panels, arrows));

        LinearLayout helpContent = column();
        Button onboardingButton = actionButton("EINWEISUNG ERNEUT ANZEIGEN", false);
        onboardingButton.setContentDescription("Einweisung erneut anzeigen");
        onboardingButton.setOnClickListener(v -> showOnboarding());
        helpContent.addView(onboardingButton, new LinearLayout.LayoutParams(-1, dp(46)));
        helpContent.addView(verticalGap(10));
        helpContent.addView(infoCard("Licht und Farberkennung", "Gleichmäßiges Umgebungslicht, wenig Spiegelungen und matte Flächen machen die Messung zuverlässiger."));
        helpContent.addView(verticalGap(10));
        helpContent.addView(infoCard("Farbwissen", colorTip()));
        page.addView(aboutAccordionSection("HILFE & NUTZUNG", "Einweisung, Licht-Hinweise und Alltagstipps", helpContent, false, panels, arrows));

        LinearLayout toolsContent = column();
        toolsContent.addView(infoCard("Offline-Werkzeuge", "Beispiele und Farbmessungen bleiben auf dem Gerät und benötigen keine Kamera oder Internetverbindung."));
        toolsContent.addView(verticalGap(10));
        Button testLabButton = actionButton("OFFLINE-TESTLABOR", false);
        testLabButton.setContentDescription("Lokale Beispielbilder ohne Kamera öffnen");
        testLabButton.setOnClickListener(v -> showTestLabDialog());
        toolsContent.addView(testLabButton, new LinearLayout.LayoutParams(-1, dp(46)));
        toolsContent.addView(verticalGap(10));
        Button notesButton = actionButton("LOKALE FARBNOTIZEN", false);
        notesButton.setContentDescription("Gespeicherte lokale Farbmessungen anzeigen");
        notesButton.setOnClickListener(v -> showColorNotes());
        toolsContent.addView(notesButton, new LinearLayout.LayoutParams(-1, dp(46)));
        page.addView(aboutAccordionSection("WERKZEUGE", "Offline-Testlabor und lokale Farbmemos", toolsContent, false, panels, arrows));

        LinearLayout privacyContent = column();
        privacyContent.addView(infoCard("Lokale Verarbeitung", "Es ist kein Konto nötig. Kamera-, Foto- und Videodaten werden für die Farbhilfe direkt auf diesem Gerät verarbeitet und nicht automatisch an SehPlus übertragen."));
        privacyContent.addView(verticalGap(10));
        privacyContent.addView(infoCard("Berechtigungen", "Die Kamera startet erst nach deiner Aktion und wird nur für die Kameraansicht verwendet. Bilder werden nur gespeichert oder geteilt, wenn du das selbst auswählst."));
        privacyContent.addView(verticalGap(10));
        privacyContent.addView(infoCard("Externe Seiten", "Das Feedback-Formular und die freiwillige Spende öffnen externe Anbieter erst nach deinem Tippen. Dort gelten deren eigene Datenschutz- und Nutzungsbedingungen; SehPlus verarbeitet keine Zahlungsdaten."));
        privacyContent.addView(verticalGap(10));
        privacyContent.addView(infoCard("Speicherung und Sicherungen", "Farbnotizen und Einstellungen bleiben in der App gespeichert. SehPlus schließt seine Appdaten von Android-Cloud-Backups und unterstützten Geräteübertragungen aus. Bereits bestehende Sicherungen und selbst exportierte Galeriebilder sind davon nicht betroffen."));
        privacyContent.addView(verticalGap(10));
        privacyContent.addView(infoCard("Datenschutz zum Nachlesen", "Die vollständigen Rechtstexte sind direkt in SehPlus gespeichert und auch ohne Internet lesbar. Dort findest du Informationen zu Verarbeitung, Löschung, Kontakt und deinen Rechten."));
        privacyContent.addView(verticalGap(10));
        LinearLayout legalActions = new LinearLayout(this);
        Button privacyButton = actionButton("DATENSCHUTZ", false);
        privacyButton.setContentDescription("Vollständige Datenschutzerklärung offline lesen");
        privacyButton.setOnClickListener(v -> openLegalDocument("privacy.html"));
        Button imprintButton = actionButton("IMPRESSUM", false);
        imprintButton.setContentDescription("Anbieterkennzeichnung offline lesen");
        imprintButton.setOnClickListener(v -> openLegalDocument("impressum.html"));
        legalActions.addView(privacyButton, new LinearLayout.LayoutParams(0, -2, 1));
        legalActions.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
        legalActions.addView(imprintButton, new LinearLayout.LayoutParams(0, -2, 1));
        privacyContent.addView(legalActions);
        privacyContent.addView(verticalGap(10));
        privacyContent.addView(infoCard("Medizinischer Hinweis", "SehPlus ist eine visuelle Alltagshilfe und ersetzt keine augenärztliche Untersuchung oder medizinische Diagnose."));
        page.addView(aboutAccordionSection("DATENSCHUTZ & RECHTLICHES", "Lokal verarbeitet und selbstbestimmt genutzt", privacyContent, false, panels, arrows));

        LinearLayout developerContent = column();
        String version = "unbekannt";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) { }
        LinearLayout versionRow = new LinearLayout(this);
        versionRow.setGravity(Gravity.CENTER_VERTICAL);
        versionRow.addView(pill("VERSION " + version, accent, Color.rgb(43, 69, 26)),
                new LinearLayout.LayoutParams(-2, dp(28)));
        versionRow.addView(space(dp(8)), new LinearLayout.LayoutParams(dp(8), 1));
        TextView versionInfo = label("SehPlus ColorAssist v2", 11, muted);
        versionRow.addView(versionInfo, new LinearLayout.LayoutParams(0, -2, 1));
        developerContent.addView(versionRow);

        TextView developer = label("Unabhängig entwickelt, um Farberkennung im Alltag einfacher zu machen.\n"
                + "Offline-first · keine medizinische Diagnose", 11, muted);
        developer.setPadding(dp(4), dp(4), dp(4), dp(2));
        developer.setLineSpacing(0, 1.15f);
        developerContent.addView(developer);
        developerContent.addView(verticalGap(10));
        Button reportButton = actionButton("TESTBERICHT TEILEN", false);
        reportButton.setContentDescription("Technischen SehPlus-Testbericht teilen");
        reportButton.setOnClickListener(v -> shareTestReport());
        developerContent.addView(reportButton, new LinearLayout.LayoutParams(-1, dp(46)));
        developerContent.addView(verticalGap(10));
        if (!legalConfig.publicationReady) {
            developerContent.addView(infoCard("Rechtstexte im Entwurf", "Die Funktionen können getestet werden. Die markierten Angaben in Datenschutz und Anbieterkennzeichnung werden vor einer öffentlichen Veröffentlichung ergänzt."));
        }
        page.addView(aboutAccordionSection("ENTWICKLER & VERSION", "Version, Hinweise und Testbericht", developerContent, false, panels, arrows));
        page.addView(verticalGap(4));
        return page;
    }

    private LinearLayout aboutAccordionSection(String title, String summary, View content,
                                               boolean expanded, List<View> panels,
                                               List<TextView> arrows) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(0, 0, 0, dp(10));

        if (!panels.isEmpty()) {
            View separator = new View(this);
            separator.setBackgroundColor(divider);
            LinearLayout.LayoutParams separatorParams = new LinearLayout.LayoutParams(-1, dp(1));
            separatorParams.setMargins(dp(12), 0, dp(12), dp(10));
            card.addView(separator, separatorParams);
        }

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setMinimumHeight(dp(58));
        header.setPadding(dp(14), dp(8), dp(12), dp(8));
        header.setBackground(roundDrawable(surfaceTwo, dp(12)));
        header.setContentDescription(title + ". " + summary + ". Bereich öffnen oder schließen.");

        View marker = new View(this);
        marker.setBackground(roundDrawable(expanded ? accent : divider, dp(2)));
        header.addView(marker, new LinearLayout.LayoutParams(dp(4), dp(28)));
        header.addView(space(dp(10)), new LinearLayout.LayoutParams(dp(10), 1));

        LinearLayout headerCopy = new LinearLayout(this);
        headerCopy.setOrientation(LinearLayout.VERTICAL);
        TextView headerTitle = label(title, 11, text);
        headerTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView headerSummary = label(summary, 10, muted);
        headerSummary.setPadding(0, dp(3), 0, 0);
        headerCopy.addView(headerTitle);
        headerCopy.addView(headerSummary);
        TextView arrow = label(expanded ? "▲" : "▼", 13, muted);
        arrow.setGravity(Gravity.CENTER);
        header.addView(headerCopy, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(arrow, new LinearLayout.LayoutParams(dp(30), -1));

        panels.add(content);
        arrows.add(arrow);
        content.setVisibility(expanded ? View.VISIBLE : View.GONE);
        header.setOnClickListener(v -> {
            boolean open = content.getVisibility() != View.VISIBLE;
            if (open) {
                for (int index = 0; index < panels.size(); index++) {
                    panels.get(index).setVisibility(View.GONE);
                    arrows.get(index).setText("▼");
                }
            }
            content.setVisibility(open ? View.VISIBLE : View.GONE);
            arrow.setText(open ? "▲" : "▼");
            marker.setBackground(roundDrawable(open ? accent : divider, dp(2)));
        });

        card.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));
        card.addView(content, new LinearLayout.LayoutParams(-1, -2));
        return card;
    }

    private TextView aboutGroupLabel(String value) {
        TextView title = label(value, 10, muted);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        title.setPadding(dp(4), 0, dp(4), 0);
        return title;
    }

    private View aboutDivider() {
        View separator = new View(this);
        separator.setBackgroundColor(divider);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.setMargins(dp(12), dp(20), dp(12), dp(10));
        separator.setLayoutParams(params);
        return separator;
    }

    private LinearLayout aboutActionCard(String title, String summary, boolean primary,
                                         String contentDescription, View.OnClickListener listener) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(9), dp(12), dp(9));
        card.setBackground(roundDrawable(primary ? accent : surfaceTwo, dp(14)));
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription(contentDescription);
        card.setOnClickListener(listener);

        TextView titleView = label(title, 10, primary ? Color.rgb(20, 30, 14) : text);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView summaryView = label(summary, 9, primary ? Color.rgb(43, 69, 26) : muted);
        summaryView.setPadding(0, dp(3), 0, 0);
        card.addView(titleView);
        card.addView(summaryView);
        return card;
    }

    private LinearLayout aboutFeatureTile(String title, String summary) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(5), dp(8), dp(5), dp(8));
        tile.setBackground(roundDrawable(surface, dp(12)));

        TextView titleView = label(title, 9, text);
        titleView.setGravity(Gravity.CENTER);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView summaryView = label(summary, 9, muted);
        summaryView.setGravity(Gravity.CENTER);
        summaryView.setPadding(0, dp(3), 0, 0);
        tile.addView(titleView, new LinearLayout.LayoutParams(-1, -2));
        tile.addView(summaryView, new LinearLayout.LayoutParams(-1, -2));
        return tile;
    }

    private TextView infoCard(String title, String body) {
        TextView card = label(title + "\n" + body, 12, text);
        card.setBackground(roundDrawable(surfaceTwo, dp(14)));
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setLineSpacing(0, 1.15f);
        return card;
    }

    private void showTestLabDialog() {
        String[] labels = new String[TestLabSample.values().length];
        for (int index = 0; index < labels.length; index++) labels[index] = TestLabSample.values()[index].label;
        new AlertDialog.Builder(this)
                .setTitle("Offline-Testlabor")
                .setMessage("Lokale Beispielbilder zum Prüfen von Pipette, Farben verschieben, Zoom und Whiteboard-Erkennung.")
                .setItems(labels, (dialog, which) -> loadTestLabSample(TestLabSample.values()[which]))
                .setNegativeButton("ABBRECHEN", null)
                .show();
    }

    private void loadTestLabSample(TestLabSample sample) {
        stopCamera();
        stopVideo();
        clearCurrentMedia();
        currentUri = null;
        currentSource = createTestLabBitmap(sample);
        cameraMode = false;
        cameraFrozen = false;
        showingOriginal = false;
        recognitionMode = RecognitionMode.OFF;
        zoomPreview.markNeedsFit();
        resetZoomControls();
        refreshCurrentMedia();
        freezeButton.setText("STANDBILD");
        freezeButton.setEnabled(false);
        cameraButton.setText("KAMERA STARTEN");
        cameraButton.setEnabled(true);
        statusText.setText("Offline-Testlabor · " + sample.label);
        switchPage(0);
        cameraScroll.post(() -> cameraScroll.smoothScrollTo(0, 0));
    }

    private Bitmap createTestLabBitmap(TestLabSample sample) {
        int width = 900;
        int height = 1200;
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (sample == TestLabSample.BEIGE_STOFF) {
            canvas.drawColor(Color.rgb(197, 160, 121));
            drawTexture(canvas, paint, width, height, Color.rgb(173, 135, 98), Color.rgb(222, 190, 153), 18);
        } else if (sample == TestLabSample.BLAU_GRAU_STOFF) {
            canvas.drawColor(Color.rgb(124, 139, 153));
            drawTexture(canvas, paint, width, height, Color.rgb(93, 110, 126), Color.rgb(178, 190, 199), 22);
        } else if (sample == TestLabSample.WARMES_INNENLICHT) {
            canvas.drawColor(Color.rgb(211, 174, 131));
            paint.setColor(Color.rgb(239, 223, 196));
            canvas.drawRoundRect(95, 150, 805, 1050, 48, 48, paint);
            paint.setColor(Color.rgb(184, 145, 102));
            for (int y = 200; y < 1010; y += 70) canvas.drawLine(130, y, 770, y + 18, paint);
        } else if (sample == TestLabSample.FARBKANTE) {
            canvas.drawColor(Color.rgb(215, 188, 151));
            paint.setColor(Color.rgb(112, 132, 145));
            Path edge = new Path();
            edge.moveTo(420, 0);
            edge.lineTo(width, 0);
            edge.lineTo(width, height);
            edge.lineTo(520, height);
            edge.close();
            canvas.drawPath(edge, paint);
            paint.setColor(Color.rgb(245, 235, 214));
            paint.setStrokeWidth(18);
            canvas.drawLine(410, 0, 510, height, paint);
        } else if (sample == TestLabSample.TESTPUNKTE) {
            canvas.drawColor(Color.rgb(247, 244, 230));
            drawDotPlate(canvas, paint, 300, 380, 235, 0);
            drawDotPlate(canvas, paint, 660, 380, 235, 1);
            drawDotPlate(canvas, paint, 300, 850, 235, 2);
            drawDotPlate(canvas, paint, 660, 850, 235, 3);
        } else {
            canvas.drawColor(Color.rgb(247, 247, 239));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4);
            paint.setColor(Color.rgb(203, 208, 202));
            for (int x = 50; x < width; x += 90) canvas.drawLine(x, 80, x, height - 70, paint);
            for (int y = 120; y < height; y += 90) canvas.drawLine(40, y, width - 40, y, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(40, 54, 68));
            paint.setTextSize(64);
            canvas.drawText("Farbtest 16", 90, 260, paint);
            paint.setColor(Color.rgb(151, 60, 71));
            paint.setStrokeWidth(18);
            canvas.drawLine(110, 430, 780, 530, paint);
            paint.setColor(Color.rgb(55, 106, 146));
            canvas.drawLine(110, 650, 780, 600, paint);
            paint.setColor(Color.rgb(60, 133, 92));
            canvas.drawCircle(260, 880, 74, paint);
            paint.setColor(Color.rgb(215, 150, 55));
            canvas.drawCircle(590, 880, 74, paint);
        }
        return bitmap;
    }

    private void drawTexture(Canvas canvas, Paint paint, int width, int height, int dark, int light, int spacing) {
        paint.setStrokeWidth(5);
        for (int x = -height; x < width + height; x += spacing) {
            paint.setColor(dark);
            canvas.drawLine(x, 0, x + height, height, paint);
            paint.setColor(light);
            canvas.drawLine(x + 7, 0, x + height + 7, height, paint);
        }
    }

    private void drawDotPlate(Canvas canvas, Paint paint, int centerX, int centerY, int radius, int variant) {
        paint.setColor(Color.rgb(237, 235, 222));
        canvas.drawCircle(centerX, centerY, radius, paint);
        int[] colors = new int[]{
                Color.rgb(219, 174, 40), Color.rgb(112, 126, 42), Color.rgb(62, 92, 86),
                Color.rgb(145, 84, 52), Color.rgb(94, 94, 100)
        };
        for (int row = -7; row <= 7; row++) {
            for (int column = -7; column <= 7; column++) {
                float distance = (float) Math.hypot(row, column);
                if (distance > 7.1f) continue;
                int pattern = Math.abs(row * 17 + column * 31 + variant * 13);
                int colorIndex = (pattern + (distance < 3.8f ? variant + 1 : 0)) % colors.length;
                float x = centerX + column * 27f + (row % 2 == 0 ? 7f : 0f);
                float y = centerY + row * 27f;
                paint.setColor(colors[colorIndex]);
                canvas.drawCircle(x, y, 8f + pattern % 6, paint);
            }
        }
        paint.setColor(variant % 2 == 0 ? Color.rgb(215, 175, 39) : Color.rgb(63, 83, 101));
        paint.setTextSize(112);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        canvas.drawText(variant % 2 == 0 ? "16" : "8", centerX - 62, centerY + 42, paint);
        paint.setTypeface(null);
    }

    private void showColorNotes() {
        String notes = getSharedPreferences("sehplus_preferences", MODE_PRIVATE)
                .getString("color_notes", "");
        if (notes.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Lokale Farbnotizen")
                    .setMessage("Noch keine Messung gespeichert.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Lokale Farbnotizen")
                .setMessage(notes.replace("\n", "\n\n"))
                .setNegativeButton("SCHLIESSEN", null)
                .setPositiveButton("ALLE LÖSCHEN", (dialog, which) -> getSharedPreferences("sehplus_preferences", MODE_PRIVATE)
                        .edit().remove("color_notes").apply())
                .show();
    }

    private void openDonationPage() {
        openExternalPage(DONATION_URL, "SehPlus Unterstützung", "Kein Browser verfügbar. Der Spenden-Link wurde kopiert.");
    }

    private void openLegalDocument(String document) {
        startActivity(new Intent(this, LegalActivity.class).putExtra(LegalActivity.EXTRA_DOCUMENT, document));
    }

    private void openFeedbackForm() {
        if (!legalConfig.hasFeedback()) {
            Toast.makeText(this, "Das Feedback-Formular ist noch nicht eingerichtet.", Toast.LENGTH_LONG).show();
            return;
        }
        openExternalPage(legalConfig.feedbackUrl, "SehPlus Feedback", "Kein Browser verfügbar. Der Feedback-Link wurde kopiert.");
    }

    private void openExternalPage(String url, String clipLabel, String fallbackMessage) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception exception) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText(clipLabel, url));
            }
            Toast.makeText(this, fallbackMessage, Toast.LENGTH_LONG).show();
        }
    }

    private void shareTestReport() {
        String report = buildTestReport();
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "SehPlus Testbericht");
        share.putExtra(Intent.EXTRA_TEXT, report);
        try {
            startActivity(Intent.createChooser(share, "SehPlus-Testbericht teilen"));
        } catch (Exception exception) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("SehPlus Testbericht", report));
            }
            Toast.makeText(this, "Kein Teilen-Menü verfügbar. Bericht wurde kopiert.", Toast.LENGTH_LONG).show();
        }
    }

    private String buildTestReport() {
        String version = "unbekannt";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) { }
        String cameraState = cameraUiState.label;
        String error = lastCameraError.isEmpty() ? "keiner" : lastCameraError;
        return "SehPlus Testbericht\n"
                + "Zeitpunkt: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + "\n"
                + "Version: " + version + "\n"
                + "Gerät: " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                + "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n"
                + "Kamerastatus: " + cameraState + "\n"
                + "Letzter Kamerafehler: " + error + "\n"
                + "Farbprofil: " + selectedProfile.shortName + "\n"
                + "Lichtkalibrierung: " + (pipetteCalibration == null ? "aus" : "aktiv") + "\n"
                + "Taschenlampe: " + (torchAvailable ? "verfügbar" : "nicht verfügbar") + "\n\n"
                + "Keine Bilder oder persönlichen Inhalte wurden in diesen Bericht aufgenommen.";
    }

    private String colorTip() {
        String[] tips = {
                "Tipp: Eine gleichmäßige, helle Beleuchtung macht die Pipettenmessung zuverlässiger.",
                "Tipp: Nutze den Zoom im Standbild, wenn du eine kleine Farbfläche genau treffen möchtest.",
                "Tipp: Die HEX- und RGB-Werte sind genauer als ein beschreibender Farbname.",
                "Tipp: Matte Flächen lassen sich meist zuverlässiger messen als glänzende Oberflächen.",
                "Tipp: Prüfe wichtige Farben immer unter dem Licht, unter dem du sie später brauchst."
        };
        int index = (int) (System.currentTimeMillis() / 86400000L % tips.length);
        return tips[index];
    }

    private LinearLayout buildSettingsPage() {
        LinearLayout page = column();
        TextView heading = label("Einstellungen", 20, text);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(heading);
        TextView description = label("Kamera, Medien und Farbwerkzeuge sind jederzeit verfügbar.", 12, muted);
        description.setPadding(dp(4), dp(4), dp(4), dp(12));
        page.addView(description);
        LinearLayout preferences = column();
        autoEnhanceSwitch = settingSwitch("Automatische Helligkeit und Kontrast", "Passt schwierige Lichtverhältnisse vorsichtig an.", autoEnhance);
        hapticsSwitch = settingSwitch("Haptisches Feedback", "Kurze Rückmeldung bei Pipette und Zoom.", hapticsEnabled);
        autoEnhanceSwitch.setOnCheckedChangeListener((button, checked) -> {
            autoEnhance = checked;
            savePreferences();
            refreshCurrentMedia();
        });
        hapticsSwitch.setOnCheckedChangeListener((button, checked) -> {
            hapticsEnabled = checked;
            savePreferences();
        });
        preferences.addView(autoEnhanceSwitch, new LinearLayout.LayoutParams(-1, dp(52)));
        preferences.addView(hapticsSwitch, new LinearLayout.LayoutParams(-1, dp(52)));
        page.addView(collapsibleCard("Anzeige und Bedienung", "Automatik und Feedback", preferences, true));
        performanceStatus = label("Gerätestatus wird geladen …", 12, muted);
        performanceStatus.setPadding(dp(4), dp(8), dp(4), dp(8));
        Button refreshStatus = actionButton("STATUS AKTUALISIEREN", false);
        refreshStatus.setOnClickListener(v -> updateDeviceStatus());
        LinearLayout statusContent = column();
        statusContent.addView(performanceStatus);
        statusContent.addView(refreshStatus, new LinearLayout.LayoutParams(-1, dp(40)));
        page.addView(collapsibleCard("Akku und Performance", "Kompakte Geräteinformationen", statusContent, false));
        TextView note = label("SehPlus unterstützt die Farbwahrnehmung, ersetzt aber keine medizinische Untersuchung. Farben können je nach Licht und Kamera abweichen.", 11, muted);
        note.setPadding(dp(4), dp(16), dp(4), dp(4));
        note.setLineSpacing(0, 1.15f);
        page.addView(note);
        return page;
    }

    private Space space(int width) {
        return new Space(this);
    }

    private View verticalGap(int height) {
        Space gap = new Space(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return gap;
    }

    private Switch settingSwitch(String title, String summary, boolean checked) {
        Switch setting = new Switch(this);
        setting.setText(title + "\n" + summary);
        setting.setTextColor(text);
        setting.setTextSize(12);
        setting.setChecked(checked);
        setting.setPadding(dp(4), dp(4), dp(4), dp(4));
        return setting;
    }

    private LinearLayout collapsibleCard(String title, String summary, View content, boolean expanded) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(0, dp(5), 0, dp(8));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(7), dp(12), dp(7));
        header.setBackground(roundDrawable(surfaceTwo, dp(11)));
        TextView headerText = label(title + "\n" + summary, 11, text);
        headerText.setLineSpacing(0, 1.05f);
        TextView arrow = label(expanded ? "▲" : "▼", 13, muted);
        arrow.setGravity(Gravity.CENTER);
        header.addView(headerText, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(arrow, new LinearLayout.LayoutParams(dp(28), -1));
        content.setVisibility(expanded ? View.VISIBLE : View.GONE);
        header.setOnClickListener(v -> {
            boolean open = content.getVisibility() != View.VISIBLE;
            content.setVisibility(open ? View.VISIBLE : View.GONE);
            arrow.setText(open ? "▲" : "▼");
        });
        card.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));
        card.addView(content, new LinearLayout.LayoutParams(-1, -2));
        return card;
    }

    private void switchPage(int page) {
        if (cameraPage == null || aboutPage == null || settingsPage == null) return;
        cameraPage.setVisibility(page == 0 ? View.VISIBLE : View.GONE);
        aboutPage.setVisibility(page == 1 ? View.VISIBLE : View.GONE);
        settingsPage.setVisibility(page == 2 ? View.VISIBLE : View.GONE);
        updateTabButton(cameraTab, page == 0);
        updateTabButton(aboutTab, page == 1);
        updateTabButton(settingsTab, page == 2);
        if (page == 2) updateDeviceStatus();
    }

    private void updateTabButton(Button button, boolean selected) {
        if (button == null) return;
        button.setTextColor(selected ? Color.rgb(20, 30, 14) : text);
        button.setBackground(roundStroke(selected ? accent : divider,
                selected ? accent : surfaceTwo, dp(10)));
    }

    private void savePreferences() {
        getSharedPreferences("sehplus_preferences", MODE_PRIVATE).edit()
                .putBoolean("auto_enhance", autoEnhance)
                .putBoolean("haptics", hapticsEnabled)
                .putString("profile", selectedProfile.name())
                .apply();
    }

    private void updateDeviceStatus() {
        if (batteryStatus == null) return;
        BatteryManager battery = (BatteryManager) getSystemService(BATTERY_SERVICE);
        int level = battery == null ? -1 : battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        batteryStatus.setText(level >= 0 ? "Akku " + level + "%" : "Akku --");
        if (performanceStatus != null) {
            ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
            if (manager != null) manager.getMemoryInfo(memory);
            long freeMb = memory.availMem / (1024L * 1024L);
            String camera = cameraMode ? "Kamera aktiv" : "Kamera inaktiv";
            performanceStatus.setText("Akku: " + (level >= 0 ? level + "%" : "unbekannt")
                    + "\nFreier Arbeitsspeicher: " + freeMb + " MB\n" + camera);
        }
    }

    private void haptic(View source) {
        if (hapticsEnabled && source != null) {
            source.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
    }

    private void resetZoomControls() {
        if (zoomPreview != null) zoomPreview.resetZoom();
        boolean enabled = currentSource != null && (!cameraMode || cameraFrozen);
        if (zoomOutButton != null) zoomOutButton.setEnabled(enabled);
        if (zoomResetButton != null) zoomResetButton.setEnabled(enabled);
        if (zoomInButton != null) zoomInButton.setEnabled(enabled);
        if (zoomValue != null) zoomValue.setText(enabled ? "Zoom 1× · Pinch oder Tasten" : "Zoom nur im Standbild");
    }

    private void updateZoomLabel(float value) {
        if (zoomValue != null) zoomValue.setText(String.format(Locale.US, "Zoom %.1f×", value));
        boolean enabled = currentSource != null && (!cameraMode || cameraFrozen);
        if (zoomOutButton != null) zoomOutButton.setEnabled(enabled && value > 1.01f);
        if (zoomResetButton != null) zoomResetButton.setEnabled(enabled);
        if (zoomInButton != null) zoomInButton.setEnabled(enabled && value < 7.99f);
    }

    private void renderPreview() {
        if (currentSource == null || currentDisplay == null || preview == null) return;
        preview.setImageBitmap(showingOriginal ? currentSource : currentDisplay);
        if (compareButton != null) {
            compareButton.setText(showingOriginal ? "FILTER ANZEIGEN" : "NORMALANSICHT");
            compareButton.setEnabled(true);
        }
    }

    private void toggleComparison() {
        if (currentSource == null || currentDisplay == null) return;
        showingOriginal = !showingOriginal;
        renderPreview();
        haptic(compareButton);
    }

    private class ZoomImageView extends ImageView {
        private final Matrix transform = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private float zoom = 1f;
        private boolean needsFit = true;
        private float lastX;
        private float lastY;
        private boolean dragging;
        private long lastTapTime;
        private float downX;
        private float downY;

        ZoomImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    if (currentSource == null || (!cameraFrozen && cameraMode)) return false;
                    float oldZoom = zoom;
                    zoom = Math.max(1f, Math.min(8f, zoom * detector.getScaleFactor()));
                    float factor = zoom / oldZoom;
                    transform.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                    clampTransform();
                    setImageMatrix(transform);
                    updateZoomLabel(zoom);
                    return true;
                }
            });
            setFocusable(true);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (colorCompareMode && currentSource != null) {
                if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                    sampleAtPreviewPoint(event.getX(), event.getY());
                    haptic(this);
                }
                return true;
            }
            if (pipetteMode && currentSource != null) {
                if (event.getAction() == MotionEvent.ACTION_DOWN
                        || event.getAction() == MotionEvent.ACTION_MOVE
                        || event.getAction() == MotionEvent.ACTION_UP) {
                    sampleAtPreviewPoint(event.getX(), event.getY());
                    if (event.getAction() == MotionEvent.ACTION_UP) haptic(this);
                    return true;
                }
            }
            scaleDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    downX = lastX;
                    downY = lastY;
                    dragging = true;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && zoom > 1f && event.getPointerCount() == 1) {
                        float dx = event.getX() - lastX;
                        float dy = event.getY() - lastY;
                        transform.postTranslate(dx, dy);
                        clampTransform();
                        setImageMatrix(transform);
                        lastX = event.getX();
                        lastY = event.getY();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    if (event.getActionMasked() == MotionEvent.ACTION_UP
                            && Math.hypot(event.getX() - downX, event.getY() - downY) < dp(24)) {
                        long now = android.os.SystemClock.uptimeMillis();
                        if (now - lastTapTime < 320) {
                            changeZoom(zoom < 1.5f ? 2f : 0.5f);
                            lastTapTime = 0;
                        } else {
                            lastTapTime = now;
                        }
                    }
                    return true;
                default:
                    return true;
            }
        }

        void changeZoom(float factor) {
            if (currentSource == null || (!cameraFrozen && cameraMode)) return;
            float oldZoom = zoom;
            zoom = Math.max(1f, Math.min(8f, zoom * factor));
            float actualFactor = zoom / oldZoom;
            transform.postScale(actualFactor, actualFactor, getWidth() / 2f, getHeight() / 2f);
            clampTransform();
            setImageMatrix(transform);
            updateZoomLabel(zoom);
            if (Math.abs(zoom - oldZoom) > 0.01f) haptic(this);
        }

        void markNeedsFit() {
            needsFit = true;
            post(this::fitToViewIfNeeded);
        }

        private void fitToViewIfNeeded() {
            if (!needsFit) return;
            resetZoom();
        }

        void resetZoom() {
            zoom = 1f;
            if (getDrawable() == null) {
                transform.reset();
                setImageMatrix(transform);
                needsFit = false;
                updateZoomLabel(zoom);
                return;
            }
            if (getWidth() <= 0 || getHeight() <= 0) {
                post(this::resetZoom);
                return;
            }
            float imageWidth = getDrawable().getIntrinsicWidth();
            float imageHeight = getDrawable().getIntrinsicHeight();
            // Live frames fill the same large portrait area as a still image.
            // Keep the complete image visible for still/media content, while
            // using a proportional center-crop for the live camera preview.
            boolean fillLivePreview = cameraMode && !cameraFrozen;
            float scale = fillLivePreview
                    ? Math.max(getWidth() / imageWidth, getHeight() / imageHeight)
                    : Math.min(getWidth() / imageWidth, getHeight() / imageHeight);
            transform.reset();
            transform.setScale(scale, scale);
            transform.postTranslate((getWidth() - imageWidth * scale) / 2f,
                    (getHeight() - imageHeight * scale) / 2f);
            setImageMatrix(transform);
            needsFit = false;
            updateZoomLabel(zoom);
        }

        private void clampTransform() {
            if (getDrawable() == null) return;
            RectF rect = new RectF(0, 0, getDrawable().getIntrinsicWidth(), getDrawable().getIntrinsicHeight());
            transform.mapRect(rect);
            float dx = 0;
            float dy = 0;
            if (rect.width() <= getWidth()) dx = getWidth() / 2f - rect.centerX();
            else if (rect.left > 0) dx = -rect.left;
            else if (rect.right < getWidth()) dx = getWidth() - rect.right;
            if (rect.height() <= getHeight()) dy = getHeight() / 2f - rect.centerY();
            else if (rect.top > 0) dy = -rect.top;
            else if (rect.bottom < getHeight()) dy = getHeight() - rect.bottom;
            transform.postTranslate(dx, dy);
        }
    }

    private TextView sectionTitle(String value) {
        TextView t = label(value, 11, muted);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private TextView label(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private TextView pill(String value, int foreground, int backgroundColor) {
        TextView view = label(value, 10, foreground);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(11), 0, dp(11), 0);
        view.setTypeface(null, android.graphics.Typeface.BOLD);
        view.setBackground(roundDrawable(backgroundColor, dp(18)));
        return view;
    }

    private Button actionButton(String value, boolean primary) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setIncludeFontPadding(false);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(primary ? Color.rgb(20, 30, 14) : text);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(roundDrawable(primary ? accent : surfaceTwo, dp(11)));
        return button;
    }

    private Button chipButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setTextColor(muted);
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setBackground(roundStroke(divider, surface, dp(10)));
        return button;
    }

    private SeekBar seekBar(int value) {
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(value);
        bar.setPadding(0, 0, 0, 0);
        bar.setContentDescription("Regler");
        return bar;
    }

    private GradientDrawable roundDrawable(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private GradientDrawable roundStroke(int strokeColor, int fillColor, int radius) {
        GradientDrawable drawable = roundDrawable(fillColor, radius);
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private void selectProfile(Profile profile) {
        selectedProfile = profile;
        for (Button button : profileButtons) {
            boolean active = button.getTag() == profile;
            button.setTextColor(active ? Color.rgb(20, 30, 14) : muted);
            button.setBackground(roundStroke(active ? accent : divider, active ? accent : surface, dp(10)));
        }
        if (profileDescription != null) profileDescription.setText(profile.description);
        if (filterMenuButton != null) filterMenuButton.setText("FILTER · " + profile.shortName + "  ▾");
        savePreferences();
        refreshCurrentMedia();
    }

    private void resetControls() {
        strengthSeek.setProgress(70);
        brightnessSeek.setProgress(50);
        selectProfile(Profile.RED_GREEN_PLUS);
    }

    private void showEmptyState(String message) {
        recognitionMode = RecognitionMode.OFF;
        resetZoomControls();
        emptyPreview.setText(message);
        emptyPreview.setVisibility(View.VISIBLE);
        preview.setVisibility(View.INVISIBLE);
        if (saveButton != null) saveButton.setEnabled(false);
        if (compareButton != null) compareButton.setEnabled(false);
        if (freezeButton != null) freezeButton.setEnabled(false);
        if (pipetteButton != null) pipetteButton.setEnabled(false);
        if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
        if (pipetteOverlay != null) {
            pipetteMode = false;
            colorCompareMode = false;
            compareFirstResult = null;
            if (colorCompareButton != null) colorCompareButton.setText("ZWEI FARBEN VERGLEICHEN");
            pipetteOverlay.setVisibility(View.GONE);
        }
        if (pipetteResult != null) pipetteResult.setText("Pipette auswählen, dann über das Bild ziehen.");
        if (pipetteSwatch != null) pipetteSwatch.setBackground(roundDrawable(surfaceTwo, dp(18)));
        lastPipetteResult = null;
        lastPipetteColor = Color.TRANSPARENT;
        clearPipetteCalibration();
        updateColorToolUi();
        updateRecognitionUi();
        if (statusText != null) statusText.setText("Bereit · Verarbeitung bleibt auf dem Gerät");
    }

    private void prepareTorch() {
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            torchCameraId = findBackCamera(manager);
            if (torchCameraId != null) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(torchCameraId);
                Boolean flashAvailable = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                torchAvailable = Boolean.TRUE.equals(flashAvailable);
                if (Build.VERSION.SDK_INT >= 33) {
                    Integer max = characteristics.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL);
                    Integer defaultLevel = characteristics.get(CameraCharacteristics.FLASH_INFO_STRENGTH_DEFAULT_LEVEL);
                    torchMaxLevel = max == null ? 1 : Math.max(1, max);
                    torchDefaultLevel = defaultLevel == null ? 1 : Math.max(1, defaultLevel);
                } else {
                    torchMaxLevel = 1;
                    torchDefaultLevel = 1;
                }
            }
        } catch (Exception exception) {
            torchAvailable = false;
            torchCameraId = null;
        }
        runOnUiThread(this::updateTorchUi);
    }

    private void updateTorchUi() {
        if (torchButton == null) return;
        if (torchAvailable && torchMaxLevel > 1 && torchSeek != null) {
            int defaultProgress = Math.max(1, Math.min(100,
                    Math.round(torchDefaultLevel * 100f / torchMaxLevel)));
            if (!torchOn && torchSeek.getProgress() == 50) torchSeek.setProgress(defaultProgress);
        }
        torchButton.setEnabled(torchAvailable);
        torchSeek.setEnabled(torchAvailable && torchMaxLevel > 1);
        torchSeek.setVisibility(torchAvailable && torchOn && torchMaxLevel > 1 ? View.VISIBLE : View.GONE);
        if (!torchAvailable) {
            torchButton.setText("TASCHENLAMPE NICHT VERFÜGBAR");
            torchValue.setText("kein Blitz");
        } else if (torchMaxLevel <= 1) {
            torchButton.setText(torchOn ? "TASCHENLAMPE AN" : "TASCHENLAMPE AUS");
            torchValue.setText("nur Ein/Aus");
        } else {
            torchButton.setText(torchOn ? "TASCHENLAMPE AN" : "TASCHENLAMPE AUS");
            torchValue.setText("Helligkeit " + Math.max(1, torchSeek.getProgress()) + " %");
        }
    }

    private void toggleTorch() {
        if (!torchAvailable) return;
        torchOn = !torchOn;
        applyTorchState();
    }

    private int torchStrengthLevel() {
        if (torchMaxLevel <= 1) return 1;
        return Math.max(1, Math.round(torchSeek.getProgress() / 100f * torchMaxLevel));
    }

    private void applyTorchLevel() {
        if (!torchOn) return;
        applyTorchState();
    }

    private void applyTorchState() {
        if (torchCameraId == null) return;
        try {
            if (cameraMode && cameraSession != null && cameraRequestBuilder != null) {
                cameraRequestBuilder.set(CaptureRequest.FLASH_MODE, torchOn
                        ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
                if (Build.VERSION.SDK_INT >= 35 && torchOn && torchMaxLevel > 1) {
                    cameraRequestBuilder.set(CaptureRequest.FLASH_STRENGTH_LEVEL, torchStrengthLevel());
                }
                cameraSession.setRepeatingRequest(cameraRequestBuilder.build(), null, cameraHandler);
            } else if (torchOn && Build.VERSION.SDK_INT >= 33 && torchMaxLevel > 1) {
                CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                manager.turnOnTorchWithStrengthLevel(torchCameraId, torchStrengthLevel());
            } else {
                CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                manager.setTorchMode(torchCameraId, torchOn);
            }
            updateTorchUi();
        } catch (Exception exception) {
            torchOn = false;
            updateTorchUi();
            statusText.setText("Taschenlampe konnte nicht gesteuert werden");
        }
    }

    private void turnTorchOff() {
        if (!torchOn) return;
        torchOn = false;
        try {
            if (cameraMode && cameraSession != null && cameraRequestBuilder != null) {
                cameraRequestBuilder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF);
                cameraSession.setRepeatingRequest(cameraRequestBuilder.build(), null, cameraHandler);
            } else if (torchCameraId != null) {
                CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                manager.setTorchMode(torchCameraId, false);
            }
        } catch (Exception ignored) { }
        updateTorchUi();
    }

    private void startCameraFromUserAction() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            return;
        }
        startCamera();
    }

    private void startCamera() {
        stopCamera();
        stopVideo();
        clearCurrentMedia();
        final long generation = ++cameraGeneration;
        cameraMode = true;
        cameraFrozen = false;
        livePreviewFitPending = true;
        if (zoomPreview != null) zoomPreview.markNeedsFit();
        cameraUiState = CameraUiState.STARTING;
        lastCameraError = "";
        pipetteMode = false;
        if (pipetteOverlay != null) pipetteOverlay.setVisibility(View.GONE);
        videoMode = false;
        videoSeek.setVisibility(View.GONE);
        videoPositionLabel.setText("");
        cameraButton.setText("KAMERA LÄUFT");
        cameraButton.setEnabled(false);
        freezeButton.setText("STANDBILD");
        freezeButton.setEnabled(false);
        pipetteButton.setText("PIPETTE");
        pipetteButton.setEnabled(false);
        if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
        updatePipetteCalibrationUi();
        emptyPreview.setText("Kamera wird gestartet …");
        emptyPreview.setVisibility(View.VISIBLE);
        preview.setVisibility(View.VISIBLE);
        statusText.setText("Live-Kamera · Filter wird lokal angewendet");
        startCameraThread();
        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String cameraId = findBackCamera(manager);
            if (cameraId == null) {
                showCameraError("Keine Rückkamera gefunden");
                return;
            }
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
            cameraFrontFacing = facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT;
            Integer sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            cameraRotationDegrees = calculateCameraRotation(sensorOrientation == null ? 0 : sensorOrientation, cameraFrontFacing);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size size = chooseJpegSize(map);
            Size stillSize = chooseHighResolutionJpegSize(map, safeHighResolutionLimit());
            imageReader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(reader -> onCameraImage(reader, generation), cameraHandler);
            stillReader = ImageReader.newInstance(stillSize.getWidth(), stillSize.getHeight(), ImageFormat.JPEG, 2);
            stillReader.setOnImageAvailableListener(reader -> onStillImage(reader, generation), cameraHandler);
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            cameraOpening = true;
            manager.openCamera(cameraId, cameraStateCallbackFor(generation), cameraHandler);
        } catch (Exception exception) {
            showCameraError("Kamera konnte nicht geöffnet werden");
        }
    }

    private String findBackCamera(CameraManager manager) throws CameraAccessException {
        for (String id : manager.getCameraIdList()) {
            CameraCharacteristics c = manager.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
        }
        String[] ids = manager.getCameraIdList();
        return ids.length > 0 ? ids[0] : null;
    }

    private Size chooseJpegSize(StreamConfigurationMap map) {
        if (map == null) return new Size(640, 480);
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        Size best = new Size(640, 480);
        long bestDistance = Long.MAX_VALUE;
        if (sizes != null) {
            for (Size candidate : sizes) {
                long distance = Math.abs((long) candidate.getWidth() * candidate.getHeight() - 640L * 480L);
                if (candidate.getWidth() <= 1280 && candidate.getHeight() <= 1280 && distance < bestDistance) {
                    best = candidate;
                    bestDistance = distance;
                }
            }
        }
        return best;
    }

    private Size chooseHighResolutionJpegSize(StreamConfigurationMap map, int maxDimension) {
        if (map == null) return new Size(1280, 720);
        Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
        Size best = new Size(1280, 720);
        long bestArea = 0;
        if (sizes != null) {
            for (Size candidate : sizes) {
                if (candidate.getWidth() > maxDimension || candidate.getHeight() > maxDimension) continue;
                long area = (long) candidate.getWidth() * candidate.getHeight();
                if (area > bestArea) {
                    best = candidate;
                    bestArea = area;
                }
            }
        }
        return best;
    }

    private int safeHighResolutionLimit() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int memoryClass = manager == null ? 256 : manager.getMemoryClass();
        if (memoryClass <= 256) return 4096;
        if (memoryClass <= 384) return 6144;
        return 8192;
    }

    private int calculateCameraRotation(int sensorOrientation, boolean frontFacing) {
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        int displayDegrees;
        switch (displayRotation) {
            case Surface.ROTATION_90:
                displayDegrees = 90;
                break;
            case Surface.ROTATION_180:
                displayDegrees = 180;
                break;
            case Surface.ROTATION_270:
                displayDegrees = 270;
                break;
            default:
                displayDegrees = 0;
        }
        if (frontFacing) return (sensorOrientation + displayDegrees) % 360;
        return (sensorOrientation - displayDegrees + 360) % 360;
    }

    private boolean isCurrentCamera(long generation) {
        return cameraMode && cameraGeneration == generation;
    }

    private CameraDevice.StateCallback cameraStateCallbackFor(final long generation) {
        return new CameraDevice.StateCallback() {
            @Override public void onOpened(CameraDevice camera) {
                if (!isCurrentCamera(generation) || imageReader == null || cameraHandler == null) {
                    camera.close();
                    return;
                }
                cameraDevice = camera;
                cameraOpening = false;
                try {
                    CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                    cameraRequestBuilder = builder;
                    builder.addTarget(imageReader.getSurface());
                    builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                    java.util.List<Surface> surfaces = new ArrayList<>();
                    surfaces.add(imageReader.getSurface());
                    if (stillReader != null) surfaces.add(stillReader.getSurface());
                    camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession session) {
                            if (!isCurrentCamera(generation) || cameraDevice == null) {
                                session.close();
                                return;
                            }
                            cameraSession = session;
                            cameraUiState = CameraUiState.LIVE;
                            try {
                                session.setRepeatingRequest(builder.build(), null, cameraHandler);
                            } catch (CameraAccessException exception) {
                                showCameraError("Live-Vorschau konnte nicht gestartet werden");
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession session) {
                            if (isCurrentCamera(generation)) {
                                showCameraError("Kamera-Vorschau konnte nicht konfiguriert werden");
                            }
                        }
                    }, cameraHandler);
                } catch (CameraAccessException exception) {
                    if (isCurrentCamera(generation)) {
                        showCameraError("Kamera-Vorschau konnte nicht gestartet werden");
                    }
                }
            }

            @Override public void onDisconnected(CameraDevice camera) {
                camera.close();
                if (!isCurrentCamera(generation)) return;
                cameraDevice = null;
                cameraRequestBuilder = null;
                showCameraError("Kamera wurde getrennt");
            }

            @Override public void onError(CameraDevice camera, int error) {
                camera.close();
                if (!isCurrentCamera(generation)) return;
                cameraDevice = null;
                cameraRequestBuilder = null;
                showCameraError("Kamerafehler (" + error + ")");
            }
        };
    }

    private void onCameraImage(ImageReader reader, long generation) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            Bitmap raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (raw == null) return;
            if (!isCurrentCamera(generation) || cameraFrozen) {
                raw.recycle();
                return;
            }
            Bitmap frameSource = null;
            Bitmap filtered;
            try {
                frameSource = rotateBitmap(raw, cameraRotationDegrees, cameraFrontFacing);
                if (frameSource != raw) raw.recycle();
                filtered = filterBitmap(frameSource);
            } catch (OutOfMemoryError error) {
                if (frameSource != null && frameSource != raw && !frameSource.isRecycled()) frameSource.recycle();
                if (!raw.isRecycled()) raw.recycle();
                runOnUiThread(() -> statusText.setText("Livebild zu groß · sichere Vorschau wird verwendet"));
                return;
            }
            final Bitmap finalFrameSource = frameSource;
            final Bitmap finalFiltered = filtered;
            runOnUiThread(() -> {
                if (!isCurrentCamera(generation) || cameraFrozen) {
                    if (!finalFrameSource.isRecycled()) finalFrameSource.recycle();
                    if (!finalFiltered.isRecycled()) finalFiltered.recycle();
                    return;
                }
                Bitmap oldSource = currentSource;
                currentSource = finalFrameSource;
                if (oldSource != null && oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
                if (livePreviewFitPending) {
                    livePreviewFitPending = false;
                    zoomPreview.markNeedsFit();
                }
                setDisplayBitmap(finalFiltered);
                emptyPreview.setVisibility(View.GONE);
                preview.setVisibility(View.VISIBLE);
                saveButton.setEnabled(true);
                freezeButton.setEnabled(true);
                pipetteButton.setEnabled(true);
            });
        } finally {
            image.close();
        }
    }

    private void requestHighResolutionStill() {
        if (!cameraMode || !cameraFrozen) return;
        if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
        if (cameraDevice == null || cameraSession == null || stillReader == null) {
            stillCapturePending = false;
            showStillFallback("Standbild aktiv · Vorschauauflösung verwendet");
            updateRecognitionUi();
            return;
        }
        try {
            CaptureRequest.Builder stillBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            stillBuilder.addTarget(stillReader.getSurface());
            stillBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            stillCapturePending = true;
            cameraSession.capture(stillBuilder.build(), null, cameraHandler);
            uiHandler.removeCallbacks(stillTimeout);
            uiHandler.postDelayed(stillTimeout, 4500L);
            statusText.setText("Hochauflösendes Standbild wird erstellt …");
        } catch (Exception exception) {
            stillCapturePending = false;
            uiHandler.removeCallbacks(stillTimeout);
            showStillFallback("Standbild aktiv · Vorschauauflösung verwendet");
            updateRecognitionUi();
        }
    }

    private void showStillFallback(String message) {
        runOnUiThread(() -> {
            if (statusText != null) statusText.setText(message);
            if (stillRetryButton != null) {
                stillRetryButton.setVisibility(cameraMode && cameraFrozen ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void onStillImage(ImageReader reader, long generation) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        try {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            Bitmap raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            stillCapturePending = false;
            uiHandler.removeCallbacks(stillTimeout);
            if (raw == null) return;
            Bitmap oriented;
            try {
                oriented = rotateBitmap(raw, cameraRotationDegrees, cameraFrontFacing);
                if (oriented != raw) raw.recycle();
            } catch (OutOfMemoryError error) {
                if (!raw.isRecycled()) raw.recycle();
                showStillFallback("Standbild zu groß · Vorschauauflösung verwendet");
                return;
            }
            final Bitmap highResolutionSource = scaleDown(oriented, safeHighResolutionLimit());
            if (highResolutionSource != oriented && !oriented.isRecycled()) oriented.recycle();
            Bitmap filtered;
            try {
                filtered = filterBitmap(highResolutionSource);
            } catch (OutOfMemoryError error) {
                if (!highResolutionSource.isRecycled()) highResolutionSource.recycle();
                showStillFallback("Standbild zu groß · Vorschauauflösung verwendet");
                return;
            }
            runOnUiThread(() -> {
                if (!isCurrentCamera(generation) || !cameraFrozen) {
                    if (!highResolutionSource.isRecycled()) highResolutionSource.recycle();
                    if (!filtered.isRecycled()) filtered.recycle();
                    return;
                }
                Bitmap oldSource = currentSource;
                currentSource = highResolutionSource;
                if (oldSource != null && oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
                zoomPreview.markNeedsFit();
                setDisplayBitmap(filtered);
                resetZoomControls();
                emptyPreview.setVisibility(View.GONE);
                preview.setVisibility(View.VISIBLE);
                saveButton.setEnabled(currentSource != null);
                freezeButton.setEnabled(true);
                pipetteButton.setEnabled(true);
                if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
                statusText.setText("Hochauflösendes Standbild · Filter und Pipette sind verfügbar");
                haptic(preview);
            });
        } finally {
            image.close();
        }
    }

    private Bitmap rotateBitmap(Bitmap source, int degrees, boolean mirror) {
        if (degrees == 0 && !mirror) return source;
        android.graphics.Matrix matrix = new android.graphics.Matrix();
        if (degrees != 0) matrix.postRotate(degrees);
        if (mirror) matrix.postScale(-1, 1);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    private void showCameraError(String message) {
        runOnUiThread(() -> handleCameraFailure(message));
    }

    private void handleCameraFailure(String message) {
        lastCameraError = message;
        Bitmap lastImage = currentSource;
        stopCamera();
        cameraUiState = CameraUiState.ERROR;
        if (cameraButton != null) {
            cameraButton.setText("KAMERA NEU STARTEN");
            cameraButton.setContentDescription("Kamera nach einem Fehler neu starten");
            cameraButton.setEnabled(true);
        }
        if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
        if (freezeButton != null) {
            freezeButton.setText("STANDBILD");
            freezeButton.setEnabled(false);
        }
        if (lastImage != null && !lastImage.isRecycled()) {
            emptyPreview.setVisibility(View.GONE);
            preview.setVisibility(View.VISIBLE);
            statusText.setText(message + " · letztes Bild bleibt verfügbar");
            pipetteButton.setEnabled(true);
            updateRecognitionUi();
        } else {
            emptyPreview.setText(message + "\n\nTippe auf KAMERA NEU STARTEN.");
            emptyPreview.setVisibility(View.VISIBLE);
            preview.setVisibility(View.INVISIBLE);
            statusText.setText(message);
            updateRecognitionUi();
        }
    }

    private void toggleFreeze() {
        if (!cameraMode || currentSource == null) return;
        cameraFrozen = !cameraFrozen;
        if (cameraFrozen) {
            cameraUiState = CameraUiState.FROZEN;
            freezeButton.setText("WEITER LIVE");
            updateRecognitionUi();
            resetZoomControls();
            statusText.setText("Standbild wird vorbereitet …");
            requestHighResolutionStill();
            haptic(freezeButton);
        } else {
            cameraUiState = CameraUiState.LIVE;
            stillCapturePending = false;
            uiHandler.removeCallbacks(stillTimeout);
            if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
            recognitionMode = RecognitionMode.OFF;
            pipetteMode = false;
            pipetteOverlay.setVisibility(View.GONE);
            pipetteButton.setText("PIPETTE");
            colorCompareMode = false;
            compareFirstResult = null;
            if (colorCompareButton != null) colorCompareButton.setText("ZWEI FARBEN VERGLEICHEN");
            lastPipetteResult = null;
            lastPipetteColor = Color.TRANSPARENT;
            pipetteResult.setText("Pipette auswählen, dann über das Bild ziehen.");
            freezeButton.setText("STANDBILD");
            statusText.setText("Live-Kamera · Filter wird lokal angewendet");
            showingOriginal = false;
            livePreviewFitPending = true;
            zoomPreview.markNeedsFit();
            renderPreview();
            updateRecognitionUi();
            resetZoomControls();
            updateColorToolUi();
        }
    }

    private void togglePipette() {
        if (currentSource == null) return;
        if (cameraMode && !cameraFrozen) {
            cameraFrozen = true;
            cameraUiState = CameraUiState.FROZEN;
            freezeButton.setText("WEITER LIVE");
            updateRecognitionUi();
            statusText.setText("Standbild wird vorbereitet …");
            requestHighResolutionStill();
        }
        if (colorCompareMode) {
            colorCompareMode = false;
            compareFirstResult = null;
            if (colorCompareButton != null) colorCompareButton.setText("ZWEI FARBEN VERGLEICHEN");
        }
        pipetteMode = !pipetteMode;
        haptic(pipetteButton);
        pipetteOverlay.setVisibility(pipetteMode ? View.VISIBLE : View.GONE);
        pipetteButton.setText(pipetteMode ? "PIPETTE AUS" : "PIPETTE");
        if (pipetteCalibrationButton != null) pipetteCalibrationButton.setEnabled(true);
        if (!pipetteMode) {
            pipetteResult.setText("Pipette auswählen, dann über das Bild ziehen.");
            pipetteSwatch.setBackground(roundDrawable(surfaceTwo, dp(18)));
            pipetteOverlay.clearPoint();
        } else {
            pipetteResult.setText("Über das Bild ziehen · Originalfarbe wird gemessen");
        }
        updateColorToolUi();
    }

    private void togglePipetteCalibration() {
        if (currentSource == null) return;
        if (pipetteCalibration != null) {
            clearPipetteCalibration();
            statusText.setText("Lichtkalibrierung zurückgesetzt");
            return;
        }
        if (lastPipetteSourceX < 0 || lastPipetteSourceY < 0) {
            Toast.makeText(this, "Aktiviere die Pipette und ziehe sie zuerst über eine matte weiße oder graue Fläche.", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Licht kalibrieren")
                .setMessage("Der aktuelle Pipettenpunkt wird als neutrale Referenz verwendet. "
                        + "Richte den Punkt auf eine matte weiße oder graue Fläche unter dem Licht, unter dem du messen möchtest.")
                .setNegativeButton("ABBRECHEN", null)
                .setPositiveButton("KALIBRIERUNG ÜBERNEHMEN", (dialog, which) -> capturePipetteCalibration())
                .show();
    }

    private void capturePipetteCalibration() {
        if (currentSource == null || lastPipetteSourceX < 0 || lastPipetteSourceY < 0) return;
        ColorAnalyzer.Result reference = ColorAnalyzer.analyze(
                currentSource, lastPipetteSourceX, lastPipetteSourceY,
                sourceRadiusForPipetteArea(), 1f, 1f, 1f);
        int red = Color.red(reference.color);
        int green = Color.green(reference.color);
        int blue = Color.blue(reference.color);
        float[] hsv = new float[3];
        Color.colorToHSV(reference.color, hsv);
        if (reference.sampleCount < 12 || reference.mixed || reference.saturation > 0.24f || hsv[2] < 0.35f
                || Math.max(red, Math.max(green, blue)) - Math.min(red, Math.min(green, blue)) > 68) {
            Toast.makeText(this, "Die Referenz ist nicht neutral oder zu dunkel. Nutze eine matte weiße oder graue Fläche.", Toast.LENGTH_LONG).show();
            return;
        }
        float target = hsv[2] > 0.78f ? 232f : 170f;
        pipetteCalibration = new PipetteCalibration(
                clampCalibrationGain(target / Math.max(1, red)),
                clampCalibrationGain(target / Math.max(1, green)),
                clampCalibrationGain(target / Math.max(1, blue)),
                reference.color);
        updatePipetteCalibrationUi();
        statusText.setText("Lichtkalibrierung aktiv · Pipette korrigiert Messwerte");
        if (lastPipetteViewX > 0 || lastPipetteViewY > 0) {
            sampleAtPreviewPoint(lastPipetteViewX, lastPipetteViewY);
        }
    }

    private float clampCalibrationGain(float gain) {
        return Math.max(0.70f, Math.min(1.40f, gain));
    }

    private void updatePipetteCalibrationUi() {
        if (pipetteCalibrationButton == null) return;
        pipetteCalibrationButton.setEnabled(currentSource != null);
        pipetteCalibrationButton.setText(pipetteCalibration == null
                ? "LICHT KALIBRIEREN" : "KALIBRIERUNG ZURÜCKSETZEN");
        if (pipetteCalibrationStatus != null) {
            pipetteCalibrationStatus.setText(pipetteCalibration == null
                    ? "Keine Lichtkalibrierung aktiv"
                    : "Kalibrierung aktiv · gilt bis zum Neustart oder Zurücksetzen");
        }
        updatePipetteAreaUi();
    }

    private void clearPipetteCalibration() {
        pipetteCalibration = null;
        lastPipetteSourceX = -1;
        lastPipetteSourceY = -1;
        lastPipetteViewX = 0;
        lastPipetteViewY = 0;
        updatePipetteCalibrationUi();
    }

    private boolean handlePipetteTouch(MotionEvent event) {
        if (!pipetteMode || currentSource == null) return false;
        if (event.getAction() == MotionEvent.ACTION_DOWN
                || event.getAction() == MotionEvent.ACTION_MOVE
                || event.getAction() == MotionEvent.ACTION_UP) {
            sampleAtPreviewPoint(event.getX(), event.getY());
            return true;
        }
        return false;
    }

    private void sampleAtPreviewPoint(float viewX, float viewY) {
        if (currentSource == null || preview == null) return;
        float viewWidth = preview.getWidth();
        float viewHeight = preview.getHeight();
        if (viewWidth <= 0 || viewHeight <= 0) return;
        float[] point = new float[]{viewX, viewY};
        Matrix inverse = new Matrix();
        if (zoomPreview == null || !zoomPreview.getImageMatrix().invert(inverse)) return;
        inverse.mapPoints(point);
        float sourceX = point[0];
        float sourceY = point[1];
        if (sourceX < 0 || sourceY < 0 || sourceX >= currentSource.getWidth() || sourceY >= currentSource.getHeight()) return;
        int x = Math.max(0, Math.min(currentSource.getWidth() - 1, Math.round(sourceX)));
        int y = Math.max(0, Math.min(currentSource.getHeight() - 1, Math.round(sourceY)));
        float[] gains = pipetteGains(currentSource);
        ColorAnalyzer.Result sample = ColorAnalyzer.analyze(
                currentSource, x, y, sourceRadiusForPipetteArea(), gains[0], gains[1], gains[2]);
        lastPipetteSourceX = x;
        lastPipetteSourceY = y;
        lastPipetteViewX = viewX;
        lastPipetteViewY = viewY;
        int pixel = sample.color;
        lastPipetteResult = sample;
        lastPipetteColor = pixel;
        if (colorCompareMode) {
            if (compareFirstResult == null) {
                compareFirstResult = sample;
                pipetteResult.setText("Punkt A: " + sample.displayName()
                        + "\nJetzt Punkt B auf dem Bild auswählen.");
            } else {
                pipetteResult.setText(buildColorComparison(compareFirstResult, sample));
                colorCompareMode = false;
                compareFirstResult = null;
                colorCompareButton.setText("ZWEI FARBEN VERGLEICHEN");
                statusText.setText("Farbvergleich abgeschlossen · Punkt B ausgewertet");
            }
            pipetteSwatch.setBackground(roundDrawable(pixel, dp(18)));
            pipetteOverlay.setAreaSize(pipetteAreaSize);
            pipetteOverlay.setPoint(viewX, viewY);
            pipetteOverlay.setSourcePoint(x, y);
            updateColorToolUi();
            return;
        }
        String lightNote = pipetteCalibration != null ? "\nLicht: manuell kalibriert"
                : isNeutralGain(gains) ? "" : "\nLicht: vorsichtig automatisch korrigiert";
        String qualityHint = measurementQualityHint(sample, pixel);
        String details = String.format(Locale.US,
                "Grundfarbe: %s\nMessqualität: %s\nSicherheit: %s · %s\nHEX #%02X%02X%02X · RGB %d, %d, %d\nMessung: punktnahe Fläche · %d Pixel%s",
                sample.displayName(), qualityHint, sample.confidence.label, sample.reason,
                Color.red(pixel), Color.green(pixel), Color.blue(pixel),
                Color.red(pixel), Color.green(pixel), Color.blue(pixel), sample.sampleCount, lightNote);
        pipetteResult.setText(details);
        pipetteSwatch.setBackground(roundDrawable(pixel, dp(18)));
        pipetteOverlay.setAreaSize(pipetteAreaSize);
        pipetteOverlay.setPoint(viewX, viewY);
        pipetteOverlay.setSourcePoint(x, y);
    }

    private String measurementQualityHint(ColorAnalyzer.Result sample, int color) {
        if (sample == null) return "unbekannt";
        int maximum = Math.max(Color.red(color), Math.max(Color.green(color), Color.blue(color)));
        int minimum = Math.min(Color.red(color), Math.min(Color.green(color), Color.blue(color)));
        if (maximum < 32) return "eingeschränkt · zu dunkel";
        if (maximum > 248 && maximum - minimum < 18) return "eingeschränkt · sehr hell oder Spiegelung";
        if (sample.mixed) return "eingeschränkt · gemischte Fläche oder Kante";
        if (sample.confidence == ColorAnalyzer.Confidence.LOW) return "eingeschränkt · Fläche uneinheitlich";
        if (sample.confidence == ColorAnalyzer.Confidence.MEDIUM) return "brauchbar · möglichst gleichmäßig beleuchten";
        return "gut · Fläche überwiegend einheitlich";
    }

    private float[] pipetteGains(Bitmap source) {
        if (pipetteCalibration != null) {
            return new float[]{pipetteCalibration.redGain, pipetteCalibration.greenGain, pipetteCalibration.blueGain};
        }
        if (source == null || source.isRecycled()) return new float[]{1f, 1f, 1f};
        if (pipetteGainSource == source) return cachedPipetteGains;
        int stepX = Math.max(1, source.getWidth() / 32);
        int stepY = Math.max(1, source.getHeight() / 32);
        float red = 0f;
        float green = 0f;
        float blue = 0f;
        int count = 0;
        for (int y = 0; y < source.getHeight(); y += stepY) {
            for (int x = 0; x < source.getWidth(); x += stepX) {
                int pixel = source.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);
                int maximum = Math.max(Color.red(pixel), Math.max(Color.green(pixel), Color.blue(pixel)));
                int minimum = Math.min(Color.red(pixel), Math.min(Color.green(pixel), Color.blue(pixel)));
                float luminance = .2126f * Color.red(pixel) + .7152f * Color.green(pixel) + .0722f * Color.blue(pixel);
                boolean neutral = hsv[1] < .14f && luminance > 36f && luminance < 238f;
                boolean glare = maximum >= 244 && maximum - minimum < 48;
                if (!neutral || glare) continue;
                red += Color.red(pixel);
                green += Color.green(pixel);
                blue += Color.blue(pixel);
                count++;
            }
        }
        if (count < 12) {
            pipetteGainSource = source;
            cachedPipetteGains = new float[]{1f, 1f, 1f};
            return cachedPipetteGains;
        }
        red /= count;
        green /= count;
        blue /= count;
        float average = (red + green + blue) / 3f;
        float redGain = clampAutomaticGain(average / Math.max(1f, red));
        float greenGain = clampAutomaticGain(average / Math.max(1f, green));
        float blueGain = clampAutomaticGain(average / Math.max(1f, blue));
        if (Math.max(redGain, Math.max(greenGain, blueGain))
                - Math.min(redGain, Math.min(greenGain, blueGain)) < .035f) {
            pipetteGainSource = source;
            cachedPipetteGains = new float[]{1f, 1f, 1f};
            return cachedPipetteGains;
        }
        pipetteGainSource = source;
        cachedPipetteGains = new float[]{redGain, greenGain, blueGain};
        return cachedPipetteGains;
    }

    private float clampAutomaticGain(float gain) {
        return Math.max(.88f, Math.min(1.16f, gain));
    }

    private boolean isNeutralGain(float[] gains) {
        return gains == null || Math.max(gains[0], Math.max(gains[1], gains[2]))
                - Math.min(gains[0], Math.min(gains[1], gains[2])) < .035f;
    }

    private int sourceRadiusForPipetteArea() {
        if (currentSource == null || zoomPreview == null) return 3;
        float[] values = new float[9];
        zoomPreview.getImageMatrix().getValues(values);
        float scale = Math.max(.01f, (float) Math.hypot(
                values[Matrix.MSCALE_X], values[Matrix.MSKEW_Y]));
        int viewDiameter = dp(pipetteAreaSize.diameterDp);
        int radius = Math.round(viewDiameter / (2f * scale));
        int maxRadius = Math.max(2, Math.min(currentSource.getWidth(), currentSource.getHeight()) / 3);
        return Math.max(2, Math.min(maxRadius, radius));
    }

    private void toggleColorCompare() {
        if (currentSource == null) return;
        if (cameraMode && !cameraFrozen) {
            cameraFrozen = true;
            cameraUiState = CameraUiState.FROZEN;
            freezeButton.setText("WEITER LIVE");
            statusText.setText("Standbild wird vorbereitet …");
            requestHighResolutionStill();
        }
        if (colorCompareMode) {
            colorCompareMode = false;
            compareFirstResult = null;
            colorCompareButton.setText("ZWEI FARBEN VERGLEICHEN");
            pipetteOverlay.clearPoint();
            pipetteOverlay.setVisibility(View.GONE);
            pipetteResult.setText("Pipette auswählen, dann über das Bild ziehen.");
        } else {
            pipetteMode = false;
            pipetteButton.setText("PIPETTE");
            colorCompareMode = true;
            compareFirstResult = null;
            colorCompareButton.setText("VERGLEICH ABBRECHEN");
            pipetteOverlay.setVisibility(View.VISIBLE);
            pipetteResult.setText("Punkt A auf dem Bild auswählen.");
        }
        updateColorToolUi();
        haptic(colorCompareButton);
    }

    private void updateColorToolUi() {
        boolean available = currentSource != null;
        if (colorCompareButton != null) {
            colorCompareButton.setEnabled(available);
            colorCompareButton.setText(colorCompareMode ? "VERGLEICH ABBRECHEN" : "ZWEI FARBEN VERGLEICHEN");
        }
        boolean measured = available && lastPipetteResult != null;
        if (saveColorButton != null) saveColorButton.setEnabled(measured);
        if (shareColorButton != null) shareColorButton.setEnabled(measured);
    }

    private String buildColorComparison(ColorAnalyzer.Result first, ColorAnalyzer.Result second) {
        int firstColor = first.color;
        int secondColor = second.color;
        float firstLuminance = .2126f * Color.red(firstColor)
                + .7152f * Color.green(firstColor) + .0722f * Color.blue(firstColor);
        float secondLuminance = .2126f * Color.red(secondColor)
                + .7152f * Color.green(secondColor) + .0722f * Color.blue(secondColor);
        String brightness = Math.abs(firstLuminance - secondLuminance) < 12f
                ? "ähnlich hell" : secondLuminance > firstLuminance ? "Punkt B ist heller" : "Punkt B ist dunkler";
        float[] firstHsv = new float[3];
        float[] secondHsv = new float[3];
        Color.colorToHSV(firstColor, firstHsv);
        Color.colorToHSV(secondColor, secondHsv);
        float hueDifference = Math.abs(firstHsv[0] - secondHsv[0]);
        hueDifference = Math.min(hueDifference, 360f - hueDifference);
        String hueText = hueDifference < 18f ? "ähnlicher Farbton"
                : hueDifference < 58f ? "leicht anderer Farbton" : "deutlich anderer Farbton";
        int distance = (int) Math.round(Math.sqrt(
                Math.pow(Color.red(firstColor) - Color.red(secondColor), 2)
                        + Math.pow(Color.green(firstColor) - Color.green(secondColor), 2)
                        + Math.pow(Color.blue(firstColor) - Color.blue(secondColor), 2)));
        return String.format(Locale.US,
                "Punkt A: %s\nHEX #%02X%02X%02X · RGB %d, %d, %d\n\nPunkt B: %s\nHEX #%02X%02X%02X · RGB %d, %d, %d\n\nVergleich: %s · %s\nFarbabstand: %d · Sicherheit B: %s",
                first.displayName(), Color.red(firstColor), Color.green(firstColor), Color.blue(firstColor),
                Color.red(firstColor), Color.green(firstColor), Color.blue(firstColor),
                second.displayName(), Color.red(secondColor), Color.green(secondColor), Color.blue(secondColor),
                Color.red(secondColor), Color.green(secondColor), Color.blue(secondColor),
                brightness, hueText, distance, second.confidence.label);
    }

    private void saveColorNote() {
        if (lastPipetteResult == null) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("z. B. Handtuch Badezimmer");
        input.setTextColor(text);
        input.setHintTextColor(muted);
        input.setPadding(dp(12), dp(4), dp(12), dp(4));
        new AlertDialog.Builder(this)
                .setTitle("Farbmessung merken")
                .setMessage("Es werden nur Name, Farbe und Messsicherheit lokal gespeichert – kein Foto.")
                .setView(input)
                .setNegativeButton("ABBRECHEN", null)
                .setPositiveButton("SPEICHERN", (dialog, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "Unbenannte Messung";
                    name = name.replace("|", " ").replace("\n", " ");
                    ColorAnalyzer.Result result = lastPipetteResult;
                    int color = lastPipetteColor;
                    String entry = name + " | " + result.displayName()
                            + " | HEX #" + String.format(Locale.US, "%02X%02X%02X",
                            Color.red(color), Color.green(color), Color.blue(color))
                            + " | Sicherheit " + result.confidence.label;
                    String old = getSharedPreferences("sehplus_preferences", MODE_PRIVATE)
                            .getString("color_notes", "");
                    String combined = entry + (old.isEmpty() ? "" : "\n" + old);
                    String[] entries = combined.split("\\n");
                    StringBuilder limited = new StringBuilder();
                    for (int index = 0; index < Math.min(10, entries.length); index++) {
                        if (index > 0) limited.append('\n');
                        limited.append(entries[index]);
                    }
                    getSharedPreferences("sehplus_preferences", MODE_PRIVATE).edit()
                            .putString("color_notes", limited.toString()).apply();
                    Toast.makeText(this, "Farbmessung lokal gespeichert", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void shareColorCard() {
        if (lastPipetteResult == null) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "SehPlus Farbkarte");
        share.putExtra(Intent.EXTRA_TEXT, buildColorCard(lastPipetteResult, lastPipetteColor));
        try {
            startActivity(Intent.createChooser(share, "Farbkarte teilen"));
        } catch (Exception exception) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("SehPlus Farbkarte", buildColorCard(lastPipetteResult, lastPipetteColor)));
            Toast.makeText(this, "Kein Teilen-Menü verfügbar. Farbkarte wurde kopiert.", Toast.LENGTH_LONG).show();
        }
    }

    private String buildColorCard(ColorAnalyzer.Result result, int color) {
        return "SehPlus Farbkarte\n\n"
                + "Grundfarbe: " + result.displayName() + "\n"
                + "Sicherheit: " + result.confidence.label + " · " + result.reason + "\n"
                + String.format(Locale.US, "HEX #%02X%02X%02X · RGB %d, %d, %d\n",
                Color.red(color), Color.green(color), Color.blue(color),
                Color.red(color), Color.green(color), Color.blue(color))
                + "Keine Aufnahme oder persönlichen Daten enthalten.";
    }

    private void clearCurrentMedia() {
        if (currentSource != null && currentSource != currentDisplay && !currentSource.isRecycled()) currentSource.recycle();
        if (currentDisplay != null && !currentDisplay.isRecycled()) currentDisplay.recycle();
        currentSource = null;
        currentDisplay = null;
        showingOriginal = false;
        recognitionMode = RecognitionMode.OFF;
        if (zoomPreview != null) zoomPreview.markNeedsFit();
        resetZoomControls();
        if (preview != null) preview.setImageDrawable(null);
        if (saveButton != null) saveButton.setEnabled(false);
        if (compareButton != null) compareButton.setEnabled(false);
        if (pipetteButton != null) pipetteButton.setEnabled(false);
        pipetteGainSource = null;
        cachedPipetteGains = new float[]{1f, 1f, 1f};
        lastPipetteResult = null;
        lastPipetteColor = Color.TRANSPARENT;
        colorCompareMode = false;
        compareFirstResult = null;
        clearPipetteCalibration();
        updateColorToolUi();
        updateRecognitionUi();
    }

    private void startCameraThread() {
        if (cameraThread != null) return;
        cameraThread = new HandlerThread("SehPlusCamera");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());
    }

    private void stopCamera() {
        turnTorchOff();
        cameraGeneration++;
        stillCapturePending = false;
        uiHandler.removeCallbacks(stillTimeout);
        cameraMode = false;
        cameraOpening = false;
        cameraFrozen = false;
        cameraUiState = CameraUiState.IDLE;
        pipetteMode = false;
        if (pipetteOverlay != null) pipetteOverlay.setVisibility(View.GONE);
        if (cameraSession != null) {
            try { cameraSession.close(); } catch (Exception ignored) { }
            cameraSession = null;
        }
        cameraRequestBuilder = null;
        if (cameraDevice != null) {
            try { cameraDevice.close(); } catch (Exception ignored) { }
            cameraDevice = null;
        }
        if (imageReader != null) {
            try { imageReader.close(); } catch (Exception ignored) { }
            imageReader = null;
        }
        if (stillReader != null) {
            try { stillReader.close(); } catch (Exception ignored) { }
            stillReader = null;
        }
        stillCapturePending = false;
        if (cameraThread != null) {
            cameraThread.quitSafely();
            cameraThread = null;
            cameraHandler = null;
        }
        if (cameraButton != null) {
            cameraButton.setText("KAMERA STARTEN");
            cameraButton.setContentDescription("Kamera starten oder stoppen");
            cameraButton.setEnabled(true);
        }
        if (stillRetryButton != null) stillRetryButton.setVisibility(View.GONE);
        if (freezeButton != null) {
            freezeButton.setText("STANDBILD");
            freezeButton.setEnabled(false);
        }
        if (pipetteButton != null) {
            pipetteButton.setText("PIPETTE");
            pipetteButton.setEnabled(currentSource != null);
        }
        updatePipetteCalibrationUi();
        updateRecognitionUi();
    }

    private void openMediaPicker() {
        stopCamera();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        startActivityForResult(intent, PICK_MEDIA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_MEDIA || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        currentUri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(currentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        String mime = getContentResolver().getType(currentUri);
        if (mime != null && mime.startsWith("video")) loadVideo(currentUri);
        else loadPhoto(currentUri);
    }

    private void loadPhoto(Uri uri) {
        stopVideo();
        clearPipetteCalibration();
        recognitionMode = RecognitionMode.OFF;
        videoMode = false;
        videoSeek.setVisibility(View.GONE);
        videoPositionLabel.setText("");
        try {
            Bitmap bitmap = decodeHighResolutionPhoto(uri, safeHighResolutionLimit());
            if (bitmap == null) throw new IOException("Bild konnte nicht gelesen werden");
            Bitmap oldSource = currentSource;
            currentSource = bitmap;
            if (oldSource != null && oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
            cameraMode = false;
            showingOriginal = false;
            zoomPreview.markNeedsFit();
            resetZoomControls();
            refreshCurrentMedia();
            statusText.setText("Bild geladen · Filter lokal angewendet");
        } catch (OutOfMemoryError error) {
            try {
                Bitmap fallback = decodeHighResolutionPhoto(uri, 4096);
                if (fallback == null) throw new IOException("Bild konnte nicht gelesen werden");
                Bitmap oldSource = currentSource;
                currentSource = fallback;
                if (oldSource != null && oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
                cameraMode = false;
                showingOriginal = false;
                zoomPreview.markNeedsFit();
                resetZoomControls();
                refreshCurrentMedia();
                statusText.setText("Bild geladen · sichere Auflösung verwendet");
            } catch (Exception fallbackError) {
                showEmptyState("Bild ist zu groß für dieses Gerät");
            }
        } catch (Exception exception) {
            showEmptyState("Bild konnte nicht geöffnet werden");
        }
    }

    private Bitmap decodeHighResolutionPhoto(Uri uri, int maxDimension) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(input, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while (bounds.outWidth / sample > maxDimension * 2 || bounds.outHeight / sample > maxDimension * 2) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inSampleSize = sample;
        Bitmap bitmap;
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(input, null, options);
        }
        if (bitmap == null) return null;
        return scaleDown(bitmap, maxDimension);
    }

    private void loadVideo(Uri uri) {
        stopVideo();
        clearPipetteCalibration();
        recognitionMode = RecognitionMode.OFF;
        try {
            videoRetriever = new MediaMetadataRetriever();
            videoRetriever.setDataSource(this, uri);
            String duration = videoRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            videoDurationMs = duration == null ? 0 : Long.parseLong(duration);
            if (videoDurationMs <= 0) throw new IOException("Videolänge unbekannt");
            videoMode = true;
            cameraMode = false;
            videoSeek.setVisibility(View.VISIBLE);
            videoPositionLabel.setText("Video · Position 0:00");
            updateVideoFrame(0);
            statusText.setText("Video geöffnet · Position mit dem Regler wählen");
        } catch (Exception exception) {
            stopVideo();
            showEmptyState("Video konnte nicht geöffnet werden");
        }
    }

    private void updateVideoFrame(long positionMs) {
        if (!videoMode || videoRetriever == null) return;
        Bitmap frame = videoRetriever.getFrameAtTime(Math.max(0, positionMs) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST);
        if (frame == null) return;
        Bitmap scaled = scaleDown(frame, 1600);
        if (scaled != frame) frame.recycle();
        Bitmap oldSource = currentSource;
        currentSource = scaled;
        if (oldSource != null && oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
        zoomPreview.markNeedsFit();
        Bitmap filtered = filterBitmap(currentSource);
        runOnUiThread(() -> {
            setDisplayBitmap(filtered);
            emptyPreview.setVisibility(View.GONE);
            preview.setVisibility(View.VISIBLE);
            saveButton.setEnabled(true);
            videoPositionLabel.setText("Video · Position " + formatTime(positionMs));
            if (videoSeek.getProgress() != (int) (positionMs * 1000L / Math.max(1, videoDurationMs))) {
                videoSeek.setProgress((int) (positionMs * 1000L / Math.max(1, videoDurationMs)));
            }
        });
    }

    private void stopVideo() {
        videoMode = false;
        if (videoSeek != null) videoSeek.setVisibility(View.GONE);
        if (videoPositionLabel != null) videoPositionLabel.setText("");
        if (videoRetriever != null) {
            try { videoRetriever.release(); } catch (Exception ignored) { }
            videoRetriever = null;
        }
    }

    private void refreshCurrentMedia() {
        if (currentSource == null || (cameraMode && !cameraFrozen)) return;
        Bitmap filtered;
        try {
            filtered = filterBitmap(currentSource);
        } catch (OutOfMemoryError error) {
            Bitmap safeSource = scaleDown(currentSource, 4096);
            if (safeSource == currentSource) {
                statusText.setText("Bild ist zu groß für die Filtervorschau");
                return;
            }
            Bitmap oldSource = currentSource;
            currentSource = safeSource;
            if (oldSource != currentDisplay && !oldSource.isRecycled()) oldSource.recycle();
            try {
                filtered = filterBitmap(currentSource);
                statusText.setText("Sichere Auflösung für dieses Gerät verwendet");
            } catch (OutOfMemoryError secondError) {
                statusText.setText("Bild ist zu groß für die Filtervorschau");
                return;
            }
        }
        setDisplayBitmap(filtered);
        emptyPreview.setVisibility(View.GONE);
        preview.setVisibility(View.VISIBLE);
        saveButton.setEnabled(currentSource != null);
    }

    private void setDisplayBitmap(Bitmap bitmap) {
        Bitmap old = currentDisplay;
        currentDisplay = bitmap;
        renderPreview();
        if (zoomPreview != null) zoomPreview.fitToViewIfNeeded();
        updateRecognitionUi();
        pipetteButton.setEnabled(currentSource != null);
        updatePipetteAreaUi();
        updateColorToolUi();
        if (old != null && old != currentSource && old != bitmap && !old.isRecycled()) old.recycle();
    }

    private Bitmap filterBitmap(Bitmap source) {
        Bitmap output = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        if (recognitionMode != RecognitionMode.OFF && (!cameraMode || cameraFrozen)) {
            applyRecognitionFilter(source, output);
            return output;
        }
        if (selectedProfile == Profile.RED_GREEN || selectedProfile == Profile.RED_GREEN_PLUS) {
            applyRedGreenDaltonization(source, output, selectedProfile == Profile.RED_GREEN_PLUS);
            return output;
        }
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        paint.setColorFilter(new ColorMatrixColorFilter(buildColorMatrix(source)));
        canvas.drawBitmap(source, 0, 0, paint);
        return output;
    }

    /**
     * A static-image reading mode. It deliberately sacrifices natural colour
     * reproduction to create stronger luminance and blue/yellow cues for
     * numbers, dots, marker strokes and board text.
     */
    private void applyRecognitionFilter(Bitmap source, Bitmap output) {
        int width = source.getWidth();
        int height = source.getHeight();
        int[] pixels = new int[width * height];
        source.getPixels(pixels, 0, width, 0, 0, width, height);
        boolean whiteboard = recognitionMode == RecognitionMode.WHITEBOARD;
        float strength = Math.max(0.05f, recognitionStrength / 100f);
        float opponentStrength = (whiteboard ? .82f : 1.12f) * strength;
        float contrast = (whiteboard ? 1.10f : 1.06f) + strength * (whiteboard ? .12f : .14f);
        float brightnessOffset = whiteboard ? .015f * strength : 0f;

        for (int index = 0; index < pixels.length; index++) {
            int pixel = pixels[index];
            float r = SRGB_TO_LINEAR[Color.red(pixel)];
            float g = SRGB_TO_LINEAR[Color.green(pixel)];
            float b = SRGB_TO_LINEAR[Color.blue(pixel)];
            float maximum = Math.max(r, Math.max(g, b));
            float minimum = Math.min(r, Math.min(g, b));
            float chroma = maximum - minimum;
            float luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b;
            float localLuminance = localLinearLuminance(source, index % width, index / width);
            float localDetail = clamp((luminance - localLuminance) * (whiteboard ? 2.0f : 2.8f), -.22f, .22f);

            float opponent = clamp((r - g) * 2.5f, -1f, 1f);
            float chromaGate = Math.min(1f, chroma * (whiteboard ? 2.8f : 4.0f));
            float shift = opponent * chromaGate * opponentStrength;
            // Positive red/green difference moves toward yellow, negative
            // difference toward blue. This is intentionally stronger than the
            // everyday Rot-Grün profiles.
            float red = r + shift * (whiteboard ? .05f : .10f);
            float green = g + shift * (whiteboard ? .18f : .30f);
            float blue = b - shift * (whiteboard ? .22f : .30f);
            red += localDetail;
            green += localDetail;
            blue += localDetail;

            if (whiteboard && luminance > .72f && chroma < .18f) {
                // Keep a bright board surface close to white rather than
                // turning it into a saturated false colour.
                float whiteLift = Math.min(.12f, (luminance - .72f) * .45f * strength);
                red += whiteLift;
                green += whiteLift;
                blue += whiteLift;
            }

            red = clamp((red - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            green = clamp((green - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            blue = clamp((blue - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            pixels[index] = Color.argb(Color.alpha(pixel),
                    linearToSrgbByte(red), linearToSrgbByte(green), linearToSrgbByte(blue));
        }
        output.setPixels(pixels, 0, width, 0, 0, width, height);
    }

    private float localLinearLuminance(Bitmap source, int x, int y) {
        int left = Math.max(0, x - 4);
        int right = Math.min(source.getWidth() - 1, x + 4);
        int top = Math.max(0, y - 4);
        int bottom = Math.min(source.getHeight() - 1, y + 4);
        int[] points = new int[]{
                source.getPixel(left, y), source.getPixel(right, y),
                source.getPixel(x, top), source.getPixel(x, bottom)
        };
        float total = 0f;
        for (int point : points) {
            float r = SRGB_TO_LINEAR[Color.red(point)];
            float g = SRGB_TO_LINEAR[Color.green(point)];
            float b = SRGB_TO_LINEAR[Color.blue(point)];
            total += .2126f * r + .7152f * g + .0722f * b;
        }
        return total / points.length;
    }

    /**
     * Re-encodes the red/green opponent signal into yellow/blue and luminance
     * cues. This is deliberately different from simply replacing one RGB row:
     * neutral surfaces stay neutral while red/green differences get a cue that
     * remains useful on boards and screens.
     */
    private void applyRedGreenDaltonization(Bitmap source, Bitmap output, boolean strong) {
        int width = source.getWidth();
        int height = source.getHeight();
        int[] pixels = new int[width * height];
        source.getPixels(pixels, 0, width, 0, 0, width, height);
        float userStrength = Math.max(0.05f, strengthSeek == null
                ? .7f : strengthSeek.getProgress() / 100f);
        float opponentStrength = (strong ? .86f : .46f) * userStrength;
        float brightness = brightnessSeek == null ? 0f : (brightnessSeek.getProgress() - 50) * 1.25f;
        if (autoEnhance) brightness += automaticBrightnessOffset(source);
        float contrast = 1f + Math.abs(brightness) / 300f + (strong ? .035f : .0f);
        float brightnessOffset = brightness / 255f;

        for (int index = 0; index < pixels.length; index++) {
            int pixel = pixels[index];
            float r = SRGB_TO_LINEAR[Color.red(pixel)];
            float g = SRGB_TO_LINEAR[Color.green(pixel)];
            float b = SRGB_TO_LINEAR[Color.blue(pixel)];
            float max = Math.max(r, Math.max(g, b));
            float min = Math.min(r, Math.min(g, b));
            float chroma = max - min;
            float luminance = 0.2126f * r + 0.7152f * g + 0.0722f * b;

            // Red is mapped toward yellow, green toward blue. The adjustment
            // is driven by the opponent signal, not by a fixed hue threshold.
            float opponent = clamp((r - g) * 2.25f, -1f, 1f);
            float chromaGate = Math.min(1f, chroma * 3.2f);
            float shift = opponent * chromaGate * opponentStrength;
            float red = r + shift * 0.08f;
            float green = g + shift * 0.23f;
            float blue = b - shift * 0.20f;

            if (strong && chroma > .035f) {
                float localContrast = clamp((luminance - .5f) * .10f, -.06f, .06f);
                red += localContrast;
                green += localContrast;
                blue += localContrast;
            }

            red = clamp((red - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            green = clamp((green - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            blue = clamp((blue - .5f) * contrast + .5f + brightnessOffset, 0f, 1f);
            pixels[index] = Color.argb(Color.alpha(pixel),
                    linearToSrgbByte(red), linearToSrgbByte(green), linearToSrgbByte(blue));
        }
        output.setPixels(pixels, 0, width, 0, 0, width, height);
    }

    private int linearToSrgbByte(float value) {
        int index = Math.round(clamp(value, 0f, 1f) * (LINEAR_TO_SRGB.length - 1));
        return LINEAR_TO_SRGB[index];
    }

    private float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private ColorMatrix buildColorMatrix(Bitmap source) {
        float intensity = Math.max(0.05f, strengthSeek == null ? .7f : strengthSeek.getProgress() / 100f);
        float[] base = selectedProfile.matrix;
        float[] values = new float[20];
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 5; col++) {
                int index = row * 5 + col;
                float identity = (row < 3 && col == row) ? 1f : 0f;
                values[index] = identity + (base[index] - identity) * intensity;
            }
        }
        float brightness = brightnessSeek == null ? 0f : (brightnessSeek.getProgress() - 50) * 1.25f;
        if (autoEnhance && source != null) brightness += automaticBrightnessOffset(source);
        float contrast = 1f + Math.abs(brightness) / 300f;
        for (int row = 0; row < 3; row++) {
            values[row * 5] *= contrast;
            values[row * 5 + 1] *= contrast;
            values[row * 5 + 2] *= contrast;
            values[row * 5 + 4] += brightness;
        }
        return new ColorMatrix(values);
    }

    private float automaticBrightnessOffset(Bitmap source) {
        int stepX = Math.max(1, source.getWidth() / 24);
        int stepY = Math.max(1, source.getHeight() / 24);
        long total = 0;
        int count = 0;
        for (int y = 0; y < source.getHeight(); y += stepY) {
            for (int x = 0; x < source.getWidth(); x += stepX) {
                int pixel = source.getPixel(x, y);
                total += (long) (0.2126f * Color.red(pixel) + 0.7152f * Color.green(pixel) + 0.0722f * Color.blue(pixel));
                count++;
            }
        }
        if (count == 0) return 0f;
        float average = total / (float) count;
        if (average < 72f) return Math.min(28f, (72f - average) * 0.28f);
        if (average > 205f) return -Math.min(20f, (average - 205f) * 0.18f);
        return 0f;
    }

    private void saveCurrentImage() {
        Bitmap imageToSave = showingOriginal ? currentSource : currentDisplay;
        if (imageToSave == null || imageToSave.isRecycled()) return;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, "SehPlus_" + stamp + ".jpg");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SehPlus");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
        }
        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) {
            Toast.makeText(this, "Speichern nicht möglich", Toast.LENGTH_SHORT).show();
            return;
        }
        try (java.io.OutputStream output = resolver.openOutputStream(uri)) {
            imageToSave.compress(Bitmap.CompressFormat.JPEG, 94, output);
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
            }
            Toast.makeText(this, "Bild in Pictures/SehPlus gespeichert", Toast.LENGTH_LONG).show();
        } catch (Exception exception) {
            resolver.delete(uri, null, null);
            Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap scaleDown(Bitmap source, int maxDimension) {
        int width = source.getWidth();
        int height = source.getHeight();
        int largest = Math.max(width, height);
        if (largest <= maxDimension) return source;
        float scale = maxDimension / (float) largest;
        Bitmap scaled = Bitmap.createScaledBitmap(source, Math.round(width * scale), Math.round(height * scale), true);
        return scaled;
    }

    private String formatTime(long millis) {
        long seconds = Math.max(0, millis / 1000);
        return String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera();
            else showCameraError("Kamerazugriff wurde nicht erlaubt");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cameraMode) stopCamera();
        else turnTorchOff();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDeviceStatus();
    }

    @Override
    protected void onDestroy() {
        turnTorchOff();
        stopCamera();
        stopVideo();
        if (currentSource != null && !currentSource.isRecycled()) currentSource.recycle();
        if (currentDisplay != null && currentDisplay != currentSource && !currentDisplay.isRecycled()) currentDisplay.recycle();
        super.onDestroy();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int previewHeight() {
        float density = getResources().getDisplayMetrics().density;
        int screenHeightDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        int desiredHeightDp = Math.round(screenHeightDp * 0.52f);
        return dp(Math.max(380, Math.min(620, desiredHeightDp)));
    }

    private class PipetteOverlay extends View {
        private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private float pointX;
        private float pointY;
        private int sourceX = -1;
        private int sourceY = -1;
        private boolean hasPoint;
        private ColorAnalyzer.AreaSize areaSize = ColorAnalyzer.AreaSize.MEDIUM;

        PipetteOverlay(Context context) {
            super(context);
            setClickable(false);
            overlayPaint.setStrokeWidth(dp(2));
        }

        void setPoint(float x, float y) {
            pointX = x;
            pointY = y;
            hasPoint = true;
            invalidate();
        }

        void setSourcePoint(int x, int y) {
            sourceX = x;
            sourceY = y;
            invalidate();
        }

        void setAreaSize(ColorAnalyzer.AreaSize size) {
            areaSize = size == null ? ColorAnalyzer.AreaSize.MEDIUM : size;
            invalidate();
        }

        void clearPoint() {
            hasPoint = false;
            sourceX = -1;
            sourceY = -1;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (!hasPoint) return;
            drawMagnifier(canvas);
            overlayPaint.setStyle(Paint.Style.STROKE);
            overlayPaint.setStrokeWidth(dp(2));
            overlayPaint.setColor(Color.argb(150, 255, 255, 255));
            canvas.drawCircle(pointX, pointY, dp(areaSize.diameterDp) / 2f, overlayPaint);
            overlayPaint.setStyle(Paint.Style.FILL);
            overlayPaint.setColor(Color.argb(210, 10, 14, 16));
            canvas.drawCircle(pointX, pointY, dp(30), overlayPaint);
            overlayPaint.setStyle(Paint.Style.STROKE);
            overlayPaint.setStrokeWidth(dp(2));
            overlayPaint.setColor(Color.WHITE);
            canvas.drawCircle(pointX, pointY, dp(26), overlayPaint);
            canvas.drawLine(pointX - dp(38), pointY, pointX + dp(38), pointY, overlayPaint);
            canvas.drawLine(pointX, pointY - dp(38), pointX, pointY + dp(38), overlayPaint);
            overlayPaint.setStyle(Paint.Style.FILL);
            overlayPaint.setColor(accent);
            canvas.drawCircle(pointX, pointY, dp(4), overlayPaint);
        }

        private void drawMagnifier(Canvas canvas) {
            if (currentSource == null || currentSource.isRecycled()
                    || sourceX < 0 || sourceY < 0) return;
            float boxSize = dp(78);
            float margin = dp(10);
            float left = pointX + dp(42);
            if (left + boxSize > getWidth() - margin) left = pointX - boxSize - dp(42);
            left = Math.max(margin, Math.min(left, getWidth() - boxSize - margin));
            float top = pointY - boxSize - dp(46);
            if (top < margin) top = pointY + dp(46);
            top = Math.max(margin, Math.min(top, getHeight() - boxSize - margin));

            float[] values = new float[9];
            zoomPreview.getImageMatrix().getValues(values);
            float scale = Math.max(.01f, (float) Math.hypot(
                    values[Matrix.MSCALE_X], values[Matrix.MSKEW_Y]));
            int halfCrop = Math.max(8, Math.round(dp(26) / scale));
            int sourceLeft = Math.max(0, sourceX - halfCrop);
            int sourceTop = Math.max(0, sourceY - halfCrop);
            int sourceRight = Math.min(currentSource.getWidth(), sourceX + halfCrop + 1);
            int sourceBottom = Math.min(currentSource.getHeight(), sourceY + halfCrop + 1);
            if (sourceRight <= sourceLeft || sourceBottom <= sourceTop) return;

            RectF destination = new RectF(left, top, left + boxSize, top + boxSize);
            overlayPaint.setStyle(Paint.Style.FILL);
            overlayPaint.setColor(Color.argb(235, 8, 12, 14));
            canvas.drawRoundRect(destination, dp(12), dp(12), overlayPaint);
            Path clip = new Path();
            clip.addRoundRect(destination, dp(10), dp(10), Path.Direction.CW);
            canvas.save();
            canvas.clipPath(clip);
            canvas.drawBitmap(currentSource,
                    new android.graphics.Rect(sourceLeft, sourceTop, sourceRight, sourceBottom),
                    destination, bitmapPaint);
            canvas.restore();
            overlayPaint.setStyle(Paint.Style.STROKE);
            overlayPaint.setStrokeWidth(dp(2));
            overlayPaint.setColor(Color.WHITE);
            canvas.drawRoundRect(destination, dp(12), dp(12), overlayPaint);
            overlayPaint.setColor(accent);
            canvas.drawCircle(left + boxSize / 2f, top + boxSize / 2f, dp(3), overlayPaint);
        }
    }

    private enum CameraUiState {
        IDLE("Bereit"),
        STARTING("Kamera startet"),
        LIVE("Live-Kamera"),
        FROZEN("Standbild"),
        ERROR("Kamerafehler");

        final String label;

        CameraUiState(String label) {
            this.label = label;
        }
    }

    private static class PipetteCalibration {
        final float redGain;
        final float greenGain;
        final float blueGain;
        final int referenceColor;

        PipetteCalibration(float redGain, float greenGain, float blueGain, int referenceColor) {
            this.redGain = redGain;
            this.greenGain = greenGain;
            this.blueGain = blueGain;
            this.referenceColor = referenceColor;
        }
    }

    private enum TestLabSample {
        BEIGE_STOFF("Beiger Stoff"),
        BLAU_GRAU_STOFF("Blau-grauer Stoff"),
        WARMES_INNENLICHT("Warmes Innenlicht"),
        FARBKANTE("Farbkante / gemischter Übergang"),
        TESTPUNKTE("Punkt-Testbild"),
        WHITEBOARD("Whiteboard und Marker");

        final String label;

        TestLabSample(String label) {
            this.label = label;
        }
    }

    private enum RecognitionMode {
        OFF("Aus"),
        TEST_IMAGE("Testbild"),
        WHITEBOARD("Whiteboard");

        final String label;

        RecognitionMode(String label) {
            this.label = label;
        }
    }

    private enum Profile {
        RED_GREEN("Rot-Grün", "Natürliche Rot-Grün-Unterstützung mit zusätzlicher Blau-Gelb-Trennung.", new float[]{1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0}),
        RED_GREEN_PLUS("Rot-Grün+", "Stärkere Rot-Grün-Unterstützung für Testbilder, Whiteboards und Touch-Boards.", new float[]{1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0}),
        TRITAN("Blau-Gelb", "Blau-Gelb-Unterstützung für Tritanopie.", new float[]{1, 0, 0, 0, 0, 0, 1.0f, 0, 0, 0, 0, 0.475f, 0.525f, 0, 0, 0, 0, 0, 1, 0}),
        CONTRAST("Kontrast", "Mehr Farbtrennung und Kontrast für schwierige Lichtverhältnisse.", new float[]{1.24f, -0.12f, -0.12f, 0, 0, -0.08f, 1.16f, -0.08f, 0, 0, -0.08f, -0.08f, 1.16f, 0, 0, 0, 0, 0, 1, 0}),
        NEUTRAL("Neutral", "Originalbild ohne Farbkorrektur.", new float[]{1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0});

        final String shortName;
        final String description;
        final float[] matrix;

        Profile(String shortName, String description, float[] matrix) {
            this.shortName = shortName;
            this.description = description;
            this.matrix = matrix;
        }

        static Profile fromStoredName(String storedName) {
            if (storedName == null) return RED_GREEN_PLUS;
            if ("PROTAN".equals(storedName)) return RED_GREEN;
            if ("DEUTAN".equals(storedName)) return RED_GREEN_PLUS;
            try {
                return Profile.valueOf(storedName);
            } catch (IllegalArgumentException exception) {
                return RED_GREEN_PLUS;
            }
        }
    }
}
