#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  echo "Für diesen Dokumentencheck wird Node.js ab Version 18 benötigt. Der Android-Build selbst benötigt Node.js nicht." >&2
  exit 2
fi
exec node "$project_dir/scripts/legal-tools.mjs" check "$@"
