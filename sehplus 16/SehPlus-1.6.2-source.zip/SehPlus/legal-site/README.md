# SehPlus Rechtstexte – private Vorschau

Diese Site enthält ausschließlich die SehPlus-Rechtstexte. Sie bleibt privat, solange die Angaben im Entwurf nicht vervollständigt und die öffentliche Freigabe nicht ausdrücklich beauftragt wurden.

Quelle im Android-Projekt: `legal/documents/`. Mit `node scripts/legal-tools.mjs prepare-site` aus dem Projektordner werden dieselben Dateien nach `legal-site/dist/` kopiert. Die Android-App bündelt diese Quelle beim Gradle-Build ebenfalls, ohne sie aus dem Netz zu laden.

Die private Vorschau ist keine geeignete Datenschutz-URL für den Google-Play-Launch.
