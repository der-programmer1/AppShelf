#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DOCUMENTS = ['index.html', 'privacy.html', 'impressum.html', 'legal.css'];
const DOMAINS = ['root', 'file', 'database', 'sharedpref', 'external', 'device_root', 'device_file', 'device_database', 'device_sharedpref'];

export function readProperties(text) {
  const values = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || /^[#!]/.test(line)) continue;
    const separator = line.indexOf('=');
    if (separator < 1) throw new Error(`Ungültiger Konfigurationseintrag: ${line}`);
    const key = line.slice(0, separator).trim();
    if (Object.hasOwn(values, key)) throw new Error(`Doppelter Konfigurationsschlüssel: ${key}`);
    values[key] = line.slice(separator + 1).trim();
  }
  return values;
}

export function isPublicHttps(value) {
  if (!value || value !== value.trim() || /\s/.test(value)) return false;
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    if (url.protocol !== 'https:' || url.username || url.password || !host.includes('.') || host.endsWith('.') || host.includes(':') || /^[\d.]+$/.test(host)) return false;
    if (/(^|\.)example\.(com|net|org)$/.test(host) || /\.(example|invalid|test|local|localhost|internal)$/.test(host)) return false;
    return !/DEIN_FORMULAR_ID|DEINE-DOMAIN|%0a|%0d/i.test(value);
  } catch { return false; }
}

export function releaseProblems(config, documents) {
  const problems = [];
  if (config.publicationReady !== 'true') problems.push('publicationReady=false: öffentliche Freigabe steht noch aus.');
  for (const key of ['privacyUrl', 'imprintUrl']) if (!isPublicHttps(config[key])) problems.push(`${key}: gültige öffentliche HTTPS-Adresse fehlt.`);
  if (config.feedbackUrl && !isPublicHttps(config.feedbackUrl)) problems.push('feedbackUrl: ungültiger oder nicht ersetzter Formular-Link.');
  for (const [name, content] of Object.entries(documents)) {
    if (!name.endsWith('.html')) continue;
    if (/data-legal-status\s*=\s*["']draft["']/i.test(content)) problems.push(`${name}: noch als Entwurf markiert.`);
    for (const marker of new Set(content.match(/\[[A-ZÄÖÜ_][A-ZÄÖÜ_0-9 -]+\]/g) ?? [])) problems.push(`${name}: ${marker}`);
  }
  return problems;
}

export function loadDocuments(root = ROOT) {
  return Object.fromEntries(DOCUMENTS.map(name => [name, fs.readFileSync(path.join(root, 'legal/documents', name), 'utf8')]));
}

export function technicalProblems(root = ROOT) {
  const problems = [];
  const documents = loadDocuments(root);
  const versions = new Set();
  for (const [name, content] of Object.entries(documents)) {
    if (!name.endsWith('.html')) continue;
    if (!/<html\b[^>]*lang="de"/.test(content)) problems.push(`${name}: deutsche Dokumentensprache fehlt.`);
    const version = content.match(/name="legal-version" content="([^"]+)"/)?.[1];
    if (!version) problems.push(`${name}: Textversion fehlt.`); else versions.add(version);
    if (/<(?:script|iframe|form|object|embed)\b|\son\w+\s*=/i.test(content)) problems.push(`${name}: unerwarteter aktiver Inhalt.`);
    if (/<[^>]+(?:src|srcset)\s*=/i.test(content)) problems.push(`${name}: unerwartete eingebettete Ressourcen.`);
    if (/<link[^>]+href="(?:https?:)?\/\//i.test(content)) problems.push(`${name}: externe Ressource.`);
    for (const [, link] of content.matchAll(/href="([^"]*)"/g)) {
      if (/^https:\/\//.test(link) || /^mailto:/.test(link)) continue;
      const [target, fragment] = link.split('#');
      const targetName = target || name;
      if (!Object.hasOwn(documents, targetName)) problems.push(`${name}: unbekanntes Linkziel ${link}.`);
      else if (fragment && !documents[targetName].includes(`id="${fragment}"`)) problems.push(`${name}: fehlende Sprungmarke ${link}.`);
    }
  }
  if (versions.size !== 1) problems.push('Die Textversionen stimmen nicht überein.');
  if (/@import|url\s*\(/i.test(documents['legal.css'])) problems.push('CSS enthält externe oder eingebettete Ressourcen.');
  const manifest = fs.readFileSync(path.join(root, 'app/src/main/AndroidManifest.xml'), 'utf8');
  if (!manifest.includes('android:allowBackup="false"')) problems.push('Android-Backup ist nicht ausgeschlossen.');
  if (/android\.permission\.(INTERNET|ACCESS_NETWORK_STATE)/.test(manifest)) problems.push('Unerwartete Netzwerkberechtigung.');
  for (const name of ['backup_rules.xml', 'data_extraction_rules.xml']) {
    const xml = fs.readFileSync(path.join(root, 'app/src/main/res/xml', name), 'utf8');
    const sections = name === 'backup_rules.xml' ? [xml] : ['cloud-backup', 'device-transfer'].map(tag => xml.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`))?.[1] ?? '');
    for (const section of sections) for (const domain of DOMAINS) if (!section.includes(`<exclude domain="${domain}" path="."`)) problems.push(`${name}: Ausschluss für ${domain} fehlt.`);
  }
  const reader = fs.readFileSync(path.join(root, 'app/src/main/java/com/sehplus/app/LegalActivity.java'), 'utf8');
  for (const call of ['setJavaScriptEnabled(false)', 'setBlockNetworkLoads(true)', 'setAllowFileAccess(false)', 'setAllowContentAccess(false)']) if (!reader.includes(call)) problems.push(`Offline-Ansicht: ${call} fehlt.`);
  for (const directory of ['legal-site/dist', 'app/build/generated/legalAssets/legal']) {
    if (!fs.existsSync(path.join(root, directory))) continue;
    for (const name of DOCUMENTS) {
      const target = path.join(root, directory, name);
      if (!fs.existsSync(target) || fs.readFileSync(target, 'utf8') !== documents[name]) problems.push(`${directory}/${name}: Kopie nicht aktuell.`);
    }
  }
  return problems;
}

function check(draft) {
  const documents = loadDocuments();
  const config = readProperties(fs.readFileSync(path.join(ROOT, 'legal/release.properties'), 'utf8'));
  const technical = technicalProblems();
  if (technical.length) {
    for (const issue of technical) console.error(`FEHLER: ${issue}`);
    return 1;
  }
  console.log('Technische Prüfung: Offline-Dokumente, interne Links, Backup-Ausschlüsse und erzeugte Kopien konsistent.');
  const missing = releaseProblems(config, documents);
  if (draft) {
    console.log(`Entwurf geprüft. Öffentliche Freigabe: ${missing.length ? 'OFFEN (' + missing.length + ' Befunde)' : 'Konfiguration vollständig'}.`);
    return 0;
  }
  if (missing.length) {
    for (const issue of missing) console.error(`OFFEN: ${issue}`);
    console.error('Launch-Check: noch nicht bereit. Dies ist die erwartete Sperre für einen Entwurf.');
    return 1;
  }
  console.log('Konfigurationsprüfung bestanden. URL-Erreichbarkeit ohne Anmeldung, Inhalte und rechtliche Freigabe sind zusätzlich zu prüfen.');
  return 0;
}

function prepareSite(isPublic) {
  if (isPublic && check(false) !== 0) return 1;
  const target = path.join(ROOT, 'legal-site/dist');
  fs.mkdirSync(target, {recursive: true});
  const extra = fs.readdirSync(target).filter(name => !DOCUMENTS.includes(name));
  if (extra.length) throw new Error(`Unerwartete Dateien im Rechtstexte-Ordner: ${extra.join(', ')}. Keine automatische Löschung.`);
  for (const name of DOCUMENTS) fs.copyFileSync(path.join(ROOT, 'legal/documents', name), path.join(target, name));
  console.log(`Rechtstexte synchronisiert: ${target} (${isPublic ? 'für öffentliche Bereitstellung geprüft' : 'private Entwurfsvorschau'}).`);
  return 0;
}

function exportHtml() {
  const documents = loadDocuments();
  const directory = path.join(ROOT, 'build/handoff');
  fs.mkdirSync(directory, {recursive: true});
  for (const name of ['privacy.html', 'impressum.html']) fs.writeFileSync(path.join(directory, name), documents[name].replace('<link rel="stylesheet" href="legal.css">', `<style>${documents['legal.css']}</style>`));
  console.log(`Selbstständig lesbare HTML-Dateien: ${directory}`);
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const command = process.argv[2] ?? 'check';
    process.exitCode = command === 'check' ? check(process.argv.includes('--draft'))
      : command === 'prepare-site' ? prepareSite(process.argv.includes('--public'))
      : command === 'export-html' ? exportHtml()
      : (() => { throw new Error(`Unbekannter Befehl: ${command}`); })();
  } catch (error) {
    console.error(`FEHLER: ${error.message}`);
    process.exitCode = 1;
  }
}
