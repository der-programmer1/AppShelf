import assert from 'node:assert/strict';
import test from 'node:test';
import {readProperties, isPublicHttps, releaseProblems, technicalProblems} from './legal-tools.mjs';

// URL strings are syntax fixtures only, not configured or verified contact addresses.
test('Konfigurationswerte statt Schutz-Strings prüfen', () => {
  const config = readProperties('# DEIN_FORMULAR_ID ist nur ein Kommentar\npublicationReady=true\nprivacyUrl=https://privacy.sehplus.de/privacy.html\nimprintUrl=https://privacy.sehplus.de/impressum.html\nfeedbackUrl=\n');
  assert.deepEqual(releaseProblems(config, {'privacy.html':'<html>Datenschutz</html>'}), []);
});
test('Entwurf und fehlende Pflichtfelder blockieren unabhängig von URLs', () => {
  assert.equal(releaseProblems({publicationReady:'false', privacyUrl:'https://privacy.sehplus.de/privacy.html', imprintUrl:'https://privacy.sehplus.de/impressum.html'}, {'privacy.html':'<html data-legal-status="draft">[DATENSCHUTZ_EMAIL]</html>'}).length, 3);
});
test('Ungültige, lokale und Platzhalter-Links werden nicht aktiviert', () => {
  for (const url of ['', 'javascript:alert(1)', 'http://privacy.sehplus.de', 'https://localhost', 'https://127.0.0.1', 'https://[::1]', 'https://user:password@privacy.sehplus.de', 'https://DEINE-DOMAIN.example/privacy.html', 'https://example.org', 'https://docs.google.com/forms/d/e/DEIN_FORMULAR_ID/viewform', 'https://privacy.sehplus.de/%0d%0a', ' https://privacy.sehplus.de']) assert.equal(isPublicHttps(url), false, url);
});
test('HTTPS-URL-Formate und Formularparameter bleiben nutzbar', () => {
  for (const url of ['https://privacy.sehplus.de/privacy.html', 'https://docs.google.com/forms/d/e/valid-token/viewform?usp=sf_link']) assert.equal(isPublicHttps(url), true, url);
});
test('Leeres Feedback ist erlaubt, Platzhalter nicht', () => {
  const config = {publicationReady:'true', privacyUrl:'https://privacy.sehplus.de/privacy.html', imprintUrl:'https://privacy.sehplus.de/impressum.html', feedbackUrl:''};
  assert.equal(releaseProblems(config, {}).length, 0);
  assert.equal(releaseProblems({...config, feedbackUrl:'https://docs.google.com/forms/d/e/DEIN_FORMULAR_ID/viewform'}, {}).length, 1);
});
test('Doppelte Konfigurationseinträge werden zurückgewiesen', () => {
  assert.throws(() => readProperties('publicationReady=false\npublicationReady=true\n'), /Doppelter/);
});
test('Dokumente, interne Links und sämtliche Backup-Domains sind vollständig', () => {
  assert.deepEqual(technicalProblems(), []);
});
