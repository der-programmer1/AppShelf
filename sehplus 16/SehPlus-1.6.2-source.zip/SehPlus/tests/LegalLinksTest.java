package com.sehplus.app;

public final class LegalLinksTest {
    private static int assertions;
    private static void expect(boolean condition, String label) {
        assertions++;
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        for (String value : new String[]{null, "", "http://privacy.sehplus.de", "javascript:alert(1)",
                "https://localhost", "https://127.0.0.1", "https://[::1]", "https://example.com",
                "https://a.example.org", "https://DEINE-DOMAIN.example/privacy.html",
                "https://user:password@privacy.sehplus.de", "https://privacy.sehplus.de/%0A",
                "https://docs.google.com/forms/d/e/DEIN_FORMULAR_ID/viewform", " https://privacy.sehplus.de"}) {
            expect(!LegalLinks.isPublicHttps(value), "Unsafe URL accepted: " + value);
        }
        expect(LegalLinks.isPublicHttps("https://privacy.sehplus.de/privacy.html"), "HTTPS format rejected");
        expect(LegalLinks.isPublicHttps("https://docs.google.com/forms/d/e/valid-token/viewform?usp=sf_link"), "Form format rejected");
        expect(!LegalLinks.isContactEmail("mailto:name@example.com"), "Placeholder email accepted");
        expect(!LegalLinks.isContactEmail("mailto:name@sehplus.de?bcc=other@sehplus.de"), "Mail headers accepted");
        expect(!LegalLinks.isContactEmail("mailto:name@sehplus.de%0d%0a"), "Encoded headers accepted");
        expect(LegalLinks.isContactEmail("mailto:datenschutz@sehplus.de"), "Email format rejected");
        expect("privacy.html".equals(LegalLinks.documentName("../../secret")), "Unsafe asset path accepted");
        expect("privacy.html".equals(LegalLinks.documentName(null)), "Missing document not defaulted");
        expect("impressum.html".equals(LegalLinks.documentName("impressum.html")), "Imprint not recognized");
        System.out.println("LegalLinks: " + assertions + " assertions passed (syntax fixtures, not real contact data).");
    }
}
